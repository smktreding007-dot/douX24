package com.bestwinesport.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Net { NONE, UNVERIFIED, OK }

/** NONE = no network at all, UNVERIFIED = connected to Wi-Fi/mobile but Android says there is no working internet, OK = internet works. */
private fun netOf(ctx: Context): Net {
    return try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return Net.NONE
        val caps = cm.getNetworkCapabilities(n) ?: return Net.NONE
        when {
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> Net.NONE
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) -> Net.OK
            else -> Net.UNVERIFIED
        }
    } catch (_: Exception) { Net.OK }
}

fun isOnline(ctx: Context): Boolean = netOf(ctx) != Net.NONE

/**
 * true while the phone really has internet. Reacts at once when the network is switched off, and also when Wi-Fi / mobile data is
 * connected but there is no internet behind it (no balance, router without internet). If Android has not verified the network yet,
 * the live Firebase connection decides.
 */
@Composable
fun rememberOnline(): Boolean {
    val ctx = LocalContext.current
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var net by remember { mutableStateOf(netOf(ctx)) }
    var fb by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val main = Handler(Looper.getMainLooper())
        fun refresh() { main.post { net = netOf(ctx) }; main.postDelayed({ net = netOf(ctx) }, 400) }   // second check: Android may still list the lost network for a moment
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { refresh() }
            override fun onLost(network: Network) { refresh() }
            override fun onUnavailable() { refresh() }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { refresh() }
        }
        try { cm.registerDefaultNetworkCallback(cb) } catch (_: Exception) { }
        val ref = try { com.google.firebase.database.FirebaseDatabase.getInstance().getReference(".info/connected") } catch (_: Exception) { null }
        val fl = object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(s: com.google.firebase.database.DataSnapshot) { fb = s.getValue(Boolean::class.java) == true }
            override fun onCancelled(e: com.google.firebase.database.DatabaseError) { }
        }
        try { ref?.addValueEventListener(fl) } catch (_: Exception) { }
        refresh()
        // Coming back from the background: Android's network state and the Firebase socket are both stale for a moment.
        // Re-read the network, force Firebase to reconnect, and check again a little later.
        val obs = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_START || event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                try { com.google.firebase.database.FirebaseDatabase.getInstance().goOnline() } catch (_: Exception) { }
                refresh()
                main.postDelayed({ net = netOf(ctx) }, 1500)
                main.postDelayed({ net = netOf(ctx) }, 3500)
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(obs)
            main.removeCallbacksAndMessages(null)
            try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) { }
            try { ref?.removeEventListener(fl) } catch (_: Exception) { }
        }
    }
    return when (net) { Net.NONE -> false; Net.OK -> true; Net.UNVERIFIED -> fb }
}

fun restartApp(ctx: Context) {
    val act = ctx.findActivity() ?: return
    act.startActivity(Intent(act, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
    act.finish()
}

/**
 * Full-screen page shown at once whenever the internet is gone, on every screen: black page, app name on top, red
 * "No Internet Connection." in the middle. When the internet is back the app restarts by itself (splash, then home).
 */
@Composable
fun OfflineGate() {
    val ctx = LocalContext.current
    val online = rememberOnline()
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var showPage by remember { mutableStateOf(false) }
    // A short drop (app just came back from the background, network switching) must not flash the page: it appears only if offline lasts 4 s.
    LaunchedEffect(online) {
        if (!online) { kotlinx.coroutines.delay(4000); showPage = true }
    }
    // Back online after the page was really shown: restart once, and only while the app is in front (a restart from the background is blocked by Android).
    LaunchedEffect(online, showPage) {
        if (online && showPage) {
            lifecycleOwner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.RESUMED) { restartApp(ctx) }
        }
    }
    if (!showPage) return
    BackHandler { ctx.findActivity()?.finish() }
    val appName = remember { try { ctx.applicationInfo.loadLabel(ctx.packageManager).toString() } catch (_: Exception) { "DOUx24" } }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }) {
        Text(appName, Modifier.fillMaxWidth().statusBarsPadding().padding(top = 18.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Text(tx("No Internet Connection."), Modifier.align(Alignment.Center), color = Color.Red, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}
