@file:androidx.media3.common.util.UnstableApi

package com.bestwinesport.app

import androidx.compose.foundation.layout.navigationBarsPadding

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.composed
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import com.google.firebase.auth.FirebaseAuth

/** false = all themes work (Liquid Glass is one of them). true = every player sees Liquid Glass only (saved theme / personal theme / custom colours are ignored). Set to false to bring the other themes back. */
const val FORCE_LIQUID_GLASS = false

private data class PlayerPalette(val id: String, val bg: Color, val card: Color, val field: Color,
                                val accent: Color, val orange: Color, val red: Color,
                                val button: Color, val match: Color, val support: Color, val success: Color,
                                val glass: Boolean = false,
                                /** true = this theme paints its own cards / panels / buttons / bottom bar (the admin main-card colour is not used). */
                                val slate: Boolean = false,
                                /** Outline colour / thickness of the cards, and fill + edge of the floating bottom bar (outlined themes; Midnight themes keep the grey defaults). */
                                val edge: Color = Color(0xFF2E323D), val edgeW: Float = 1f,
                                val barFill: Color? = null, val barEdge: Color? = null,
                                /** true = Clear Glass: like glass but almost fully see-through cards + a floating see-through bottom bar that floats over the page. */
                                val clear: Boolean = false)

private object PlayerPalettes {
    private val palettes = listOf(
        PlayerPalette("royal_purple", Color(0xFF10002B), Color(0xFF1A0536), Color(0xFF2E1763), Color(0xFF673AD1), Color(0xFFE8731A), Color(0xFFE01B10), Color(0xFF673AD1), Color(0xFF241044), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("ocean_blue", Color(0xFF06142E), Color(0xFF0C2250), Color(0xFF163A7A), Color(0xFF1E6BFF), Color(0xFFFFB300), Color(0xFFE01B10), Color(0xFF1E6BFF), Color(0xFF102C60), Color(0xFF12A7C2), Color(0xFF2ECC71)),
        PlayerPalette("forest_green", Color(0xFF06180F), Color(0xFF0C2A1B), Color(0xFF14402B), Color(0xFF1FA45B), Color(0xFFF2A900), Color(0xFFE01B10), Color(0xFF1FA45B), Color(0xFF103421), Color(0xFF1FA45B), Color(0xFF2ECC71)),
        PlayerPalette("crimson", Color(0xFF1A0306), Color(0xFF2B0A10), Color(0xFF4A1520), Color(0xFFD81B3C), Color(0xFFFF8F00), Color(0xFFE01B10), Color(0xFFD81B3C), Color(0xFF3D101A), Color(0xFFDB6977), Color(0xFF2ECC71)),
        PlayerPalette("emerald_luxe", Color(0xFF02120E), Color(0xFF072A21), Color(0xFF0E4034), Color(0xFF00C98D), Color(0xFFF2A900), Color(0xFFE01B10), Color(0xFF00A874), Color(0xFF0A342A), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("rose_pink", Color(0xFF14040C), Color(0xFF260918), Color(0xFF3F1128), Color(0xFFFF3D8B), Color(0xFFFF9800), Color(0xFFE01B10), Color(0xFFE91E73), Color(0xFF310D1F), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("amethyst", Color(0xFF0B0220), Color(0xFF170838), Color(0xFF2A1260), Color(0xFF9D4EDD), Color(0xFFF2A900), Color(0xFFE01B10), Color(0xFF7B2CBF), Color(0xFF200C4A), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("royal_gold", Color(0xFF0E0720), Color(0xFF1B0F3A), Color(0xFF2F1B63), Color(0xFFFFC83D), Color(0xFFFF8A00), Color(0xFFE01B10), Color(0xFFE0A100), Color(0xFF24144C), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("ice_teal", Color(0xFF03100F), Color(0xFF082422), Color(0xFF103A38), Color(0xFF2DD4BF), Color(0xFFF2A900), Color(0xFFE01B10), Color(0xFF14B8A6), Color(0xFF0C2E2C), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("sky_blue", Color(0xFF02070F), Color(0xFF081A2E), Color(0xFF0F2E4D), Color(0xFF38BDF8), Color(0xFFFBBF24), Color(0xFFE01B10), Color(0xFF0EA5E9), Color(0xFF0B233C), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("midnight_black", Color(0xFF000000), Color(0xFF121212), Color(0xFF242424), Color(0xFF7C4DFF), Color(0xFFFFA000), Color(0xFFE01B10), Color(0xFF7C4DFF), Color(0xFF1B1B1B), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_black_red", Color(0xFF060507), Color(0xFF14101A), Color(0xFF2A1B3A), Color(0xFFE11D2E), Color(0xFFF59E0B), Color(0xFFE01B10), Color(0xFFC8102E), Color(0xFF1E1528), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_gold", Color(0xFF0A0805), Color(0xFF17120A), Color(0xFF2B2210), Color(0xFFF5B301), Color(0xFFFF8A00), Color(0xFFE01B10), Color(0xFFD99A00), Color(0xFF20190D), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("neon_cyber", Color(0xFF02060F), Color(0xFF08142A), Color(0xFF0F2547), Color(0xFF00D1FF), Color(0xFFFFC400), Color(0xFFE01B10), Color(0xFF0096C7), Color(0xFF0B1C37), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("sunset_orange", Color(0xFF120703), Color(0xFF231009), Color(0xFF3B1D0E), Color(0xFFFF6A13), Color(0xFFFFB300), Color(0xFFE01B10), Color(0xFFE85D04), Color(0xFF2E160B), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("blood_moon", Color(0xFF090000), Color(0xFF1A0505), Color(0xFF2E0A0A), Color(0xFFFF1F1F), Color(0xFFFF8F00), Color(0xFFE01B10), Color(0xFFD90000), Color(0xFF230707), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("steel_blue", Color(0xFF080B10), Color(0xFF111A26), Color(0xFF1D2B40), Color(0xFF4F8CFF), Color(0xFFFFB300), Color(0xFFE01B10), Color(0xFF3A74E8), Color(0xFF162232), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("toxic_lime", Color(0xFF060A02), Color(0xFF101A06), Color(0xFF1B2D0B), Color(0xFF7ED321), Color(0xFFFFC107), Color(0xFFE01B10), Color(0xFF5FA812), Color(0xFF152308), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("yellow_flame", Color(0xFF0B0A02), Color(0xFF1A1704), Color(0xFF2E2808), Color(0xFFFACC15), Color(0xFFFB923C), Color(0xFFE01B10), Color(0xFFEAB308), Color(0xFF231F06), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_black_orange", Color(0xFF050505), Color(0xFF141414), Color(0xFF262626), Color(0xFFFF7A00), Color(0xFFFFB020), Color(0xFFE01B10), Color(0xFFF26A00), Color(0xFF1C1C1C), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_gold_purple", Color(0xFF0A0414), Color(0xFF1A0B2E), Color(0xFF2D1752), Color(0xFFFFB800), Color(0xFFFF8A00), Color(0xFFE01B10), Color(0xFFE69F00), Color(0xFF23103E), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_red_gold", Color(0xFF070707), Color(0xFF151210), Color(0xFF2A2218), Color(0xFFE2B13C), Color(0xFFE2B13C), Color(0xFFE01B10), Color(0xFFC0392B), Color(0xFF1E1914), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_fire", Color(0xFF0A0200), Color(0xFF1C0A04), Color(0xFF33150A), Color(0xFFFF4D1A), Color(0xFFFFA726), Color(0xFFE01B10), Color(0xFFE03E0E), Color(0xFF260F07), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("bestwin_blue", Color(0xFF03081A), Color(0xFF0A1640), Color(0xFF142468), Color(0xFF3B82F6), Color(0xFFFBBF24), Color(0xFFE01B10), Color(0xFF2563EB), Color(0xFF0E1C52), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("legends_navy", Color(0xFF020617), Color(0xFF0B1530), Color(0xFF16264D), Color(0xFF60A5FA), Color(0xFFF59E0B), Color(0xFFE01B10), Color(0xFF3B82F6), Color(0xFF101D3D), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("domain_violet", Color(0xFF0A0212), Color(0xFF1A0833), Color(0xFF2E1259), Color(0xFFA855F7), Color(0xFFF59E0B), Color(0xFFE01B10), Color(0xFF9333EA), Color(0xFF230C44), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("hot_pink", Color(0xFF12020A), Color(0xFF2A0817), Color(0xFF45102B), Color(0xFFFF2E88), Color(0xFFFF9F1C), Color(0xFFE01B10), Color(0xFFF0136E), Color(0xFF360C20), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("aqua_mint", Color(0xFF011110), Color(0xFF06302C), Color(0xFF0D4A44), Color(0xFF34E0A1), Color(0xFFF2A900), Color(0xFFE01B10), Color(0xFF12B886), Color(0xFF093C37), Color(0xFF168E9B), Color(0xFF2ECC71)),
        PlayerPalette("purple_neon_blue", Color(0xFF0A0220), Color(0xFF160A3A), Color(0xFF24146A), Color(0xFF1FB5FF), Color(0xFFFFB300), Color(0xFFE01B10), Color(0xFF6C2BD9), Color(0xFF1B0B4A), Color(0xFF1FB5FF), Color(0xFF2ECC71)),
        PlayerPalette("black_red_fire", Color(0xFF050000), Color(0xFF160505), Color(0xFF2A0A0A), Color(0xFFE01B10), Color(0xFFFF9800), Color(0xFFE01B10), Color(0xFFE01B10), Color(0xFF1F0808), Color(0xFFE01B10), Color(0xFF2ECC71)),
        PlayerPalette("black_gold", Color(0xFF050403), Color(0xFF14110A), Color(0xFF272014), Color(0xFFFFC21A), Color(0xFFFF9800), Color(0xFFE01B10), Color(0xFFD9A100), Color(0xFF1D180D), Color(0xFFFFC21A), Color(0xFF2ECC71)),
        PlayerPalette("cyberpunk_neon", Color(0xFF0A0118), Color(0xFF1A0833), Color(0xFF2D1058), Color(0xFF00F0FF), Color(0xFFFFC400), Color(0xFFE01B10), Color(0xFFFF2E9A), Color(0xFF220A44), Color(0xFFB026FF), Color(0xFF2ECC71)),
        PlayerPalette("black_orange_flame", Color(0xFF060300), Color(0xFF160B02), Color(0xFF2A1604), Color(0xFFFF7A00), Color(0xFFFFB020), Color(0xFFE01B10), Color(0xFFF26A00), Color(0xFF1E1004), Color(0xFFFF7A00), Color(0xFF2ECC71)),
        PlayerPalette("dark_blue_electric", Color(0xFF020A1F), Color(0xFF081A44), Color(0xFF102C6E), Color(0xFF1E90FF), Color(0xFFFFB300), Color(0xFFE01B10), Color(0xFF1565E8), Color(0xFF0B2154), Color(0xFF1E90FF), Color(0xFF2ECC71)),
        PlayerPalette("black_neon_green", Color(0xFF010401), Color(0xFF071207), Color(0xFF0E240E), Color(0xFF39FF14), Color(0xFFFFC107), Color(0xFFE01B10), Color(0xFF16B80B), Color(0xFF0A1A0A), Color(0xFF39FF14), Color(0xFF39FF14)),
        PlayerPalette("minimal_indigo", Color(0xFF08080C), Color(0xFF111118), Color(0xFF1C1C28), Color(0xFF6366F1), Color(0xFFF59E0B), Color(0xFFE01B10), Color(0xFF4F46E5), Color(0xFF14141F), Color(0xFF6366F1), Color(0xFF2ECC71)),
        // Midnight Slate: near-black navy page, slate cards, teal accent, black buttons (taken from the screenshot).
        PlayerPalette("midnight_teal", Color(0xFF05070B), Color(0xFF0D111A), Color(0xFF151B29), Color(0xFF4CC5BE), Color(0xFFF5A94A), Color(0xFFE01B10), Color(0xFF000000), Color(0xFF0D111C), Color(0xFF4CC5BE), Color(0xFF40C060), slate = true),
        // Midnight Violet: same slate-navy base as Midnight Slate with a violet accent.
        PlayerPalette("midnight_violet", Color(0xFF06070E), Color(0xFF0E1020), Color(0xFF181B33), Color(0xFFA78BFA), Color(0xFFFBBF24), Color(0xFFE01B10), Color(0xFF7C3AED), Color(0xFF12142A), Color(0xFFA78BFA), Color(0xFF34D399), slate = true),
        // DOUx24: near-black violet page, deep-violet cards with a glowing neon-violet outline (from the video).
        PlayerPalette("bestwin_violet_neon", Color(0xFF07010F), Color(0xFF11052B), Color(0xFF1B0B45), Color(0xFF9B5CFF), Color(0xFFF5A524), Color(0xFFE01B10), Color(0xFF6D3FD6), Color(0xFF12062F), Color(0xFF9B5CFF), Color(0xFF2ECC71), slate = true, edge = Color(0xFF7C3AED), edgeW = 1.5f, barFill = Color(0xFF0E0422), barEdge = Color(0xFF7C3AED)),
        // DOUx24: black page, dark indigo cards with a soft indigo edge, strong indigo-violet buttons (from the video).
        PlayerPalette("bestwin_indigo_tiles", Color(0xFF03010A), Color(0xFF0E0A26), Color(0xFF1A1442), Color(0xFF6C4DFF), Color(0xFFF59E0B), Color(0xFFE01B10), Color(0xFF4F2BD9), Color(0xFF0E0A26), Color(0xFF6C4DFF), Color(0xFF2ECC71), slate = true, edge = Color(0xFF2B2160), edgeW = 1f, barFill = Color(0xFF0A0720), barEdge = Color(0xFF3A2C86)),
        // Neon Pink Outline (new): black-plum page, plum cards, hot-pink outline.
        PlayerPalette("neon_pink_outline", Color(0xFF0B0210), Color(0xFF1A0620), Color(0xFF2B0B35), Color(0xFFFF4DA6), Color(0xFFFFB020), Color(0xFFE01B10), Color(0xFFD9348C), Color(0xFF1A0620), Color(0xFFFF4DA6), Color(0xFF2ECC71), slate = true, edge = Color(0xFFD9348C), edgeW = 1.5f, barFill = Color(0xFF14041A), barEdge = Color(0xFFD9348C)),
        // Royal Gold Outline (new): black page, warm-black cards, antique-gold outline.
        PlayerPalette("royal_gold_outline", Color(0xFF050403), Color(0xFF110E08), Color(0xFF211B0E), Color(0xFFFFC83D), Color(0xFFFF9800), Color(0xFFE01B10), Color(0xFFB8860B), Color(0xFF110E08), Color(0xFFFFC83D), Color(0xFF2ECC71), slate = true, edge = Color(0xFFB8892B), edgeW = 1.5f, barFill = Color(0xFF0C0905), barEdge = Color(0xFFB8892B)),
        // Bestwin Silver (new, from the new logo): pure black page, charcoal cards with a silver outline, silver/white accent, light-silver buttons (black text, always readable).
        PlayerPalette("bestwin_silver", Color(0xFF000000), Color(0xFF121214), Color(0xFF202226), Color(0xFFE6E8EC), Color(0xFFFFB020), Color(0xFFE01B10), Color(0xFFD4D7DD), Color(0xFF121214), Color(0xFFC9CCD3), Color(0xFF2ECC71), slate = true, edge = Color(0xFF8A8F99), edgeW = 1.2f, barFill = Color(0xFF0A0A0B), barEdge = Color(0xFF9AA0AA)),
        // Liquid Glass: blue-violet-cyan gradient background, frosted translucent cards (MatchC / AccountC) with a light edge. Dialogs and bars stay solid so text is always readable.
        PlayerPalette("liquid_glass", Color(0xFF081433), Color(0x2EFFFFFF), Color(0x3DFFFFFF), Color(0xFF4FC3FF), Color(0xFFFFB84D), Color(0xFFE01B10), Color(0xFF2F80ED), Color(0xFF1B2F63), Color(0xFF22B8CF), Color(0xFF2ECC71), glass = true),
        // Clear Glass (new): transparent / see-through. Cards, bars and panels are only ~7% white, so the page behind shows through everything.
        PlayerPalette("clear_glass", Color(0xFF060D26), Color(0x12FFFFFF), Color(0x1FFFFFFF), Color(0xFF5CD6FF), Color(0xFFFFB84D), Color(0xFFE01B10), Color(0xFF2F80ED), Color(0xFF1B2F63), Color(0xFF22B8CF), Color(0xFF2ECC71), glass = true, clear = true)
    )
    var current by mutableStateOf(if (FORCE_LIQUID_GLASS) palettes.first { it.id == "liquid_glass" } else palettes.first())
    /** Main card colour (match cards, account rows, wallet card, top bars). Admin sets it in Theme & colors -> "Match card + Account/Wallet cards". Default #190236. */
    val DEFAULT_MAIN = Color(0xFF190236)
    var mainCard by mutableStateOf(DEFAULT_MAIN)
    fun parseMain(raw: String?): Color {
        val h = raw?.trim()?.removePrefix("#") ?: return DEFAULT_MAIN
        return try { if (!h.matches(Regex("(?i)[0-9a-f]{6}"))) DEFAULT_MAIN else Color(android.graphics.Color.parseColor("#$h")) } catch (_: Exception) { DEFAULT_MAIN }
    }
    /** Old theme IDs (renamed to DOUx24) still saved in Firebase / on phones keep working. */
    private val legacyIds = mapOf("arise_battle" to "bestwin_black_red", "clash_orange" to "bestwin_black_orange", "victory_gold" to "bestwin_gold_purple", "warx_fire" to "bestwin_fire", "esports_blue" to "bestwin_blue", "skillwar_violet" to "bestwin_violet_neon", "supremex_indigo" to "bestwin_indigo_tiles")
    fun get(id0: String): PlayerPalette {
        val id = legacyIds[id0] ?: id0
        return if (FORCE_LIQUID_GLASS) palettes.first { it.id == "liquid_glass" } else (palettes.firstOrNull { it.id == id } ?: palettes.first())
    }
    fun custom(values: Map<String, Any?>): PlayerPalette {
        val base = palettes.first()
        fun color(key: String, fallback: Color): Color {
            val raw = values[key]?.toString()?.trim()?.removePrefix("#") ?: return fallback
            return try { if (!raw.matches(Regex("(?i)[0-9a-f]{6}"))) fallback else Color(android.graphics.Color.parseColor("#$raw")) }
            catch (_: Exception) { fallback }
        }
        return base.copy(id = "custom", bg = color("themeBg", base.bg), card = color("themeCard", base.card),
            field = color("themeField", base.field), accent = color("themeAccent", base.accent),
            button = color("themeButton", base.button), match = color("themeMatch", base.match),
            support = color("themeSupport", base.support), orange = color("themeWarning", base.orange),
            red = color("themeDanger", base.red), success = color("themeSuccess", base.success))
    }
}

val Bg: Color get() = PlayerPalettes.current.bg
val CardC: Color get() = PlayerPalettes.current.card
val Field: Color get() = PlayerPalettes.current.field
/** Player-created (PvP) match screens: fixed #141416 panel colour, never changes with the theme. */
val PvpCardC: Color = Color(0xFF141416)
val Purple: Color get() = PlayerPalettes.current.accent
val Orange: Color get() = PlayerPalettes.current.orange
val Red: Color get() = PlayerPalettes.current.red
/** SPECTATE button red = the Red Fire theme colour (same as the Ongoing / Upcoming / Completed icons in that theme), fixed in every theme, white text. */
val SpectateRed = Color(0xFFE01B10)
/** Home headings (IMPORTANT / EXCLUSIVE / MY CONTESTS) and the Ongoing / Upcoming / Completed icons: follow the selected theme (its main accent colour). */
val HomeRed: Color get() = PlayerPalettes.current.accent
/** Wallet box + the small round / square badges next to the Home headings: the theme accent, darkened only when it is so light (Silver, Gold...) that white text/icons on it would be unreadable. */
val HomeFill: Color get() = PlayerPalettes.current.accent.let { c -> if (c.luminance() > 0.35f) androidx.compose.ui.graphics.lerp(c, Color.Black, 0.5f) else c }
val ButtonC: Color get() = PlayerPalettes.current.button
/** Match card colour: admin-controlled main card colour (default #190236), same for every theme. */
val MatchC: Color get() = when { PlayerPalettes.current.glass -> GlassFill; PlayerPalettes.current.slate -> PlayerPalettes.current.card; else -> PlayerPalettes.mainCard }
/** Account menu rows, stats card, wallet card, top bars: same admin-controlled main card colour as match cards (default #190236). */
val AccountC: Color get() = when { PlayerPalettes.current.glass -> GlassFill; PlayerPalettes.current.slate -> PlayerPalettes.current.card; else -> PlayerPalettes.mainCard }
val SupportC: Color get() = PlayerPalettes.current.support
val SuccessC: Color get() = PlayerPalettes.current.success
val BarC: Color get() = PlayerPalettes.current.card
val BorderC: Color get() = if (PlayerPalettes.current.clear) Color.White.copy(alpha = 0.38f) else if (PlayerPalettes.current.glass) Color.White.copy(alpha = 0.30f) else PlayerPalettes.current.accent.copy(alpha = 0.45f)
/** Panel colour that turns into frosted glass in the Liquid Glass theme (used for the old hard-coded dark panels). */
fun glassOr(c: Color): Color = when {
    PlayerPalettes.current.glass -> GlassFill
    PlayerPalettes.current.slate -> if (c == Color(0xFF190236)) PlayerPalettes.current.card else PlayerPalettes.current.field
    else -> c
}
/** True for the Midnight themes (black-navy page, bordered rounded cards, floating bottom bar, outlined black buttons). */
val IsSlate: Boolean get() = PlayerPalettes.current.slate
val SlateBorder: Color get() = PlayerPalettes.current.edge
/** Border of buttons / the bottom bar in the outlined themes. */
val SlateBtnBorder: Color get() = PlayerPalettes.current.barEdge ?: Color(0xFF3A4152)
/** Thin neutral outline around cards in the Midnight themes; does nothing in every other theme. */
fun Modifier.slateEdge(shape: androidx.compose.ui.graphics.Shape): Modifier =
    if (IsSlate) this.border(PlayerPalettes.current.edgeW.dp, SlateBorder, shape) else this
/** Frosted glass fill: white at ~18% over the gradient background. */
val GlassFill: Color get() = if (PlayerPalettes.current.clear) Color(0x12FFFFFF) else Color(0x2EFFFFFF)
/** True only for the Clear Glass theme (see-through cards + floating see-through bottom bar). */
val IsClear: Boolean get() = PlayerPalettes.current.clear
/** Kept so the tabs still compile: the bottom bar is docked in every theme now, so nothing needs extra space at the end of a tab. */
@Composable
fun ClearBarSpacer() { }
/** Screen background: a flowing blue / violet / cyan gradient for Liquid Glass, the plain theme colour for every other theme. */
val BgBrush: Brush get() = if (PlayerPalettes.current.clear)
    Brush.linearGradient(listOf(Color(0xFF050B24), Color(0xFF3A1B8F), Color(0xFF0B86B5), Color(0xFF7A1FA8), Color(0xFF071A4A)))
else if (PlayerPalettes.current.glass)
    Brush.linearGradient(listOf(Color(0xFF081433), Color(0xFF2A1A6B), Color(0xFF0A5C8C), Color(0xFF0B1F4D)))
else SolidColor(PlayerPalettes.current.bg)
/** Name box under a game card: the theme's card colour tinted with the theme accent, so it follows the chosen theme. */
val LabelC: Color get() = Purple   // same colour as the Home contest icons = the theme accent
val Coin = Color(0xFFFFA000)

/** Readable text / icon colour for ANY background: black on light colours (gold, neon green, cyan, pink...), white on dark ones. Use it whenever text sits on a theme colour. */
fun onC(bg: Color): Color {
    if (bg.alpha < 0.9f) return Color.White   // translucent (Liquid Glass) sits on a dark gradient
    fun lin(c: Float) = if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    val l = 0.2126f * lin(bg.red) + 0.7152f * lin(bg.green) + 0.0722f * lin(bg.blue)
    return if (1.05f / (l + 0.05f) >= (l + 0.05f) / 0.05f) Color.White else Color.Black
}
/**
 * Colour of the wallet ("coin") icon on a theme colour: WHITE on red / orange / blue / purple / dark colours (e.g. the red fire theme),
 * black only on really light colours (silver, gold, cyan, neon) where white would not be readable. Text keeps using [onC].
 */
fun walletIconC(bg: Color): Color {
    if (bg.alpha < 0.9f) return Color.White
    fun lin(c: Float) = if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
    val l = 0.2126f * lin(bg.red) + 0.7152f * lin(bg.green) + 0.0722f * lin(bg.blue)
    return if (l < 0.35f) Color.White else Color.Black
}
/** Text colour on the theme's button colour / accent colour. */
val OnButton: Color get() = onC(PlayerPalettes.current.button)
val OnAccent: Color get() = onC(PlayerPalettes.current.accent)

/** Remembers the last theme on the phone so the splash / login screens already use it on the very first frame. */
object ThemeCache {
    private const val PREF = "theme_cache"
    private val customKeys = listOf("themeBg", "themeCard", "themeField", "themeAccent", "themeButton", "themeMatch", "themeSupport", "themeWarning", "themeDanger", "themeSuccess")

    fun load(ctx: Context) {
        try {
            val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val id = sp.getString("id", "").orEmpty()
            PlayerPalettes.mainCard = PlayerPalettes.parseMain(sp.getString("themeMain", null))
            if (FORCE_LIQUID_GLASS) { PlayerPalettes.current = PlayerPalettes.get("liquid_glass"); return }
            if (id.isBlank()) return
            PlayerPalettes.current = if (id == "custom") PlayerPalettes.custom(customKeys.associateWith { sp.getString(it, null) }) else PlayerPalettes.get(id)
        } catch (_: Exception) { }
    }

    fun save(ctx: Context, id: String, settings: Map<String, Any?>) {
        try {
            val e = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("id", id).putString("themeMain", settings["themeMain"]?.toString())
            if (id == "custom") customKeys.forEach { k -> e.putString(k, settings[k]?.toString()) }
            e.apply()
        } catch (_: Exception) { }
    }
}

@Suppress("DEPRECATION")
private fun paintSystemBars(ctx: Context, p: PlayerPalette) {
    val w = ctx.findActivity()?.window ?: return
    try {
        w.statusBarColor = android.graphics.Color.TRANSPARENT
        w.navigationBarColor = android.graphics.Color.TRANSPARENT
        w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(p.bg.toArgb()))
    } catch (_: Exception) { }
}

@Composable
fun BestwinTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var uid by remember { mutableStateOf(Repo.uid()) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { uid = it.currentUser?.uid.orEmpty() }
        Repo.auth.addAuthStateListener(listener)
        onDispose { Repo.auth.removeAuthStateListener(listener) }
    }
    val personalTheme by rflow(uid, init = "") { if (uid.isBlank()) flowOf("") else Repo.playerTheme(uid) }
    val appSettings by rflow(init = emptyMap<String, Any?>()) { Repo.settings() }
    val loaded = appSettings.isNotEmpty()
    val selected = if (FORCE_LIQUID_GLASS) "liquid_glass" else personalTheme.ifBlank { appSettings["playerTheme"]?.toString().orEmpty().ifBlank { "royal_purple" } }
    // Until the settings arrive keep the cached theme (no purple flash); after that follow what the admin chose.
    val p = if (FORCE_LIQUID_GLASS) PlayerPalettes.get("liquid_glass") else if (!loaded) PlayerPalettes.current else if (selected == "custom") PlayerPalettes.custom(appSettings) else PlayerPalettes.get(selected)
    SideEffect {
        if (PlayerPalettes.current != p) PlayerPalettes.current = p
        if (loaded) { val m = PlayerPalettes.parseMain(appSettings["themeMain"]?.toString()); if (PlayerPalettes.mainCard != m) PlayerPalettes.mainCard = m }
        paintSystemBars(ctx, p)
        if (loaded) {
            ThemeCache.save(ctx, selected, appSettings)
        }
    }
    MaterialTheme(
        colorScheme = darkColorScheme(primary = p.accent, secondary = p.support, tertiary = p.orange, background = p.bg, surface = if (p.glass) Color(0xFF16295A) else p.card,
            onBackground = Color.White, onSurface = Color.White,
            // Default Material buttons / switches / checkmarks sit on the accent colour: pick black or white by brightness so gold, lime, cyan... themes stay readable.
            onPrimary = onC(p.accent), onSecondary = onC(p.support), onTertiary = onC(p.orange)),
        content = {
            // Text without its own colour must ALWAYS be light (default is black = invisible on every dark theme).
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.material3.LocalContentColor provides Color.White,
                content = content
            )
        }
    )
}

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun Context.findActivity(): android.app.Activity? {
    var c = this
    while (c is android.content.ContextWrapper) { if (c is android.app.Activity) return c; c = c.baseContext }
    return null
}

/** Pull down to refresh. onRefresh should restart the screen's data streams (bump a key used in rflow). */
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun PullRefresh(onRefresh: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val state = rememberPullRefreshState(refreshing = refreshing, onRefresh = {
        if (!refreshing) {
            refreshing = true
            kickFirebase()
            val startedBefore = RefreshTracker.started.intValue
            val arrivedBefore = RefreshTracker.arrived.intValue
            val t0 = System.currentTimeMillis()
            onRefresh()
            // The spinner now stays until the restarted data streams have REALLY delivered fresh data (at most 5 s, at least 0.8 s so it is always noticed).
            scope.launch {
                try {
                    delay(250)   // let the restarted streams register
                    val need = RefreshTracker.started.intValue - startedBefore
                    if (need > 0) kotlinx.coroutines.withTimeoutOrNull(5000) {
                        androidx.compose.runtime.snapshotFlow { RefreshTracker.arrived.intValue - arrivedBefore }.first { it >= need }
                    }
                    val spent = System.currentTimeMillis() - t0
                    if (spent < 800) delay(800 - spent)
                } finally { refreshing = false }
            }
        }
    })
    Box(modifier.pullRefresh(state)) {
        content()
        PullRefreshIndicator(
            refreshing = refreshing,
            state = state,
            modifier = Modifier.align(Alignment.TopCenter),
            backgroundColor = Color.White,
            contentColor = Color.Black,
            scale = true
        )
    }
}

/** Counts data streams (re)started by rflowKeep and how many of them have delivered their first value, so pull-to-refresh can wait for real data. */
object RefreshTracker {
    val started = androidx.compose.runtime.mutableIntStateOf(0)
    val arrived = androidx.compose.runtime.mutableIntStateOf(0)
}

/** Makes sure the Firebase connection is up (helps after a bad network); harmless when already online. */
fun kickFirebase() { try { com.google.firebase.database.FirebaseDatabase.getInstance().goOnline() } catch (_: Exception) { } }

/** Like rflow, but when the key changes (pull-to-refresh) the OLD data stays on screen until the new data arrives, so the page never blanks or flashes a loader. */
@Composable
fun <T> rflowKeep(vararg k: Any?, init: T, f: () -> Flow<T>): State<T> {
    val last = remember { mutableStateOf(init) }
    val fl = remember(k.toList()) { f() }
    LaunchedEffect(fl) {
        RefreshTracker.started.intValue++
        var first = true
        try {
            fl.collect { last.value = it; if (first) { first = false; RefreshTracker.arrived.intValue++ } }
        } finally {
            // a stream that ends (or is replaced) before it ever delivered must not keep the refresh spinner waiting
            if (first) RefreshTracker.arrived.intValue++
        }
    }
    return last
}

@Composable
fun <T> rflow(vararg k: Any?, init: T, f: () -> Flow<T>): State<T> {
    val fl = remember(k.toList()) { f() }
    return fl.collectAsState(init)
}

@Composable
fun RotatingLoadingLogo(size: Int = 76, modifier: Modifier = Modifier) {
    val logoRef by rflow(init = "") { Repo.setting("loadingLogo") }
    val remoteUrl = logoRef.takeIf { it.startsWith("tgimg:") || it.startsWith("dbimg:") || it.startsWith("http://") || it.startsWith("https://") }
        ?.let { BackendConfig.resolve(it) }
    val transition = rememberInfiniteTransition(label = "loading-logo")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1400, easing = LinearEasing)),
        label = "loading-logo-rotation"
    )
    Box(modifier.size(size.dp).graphicsLayer { rotationZ = rotation }, contentAlignment = Alignment.Center) {
        // only the logo (round) spins - no ring around it
        Box(Modifier.fillMaxSize().clip(androidx.compose.foundation.shape.CircleShape), contentAlignment = Alignment.Center) {
            if (remoteUrl.isNullOrBlank()) {
                androidx.compose.foundation.Image(painterResource(R.drawable.bestwin_loading_logo), "Loading", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                androidx.compose.runtime.key(remoteUrl) {
                    AsyncImage(model = remoteUrl, contentDescription = "Loading", modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop, placeholder = null, error = painterResource(R.drawable.bestwin_loading_logo))
                }
            }
        }
    }
}

/**
 * In-screen "pages" (steps that are not separate nav routes, e.g. Select Position -> Joining Match -> Joined) get the SAME slide
 * as every other screen change in the app: forward = new page slides in from the right, back = it slides back out to the right.
 */
@Composable
fun <T> StepSlide(state: T, isForward: (from: T, to: T) -> Boolean, content: @Composable (T) -> Unit) {
    val ease = androidx.compose.animation.core.FastOutSlowInEasing
    androidx.compose.animation.AnimatedContent(
        targetState = state,
        modifier = Modifier.fillMaxSize(),
        transitionSpec = {
            if (isForward(initialState, targetState))
                (androidx.compose.animation.slideInHorizontally(tween(220, easing = ease)) { it } + androidx.compose.animation.fadeIn(tween(160))) togetherWith
                    (androidx.compose.animation.slideOutHorizontally(tween(220, easing = ease)) { -it / 4 } + androidx.compose.animation.fadeOut(tween(160)))
            else
                (androidx.compose.animation.slideInHorizontally(tween(220, easing = ease)) { -it / 4 } + androidx.compose.animation.fadeIn(tween(160))) togetherWith
                    (androidx.compose.animation.slideOutHorizontally(tween(220, easing = ease)) { it } + androidx.compose.animation.fadeOut(tween(160)))
        },
        label = "step-slide"
    ) { st -> Box(Modifier.fillMaxSize().background(BgBrush)) { content(st) } }
}

@Composable
fun StepSlide(step: Int, content: @Composable (Int) -> Unit) = StepSlide(step, { from, to -> to > from }, content)

/** Small checkbox (18-20 dp box, NO extra 48 dp touch padding around it) - the tap area is given by the row that holds it. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun CompactCheckbox(checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalMinimumInteractiveComponentEnforcement provides false) {
        androidx.compose.material3.Checkbox(checked, onChange, enabled = enabled,
            colors = androidx.compose.material3.CheckboxDefaults.colors(checkedColor = Orange, uncheckedColor = Orange))
    }
}

/** True after [ms] milliseconds - used so the logo loading page is always seen for a moment (premium feel) before a page appears. */
@Composable
fun rememberMinDelay(ms: Long = 450): Boolean {
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(ms); done = true }
    return done
}

/**
 * Full-page loader: only the spinning logo. It stays for as long as the data has not arrived (slow or no internet) and the page
 * continues by itself the moment the connection returns. After 10 seconds a small grey hint appears so it does not look frozen.
 */
@Composable
fun Loader() {
    var slow by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(10_000); slow = true }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RotatingLoadingLogo()
            if (slow) Text(tx("Waiting for internet connection..."), Modifier.padding(top = 16.dp), color = Color.Gray, fontSize = 12.sp)
        }
    }
}


// ---------------------------------------------------------------------------------------------------------------------
// Grey skeleton match cards (loading placeholder). Look measured from the reference screenshot (1080px wide = 360dp):
// card #3E3E3E, blocks #2F2F2F. Used by the match list, My Matches and the Player Match (PvP) pages.
// ---------------------------------------------------------------------------------------------------------------------
private val SkelCard = Color(0xFF3E3E3E)
private val SkelBlock = Color(0xFF2F2F2F)
private val SkelShine = Color(0xFF3A3A3A)

/** [count] grey placeholder match cards (same size / shape in every screen), with a very soft moving light sweep. */
@Composable
fun MatchSkeletonList(count: Int = 3, modifier: Modifier = Modifier.fillMaxSize()) {
    val t = rememberInfiniteTransition(label = "matchSkeleton")
    val x by t.animateFloat(
        initialValue = -400f, targetValue = 1400f, label = "matchSkeletonX",
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing))
    )
    val brush = Brush.linearGradient(
        listOf(SkelBlock, SkelShine, SkelBlock),
        start = androidx.compose.ui.geometry.Offset(x, 0f), end = androidx.compose.ui.geometry.Offset(x + 400f, 200f)
    )
    @Composable fun Blk(mod: Modifier, radius: Int = 0) = Box(mod.clip(RoundedCornerShape(radius.dp)).background(brush))
    Column(modifier.verticalScroll(rememberScrollState(), enabled = false).padding(horizontal = 5.dp).padding(top = 12.dp)) {
        repeat(count) {
            Column(Modifier.fillMaxWidth().padding(bottom = 11.dp).height(237.dp).clip(RoundedCornerShape(10.dp)).background(SkelCard)) {
                // picture + title + sub-title
                Row(Modifier.padding(start = 18.dp, end = 14.dp, top = 14.dp)) {
                    Blk(Modifier.size(55.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Blk(Modifier.fillMaxWidth().height(28.dp))
                        Spacer(Modifier.height(14.dp))
                        Blk(Modifier.fillMaxWidth(0.733f).height(18.dp))
                    }
                }
                Spacer(Modifier.height(23.dp))
                // 2 rows x 3 info boxes
                repeat(2) { r ->
                    if (r == 1) Spacer(Modifier.height(19.dp))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp), horizontalArrangement = Arrangement.spacedBy(19.dp)) {
                        repeat(3) { Blk(Modifier.weight(1f).height(23.dp)) }
                    }
                }
                Spacer(Modifier.height(18.dp))
                // bottom: two bars (left) + button (right)
                Row(Modifier.fillMaxWidth().padding(start = 23.dp, end = 18.dp)) {
                    Column(Modifier.weight(1f).padding(top = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Blk(Modifier.fillMaxWidth().height(9.dp))
                        Spacer(Modifier.height(5.dp))
                        Blk(Modifier.fillMaxWidth(0.86f).height(14.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Blk(Modifier.size(width = 91.dp, height = 46.dp), radius = 5)
                }
            }
        }
    }
}

/**
 * True for a moment (default 300 ms) every time [key] changes, so a tap on a game / tab first shows the grey skeleton cards and only then the list
 * (or the "No Match Found" text). [showFirst]: also show it when the page first opens (pages that already have their own opening skeleton pass false).
 */
@Composable
fun rememberTapSkeleton(key: Any, showFirst: Boolean, ms: Long = 300L): Boolean {
    var show by remember { mutableStateOf(showFirst) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(key) {
        if (first) {
            first = false
            if (showFirst) { delay(ms); show = false }
            return@LaunchedEffect
        }
        show = true; delay(ms); show = false
    }
    return show
}

/** Full page of skeleton cards under a title bar (+ optional tabs): replaces the old spinning-logo loader on the match pages. */
@Composable
fun SkeletonPage(title: String, nav: NavController, tabs: Boolean = true, showBalance: Boolean = false, banner: (@Composable () -> Unit)? = null) {
    Column(Modifier.fillMaxSize()) {
        BackBar(title, nav, showBalance = showBalance, maskBalance = showBalance)
        if (tabs) TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), -1) { }
        banner?.invoke()
        MatchSkeletonList()
    }
}

@androidx.media3.common.util.UnstableApi
@Composable
fun SplashScreen(nav: NavController) {
    val ctx = LocalContext.current.applicationContext
    // Everything is decided from what is saved on the phone, so the start screen never waits for the internet and never flips while open.
    val videoFile = remember { SplashVideo.playable(ctx) }
    val showImage = remember { SplashVideo.imageOn(ctx) }
    val showLogo = remember { SplashVideo.logoOn(ctx) }
    var bmp by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var left by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val fadeOut = remember { androidx.compose.animation.core.Animatable(0f) }
    fun goNext() {
        if (left) return
        left = true
        nav.navigate(if (Repo.auth.currentUser != null) "main" else "lang") { popUpTo("splash") { inclusive = true } }
    }
    /** Video ended / skipped / failed: a short fade to black, then the next page (no jump). */
    var stopped by remember { mutableStateOf(false) }
    fun finishVideo() {
        if (left || stopped) return
        stopped = true                                   // sound + picture stop immediately, the fade is only cosmetic
        scope.launch { fadeOut.animateTo(1f, androidx.compose.animation.core.tween(200)); goNext() }
    }
    var videoStarted by remember { mutableStateOf(false) }
    var videoMs by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        SplashVideo.refreshAsync(ctx)          // background: latest admin settings + video download for the next start
        if (videoFile != null) return@LaunchedEffect
        val t0 = System.currentTimeMillis()
        ImgCache.warm(ctx)
        if (showImage) { try { ImgCache.loadSplash(ctx) { bmp = it } } catch (_: Exception) { } }
        val wait = 1500 - (System.currentTimeMillis() - t0)
        if (wait > 0) delay(wait)
        goNext()
    }
    if (videoFile != null) {
        // Allow slower phones a little longer to initialize a locally cached video.
        LaunchedEffect(Unit) { delay(12_000); if (!videoStarted) finishVideo() }
        LaunchedEffect(videoStarted, videoMs) { if (videoStarted) { delay(videoMs + 3000L); finishVideo() } }
    }
    Box(Modifier.fillMaxSize()) {
        if (videoFile != null) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                SplashVideoPlayer(videoFile, stopped, onStarted = { ms -> videoMs = ms; videoStarted = true }, onDone = { finishVideo() })
                if (!videoStarted) CircularProgressIndicator(Modifier.align(Alignment.Center).size(34.dp), color = Color.White, strokeWidth = 3.dp)
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = fadeOut.value }.background(Color.Black))
                Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(14.dp).clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.45f)).border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(50))
                    .clickable { finishVideo() }.padding(horizontal = 16.dp, vertical = 7.dp)) {
                    Text(tx("SKIP"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().background(Brush.verticalGradient(listOf(CardC, Bg)))) {
                val shown = if (showImage) bmp else null
                if (shown != null) {
                    // The WHOLE picture is shown (nothing is cut at the sides, any phone shape). The strip left over at the
                    // top / bottom (or sides) is filled by a soft blurred copy of the same picture, so it looks full screen.
                    Box(Modifier.fillMaxSize().background(Color.Black))
                    Image(shown, null, Modifier.fillMaxSize().blur(12.dp), contentScale = ContentScale.Crop, alpha = 0.65f)
                    Image(shown, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                if (showLogo) RotatingLoadingLogo(size = 100, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

/** Full-screen, lifecycle-aware player for the locally cached start-screen video. */
@androidx.media3.common.util.UnstableApi
@Composable
private fun SplashVideoPlayer(file: java.io.File, stopped: Boolean, onStarted: (Int) -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val lifecycle = androidx.compose.ui.platform.LocalLifecycleOwner.current.lifecycle
    val currentOnStarted by rememberUpdatedState(onStarted)
    val currentOnDone by rememberUpdatedState(onDone)
    val currentStopped by rememberUpdatedState(stopped)
    val player = remember(file.absolutePath) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file)))
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
            prepare()
        }
    }
    DisposableEffect(player, lifecycle) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    androidx.media3.common.Player.STATE_READY -> {
                        val durationMs = player.duration.takeIf { it > 0L } ?: 1_000L
                        currentOnStarted(durationMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
                        if (!currentStopped) player.playWhenReady = true
                    }
                    androidx.media3.common.Player.STATE_BUFFERING, androidx.media3.common.Player.STATE_IDLE -> Unit
                    androidx.media3.common.Player.STATE_ENDED -> currentOnDone()
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) { currentOnDone() }
        }
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> player.pause()
                androidx.lifecycle.Lifecycle.Event.ON_RESUME -> if (!currentStopped) player.play()
                else -> Unit
            }
        }
        player.addListener(listener)
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            player.removeListener(listener)
            try { player.stop() } catch (_: Exception) { }
            player.release()
        }
    }
    LaunchedEffect(stopped) { if (stopped) { try { player.volume = 0f; player.pause() } catch (_: Exception) { } } }
    androidx.compose.ui.viewinterop.AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            androidx.media3.ui.PlayerView(c).apply {
                useController = false
                resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                setShutterBackgroundColor(android.graphics.Color.BLACK)
                this.player = player
            }
        },
        update = { it.player = player }
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, color: Color = ButtonC, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick, modifier.height(44.dp), enabled = enabled, shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        border = if (IsSlate) androidx.compose.foundation.BorderStroke(1.dp, SlateBtnBorder) else null,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = onC(color))) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun Input(v: String, onV: (String) -> Unit, hint: String, pw: Boolean = false,
          kb: KeyboardType = KeyboardType.Text, modifier: Modifier = Modifier) {
    TextField(v, onV, modifier.fillMaxWidth().padding(vertical = 4.dp),
        placeholder = { Text(hint, color = Color.White.copy(alpha = .85f), fontSize = 14.sp) }, singleLine = true,
        textStyle = TextStyle(fontSize = 14.sp), shape = RoundedCornerShape(26.dp),
        visualTransformation = if (pw) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        colors = TextFieldDefaults.colors(focusedContainerColor = Field, unfocusedContainerColor = Field,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Color.White))
}

@Composable
fun LineField(v: String, onV: (String) -> Unit, label: String, modifier: Modifier = Modifier, enabled: Boolean = true,
              pw: Boolean = false, kb: KeyboardType = KeyboardType.Text) {
    var show by remember { mutableStateOf(false) }
    TextField(v, onV, modifier.fillMaxWidth(), enabled = enabled, singleLine = true,
        label = { Text(label, fontSize = 13.sp) }, textStyle = TextStyle(fontSize = 15.sp),
        visualTransformation = if (pw && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        trailingIcon = if (pw) { { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, Modifier.clickable { show = !show }) } } else null,
        colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent, focusedIndicatorColor = Color.Gray, unfocusedIndicatorColor = Color.Gray,
            disabledIndicatorColor = Color.DarkGray, focusedLabelColor = Color.Gray, unfocusedLabelColor = Color.Gray,
            disabledLabelColor = Color.Gray, focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            disabledTextColor = Color.LightGray, cursorColor = Color.White))
}

@Composable
fun BackBar(title: String, nav: NavController, showBalance: Boolean = false, maskBalance: Boolean = false) {
    Row(Modifier.fillMaxWidth().background(AccountC).statusBarsPadding().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(22.dp).clickable { nav.back() })
        Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        if (showBalance) BalanceChip(Modifier.offset(x = 4.dp), masked = maskBalance)
    }
}

/** Wallet balance in the top-right corner of a bar: white rounded box, coin + amount (fixed look, same in every theme). */
@Composable
fun BalanceChip(modifier: Modifier = Modifier, masked: Boolean = false) {
    val user by rflow(init = User()) { Repo.me() }
    Row(modifier.clip(RoundedCornerShape(6.dp)).background(Color.White).padding(horizontal = 5.5.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        CoinIcon(15)
        Spacer(Modifier.width(6.5.dp))
        Text(if (masked) "# #" else fmt(user.balance()), color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** The app coin (gold coin image supplied by the owner: res/drawable-nodpi/coin_c.png). */
@Composable
fun CoinIcon(size: Int = 18) {
    androidx.compose.foundation.Image(painterResource(R.drawable.coin_c), null, Modifier.size(size.dp))
}

@Composable
fun Tag(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(5.dp)).background(color).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
    }
}

/** White "raised" card look: a grey lip under the card makes it look lifted off the page. */
fun Modifier.raised(radius: androidx.compose.ui.unit.Dp = 5.dp): Modifier = this
    .drawBehind {
        drawRoundRect(Color(0xFFB5B5B5), topLeft = androidx.compose.ui.geometry.Offset(0f, 3.dp.toPx()), size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius.toPx()))
    }
    .clip(RoundedCornerShape(radius))

@Composable
fun Chip(text: String) {
    Box(Modifier.raised().background(Color.White).padding(horizontal = 8.dp, vertical = 6.dp)) {
        Text(text, color = Color.Black, fontSize = 12.sp)
    }
}

@Composable
fun TabsRow(tabs: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        tabs.forEachIndexed { i, t ->
            Box(Modifier.weight(1f).clickable { onSel(i) }.padding(vertical = 11.dp), contentAlignment = Alignment.Center) {
                Text(t, color = if (i == sel) Orange else Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            }
        }
    }
}

/** Small live-count badge for a game tile (top-right of the picture): green dot when the game has matches (upcoming + ongoing), red dot when it has none, with the number beside it. */
@Composable
fun MatchCountBadge(count: Int, modifier: Modifier = Modifier) {
    val dot = if (count > 0) Color(0xFF2ECC71) else Color(0xFFE01B10)
    // Gentle "breathing" pulse: the dot (and the number a little) grows a bit and shrinks back, forever.
    val pulse = rememberInfiniteTransition(label = "count-badge")
    val dotScale by pulse.animateFloat(0.75f, 1.3f, infiniteRepeatable(tween(750, easing = androidx.compose.animation.core.FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse), label = "dot")
    val numScale by pulse.animateFloat(0.95f, 1.12f, infiniteRepeatable(tween(750, easing = androidx.compose.animation.core.FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse), label = "num")
    Row(modifier.padding(top = 5.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).graphicsLayer { scaleX = dotScale; scaleY = dotScale }.clip(CircleShape).background(dot))
        Spacer(Modifier.width(9.dp))
        Text(count.toString(), Modifier.graphicsLayer { scaleX = numScale; scaleY = numScale }, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black, androidx.compose.ui.geometry.Offset(0f, 0f), 6f)))
    }
}

@Composable
fun SectionTitle(title: String, sub: String, badge: String? = null, icon: String? = null) {
    // Home headings (IMPORTANT / EXCLUSIVE / MY CONTESTS): smaller, normal-size text like the reference video (13 sp title, 10 sp subtitle).
    Column(Modifier.padding(top = 14.dp, bottom = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = HomeRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(5.dp))
            if (icon != null) Box(Modifier.size(13.dp).clip(if (icon == "box") RoundedCornerShape(3.dp) else CircleShape).background(HomeFill), contentAlignment = Alignment.Center) {
                Icon(if (icon == "info") Icons.Default.PriorityHigh else Icons.Default.Check, null, Modifier.size(10.dp), tint = Color.White)
            }
            if (badge != null) Box(Modifier.clip(RoundedCornerShape(3.dp)).background(Color(0xFF5B1020)).padding(horizontal = 4.dp)) {
                Text(badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(sub, color = Color.Gray, fontSize = 10.sp)
    }
}

@Composable
fun HeaderBar(nav: NavController, u: User, earnTab: Boolean = false) {
    val ctx = LocalContext.current
    val globeLink by rflow(init = "") { Repo.setting("globeLink") }
    val shareText by rflow(init = "") { Repo.setting("shareText") }
    val chatOn by rflow(init = "") { Repo.setting("worldChatOn") }
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar("", u.username, 29)   // smaller profile picture (29 dp, measured from the reference screenshot)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(tx("Welcome Back,"), fontWeight = FontWeight.Medium, fontSize = 12.sp, maxLines = 1)
            Text("DOUx24", color = Purple, fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1)
        }
        if (earnTab) {
            Icon(Icons.Outlined.Share, null, tint = Color.White, modifier = Modifier.size(28.dp).clickable {
                shareApp(ctx, brandAppName(shareText.ifBlank { tx("DOUx24 Platform\nPlay Daily Matches & Win Big Prizes.") }))
            })
        } else if (chatOn.trim().equals("true", true)) {
            ChatHeaderIcon(nav)   // World chat is ON: its round icon (with the red number of new messages) takes the place of the globe
        } else {
            Icon(Icons.Outlined.Language, null, tint = Color.White, modifier = Modifier.size(28.dp).clickable { ctx.openLink(globeLink, nav = nav) })
        }
        Spacer(Modifier.width(14.dp))
        Icon(Icons.Default.Headset, null, tint = Color.White, modifier = Modifier.size(28.dp).clickable { nav.go("support") })
        Spacer(Modifier.width(10.dp))
        // Wallet box sized like the reference video: same box height (31dp), bigger wallet icon, 14sp amount, wider gaps.
        // Wallet box colour follows the theme; wallet icon, amount, divider line and "+" stay white in every theme (Earn / Play / Account all use this header).
        Row(Modifier.height(31.dp).clip(RoundedCornerShape(5.dp)).background(HomeFill).clickable { nav.go("wallet") }
            .padding(start = 4.dp, end = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AccountBalanceWallet, null, tint = Color.White, modifier = Modifier.size(31.dp))
            Spacer(Modifier.width(8.dp))
            Text(fmt(u.balance()), fontWeight = FontWeight.Normal, fontSize = 14.sp, color = Color.White)
            Spacer(Modifier.width(12.dp))
            Box(Modifier.width(1.dp).height(16.dp).background(Color.White))
            Spacer(Modifier.width(10.dp))
            Text("+", fontWeight = FontWeight.Normal, fontSize = 16.sp, color = Color.White, modifier = Modifier.clickable { nav.go("addmoney") })
        }
    }
}

@Composable
fun Avatar(url: String, name: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Field), contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Image(painterResource(R.drawable.default_avatar), name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

/** The app logo in a circle (used only on the profile). Uses the admin-set logo, otherwise the built-in DOUx24 logo. */
@Composable
fun ProfileLogo(url: String, size: Int) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color.Black).border(2.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Image(painterResource(R.drawable.bestwin_logo), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val labels = listOf(tr("tab_earn"), tr("tab_play"), tr("tab_account"))
    val slate = IsSlate
    val clear = IsClear   // Clear Glass: docked too, dark glass-coloured fill + thin light edge on top
    // Docked bar in EVERY theme: touches the left, right and bottom edges of the screen (its fill also runs under the system gesture/nav area);
    // slate themes get a thin edge line on top, other themes keep the plain black bar.
    val barFill = PlayerPalettes.current.barFill
    val barBrush = if (slate) {
        if (barFill != null) Brush.horizontalGradient(listOf(barFill, barFill))
        else Brush.horizontalGradient(listOf(Color(0xFF2A2E3C), Color(0xFF1C2030), Color(0xFF2A2E3C)))
    } else if (clear) Brush.horizontalGradient(listOf(Color(0xFF071236), Color(0xFF071236)))
    else Brush.horizontalGradient(listOf(Color.Black, Color.Black))
    val edgeColor = if (clear) Color.White.copy(alpha = 0.25f) else SlateBtnBorder
    val outer = Modifier.fillMaxWidth().background(barBrush)
        .then(if (slate || clear) Modifier.drawBehind { drawLine(edgeColor, androidx.compose.ui.geometry.Offset(0f, 0f), androidx.compose.ui.geometry.Offset(size.width, 0f), strokeWidth = 1.dp.toPx()) } else Modifier)
        .navigationBarsPadding()
    val rowMod = Modifier.fillMaxWidth().padding(top = if (slate || clear) 8.dp else 6.dp, bottom = if (slate || clear) 6.dp else 4.dp)
    Box(outer) {
        Row(rowMod) {
            labels.forEachIndexed { i, label ->
                val c = if (i == sel) (if (slate || clear) Purple else Color.White) else (if (slate) Color(0xFF9AA3B5) else if (clear) Color.White.copy(alpha = 0.75f) else Color.Gray)
                Column(Modifier.weight(1f).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    when (i) {
                        0 -> CoinIcon(21)   // gold coin picture above "Earn" (same coin_c image used everywhere)
                        1 -> Icon(Icons.Default.SportsEsports, null, tint = c, modifier = Modifier.size(24.dp))
                        else -> Icon(Icons.Default.Person, null, tint = c, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.height(0.dp))
                    Text(label, color = c, fontSize = 17.sp, fontWeight = if (i == sel) FontWeight.Medium else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun MenuRow(icon: ImageVector, title: String, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.padding(horizontal = 14.dp, vertical = 3.dp).fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(AccountC).slateEdge(RoundedCornerShape(6.dp))
        .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(22.dp)); Spacer(Modifier.width(14.dp))
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        if (trailing != null) trailing() else Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, Modifier.size(20.dp))
    }
}

@Composable
fun linkOpener(nav: NavController): (String) -> Unit {
    val ctx = LocalContext.current
    return { l -> if (l.isNotBlank()) ctx.openLink(l, nav = nav) }
}

private val schemeRegex = Regex("^([A-Za-z][A-Za-z0-9+.-]*://.*|(mailto|tel|sms|upi|geo|market|whatsapp|tg):.*)$")

/**
 * Turns whatever the admin typed into something Android can open.
 * kind: auto / instagram / telegram / whatsapp / email / phone. Accepts links, @usernames, numbers and e-mail addresses.
 */
fun resolveLink(raw: String, kind: String = "auto"): String {
    val v = raw.trim()
    val low = v.lowercase()
    if (schemeRegex.matches(v)) return v
    return when (kind) {
        "instagram" -> if (low.contains("instagram.com")) "https://" + v.removePrefix("//") else "https://www.instagram.com/" + v.removePrefix("@").trim('/')
        "telegram" -> if (low.contains("t.me/") || low.contains("telegram.me/")) "https://" + v else "https://t.me/" + v.removePrefix("@").trim('/')
        "whatsapp" -> if (low.contains("wa.me") || low.contains("whatsapp.com")) "https://" + v else "https://wa.me/" + v.filter { it.isDigit() }
        "email" -> "mailto:$v"
        "phone" -> "tel:" + v.filter { it.isDigit() || it == '+' }
        else -> when {
            v.startsWith("@") -> "https://t.me/" + v.removePrefix("@")
            v.contains("@") && !v.contains("/") -> "mailto:$v"
            Regex("^[+0-9 ()-]{7,}$").matches(v) -> "tel:" + v.filter { it.isDigit() || it == '+' }
            else -> "https://$v"
        }
    }
}

/** Opens a link safely (never crashes when no app can handle it). "app:route" opens a screen inside the app. */
fun Context.openLink(raw: String, kind: String = "auto", nav: NavController? = null) {
    val v = raw.trim()
    if (v.isEmpty()) { toast(tx("Link not added yet")); return }
    if (v.startsWith("app:")) { nav?.navigate(v.removePrefix("app:")); return }
    try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(resolveLink(v, kind))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: Exception) { toast(tx("Could not open the link")) }
}

/**
 * Share the app text. packages = null -> normal system share sheet; otherwise it is sent straight to the first installed app
 * in the list (e.g. WhatsApp / Instagram / Telegram). If none is installed the system share sheet opens instead.
 * Nothing here uses links from the admin panel - only the share text (Admin -> Settings -> share text).
 */
fun shareApp(ctx: Context, text: String, vararg packages: String) {
    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    for (pkg in packages) {
        try { ctx.startActivity(Intent(send).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) { }
    }
    try {
        if (packages.isNotEmpty()) ctx.toast(tx("App not installed. Choose another app to share."))
        ctx.startActivity(Intent.createChooser(send, tx("Share")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { ctx.toast(tx("Could not open the link")) }
}

/** ONE colour for the Home Ongoing / Upcoming / Completed boxes AND the Announcement cards: whenever the boxes change colour (theme), the announcement cards change with them. */
val HomeBoxC: Color get() = glassOr(Color(0xFF190236))

/** Title bars of the My Referrals / My Rewards cards: PERMANENT #190236 (never changes with the theme). */
val SummaryHeaderC = Color(0xFF190236)

/** White summary card used by My Referrals / My Rewards */
@Composable
fun SummaryCard(title: String, left: Pair<String, String>, right: Pair<String, String>, coin: Boolean = true) {
    Column(Modifier.padding(14.dp, 12.dp, 14.dp, 0.dp).fillMaxWidth().clip(RoundedCornerShape(6.dp))) {
        Text(title, Modifier.fillMaxWidth().background(SummaryHeaderC).padding(12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
        Row(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 14.dp)) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(left.first, color = Color(0xFF333333), fontSize = 14.sp); Text(left.second, color = Color(0xFF333333), fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(right.first, color = Color(0xFF333333), fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) { if (coin) { CoinIcon(16); Spacer(Modifier.width(4.dp)) }; Text(right.second, color = Color(0xFF333333), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun TableCard(title: String, headers: List<String>, rows: List<List<String>>, empty: String) {
    Column(Modifier.padding(14.dp, 14.dp, 14.dp, 0.dp).fillMaxWidth().clip(RoundedCornerShape(6.dp))) {
        Text(title, Modifier.fillMaxWidth().background(SummaryHeaderC).padding(12.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
        Row(Modifier.fillMaxWidth().background(Color(0xFF343A40)).padding(vertical = 10.dp)) {
            headers.forEach { Text(it, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
        }
        Column(Modifier.fillMaxWidth().background(Color.White)) {
            if (rows.isEmpty()) Text(empty, Modifier.fillMaxWidth().padding(14.dp), color = Color(0xFF333333), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold)
            rows.forEach { r -> Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                r.forEach { Text(it, Modifier.weight(1f), color = Color(0xFF333333), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 13.sp) } } }
        }
    }
}


/**
 * The one popup card used everywhere in the app: white card, black title bar, dark CANCEL and teal action button.
 * Pass dismissText = null for a single-button popup.
 */
@Composable
fun AppDialog(
    title: String, onDismiss: () -> Unit, confirmText: String, onConfirm: () -> Unit,
    dismissText: String? = null, onDismissClick: () -> Unit = onDismiss, confirmEnabled: Boolean = true, cancelable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(dismissOnBackPress = cancelable, dismissOnClickOutside = cancelable, usePlatformDefaultWidth = false)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 36.dp).clip(RoundedCornerShape(4.dp)).background(Color.White).padding(14.dp)) {
            Box(Modifier.fillMaxWidth().background(Color.Black).padding(vertical = 18.dp, horizontal = 8.dp), contentAlignment = Alignment.Center) {
                Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 12.dp)) {
                androidx.compose.runtime.CompositionLocalProvider(LocalContentColor provides Color.Black) { content() }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                if (dismissText != null) DialogButton(dismissText, dialogCancelColor(), true, onDismissClick, Modifier.weight(1f))
                DialogButton(confirmText, Color(0xFF5CCFB3), confirmEnabled, onConfirm, Modifier.weight(1f))
            }
        }
    }
}

/**
 * Cancel button colour for the WHITE dialogs. The theme's card colour is see-through (Liquid Glass) or can be light
 * (custom theme), and on a white dialog that made the button and its white text vanish. So: use the theme colour only
 * when it is solid and dark; otherwise a fixed dark colour. The text is always readable on it.
 */
private fun dialogCancelColor(): Color {
    val c = BarC
    return if (c.alpha < 0.95f || onC(c) == Color.Black) Color(0xFF1B0035) else c
}

@Composable
private fun DialogButton(text: String, color: Color, enabled: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(modifier.height(52.dp).shadow(3.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))
        .background(if (enabled) color else color.copy(alpha = .5f)).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(horizontal = 6.dp))
    }
}


/** Click with a small "press" animation (scales down slightly while the finger is down) - makes taps feel premium. */
fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.95f else 1f, androidx.compose.animation.core.tween(110), label = "press")
    this.graphicsLayer { scaleX = sc; scaleY = sc }.clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/**
 * Empty list text for Ongoing / Upcoming / Results: white, bold, centred in the middle of the screen.
 * status = "ongoing" | "upcoming" | "completed".
 */
@Composable
fun EmptyMatches(status: String) {
    val msg = when (status) { "ongoing" -> "No Live Match Found."; "completed" -> "No Completed Match Found."; else -> "No Upcoming Match Found." }
    Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), contentAlignment = Alignment.Center) {
        Text(tx(msg), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}
