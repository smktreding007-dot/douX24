package com.bestwinesport.app

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging
import java.io.ByteArrayOutputStream
import com.google.firebase.database.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlin.coroutines.resume

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: DatabaseReference get() = FirebaseDatabase.getInstance().reference
    fun uid() = auth.currentUser?.uid ?: ""
    fun depositRequests() = watch(db.child("depositRequests").child(uid())) { s ->
        s.children.mapNotNull { c -> c.safe(DepositReq::class.java)?.also { it.id = c.key ?: "" } }.sortedByDescending { it.ts }
    }

    /** Manual UPI deposit: the player pays the admin's UPI ID/QR and sends the UTR; the admin approves it in the admin app. */
    suspend fun submitDeposit(amount: Double, utr: String, username: String, proof: String): String? {
        val uid = uid()
        if (uid.isBlank()) return tx("Please sign in first")
        val clean = utr.trim().uppercase()
        if (clean.isNotEmpty() && !Regex("^[A-Z0-9]{8,30}$").matches(clean)) return tx("Enter a valid UTR / transaction ID")
        if (proof.isBlank()) return tx("Attach the payment screenshot")
        try {
            val id = db.child("depositRequests/$uid").push().key!!
            val ups = HashMap<String, Any?>()
            ups["depositRequests/$uid/$id"] = mapOf("uid" to uid, "username" to username, "amount" to amount, "utr" to clean, "hasProof" to true, "status" to "pending", "ts" to System.currentTimeMillis())
            ups["depositProofs/$uid/$id"] = proof
            if (clean.isNotEmpty()) ups["depositUtrs/$clean"] = id
            db.updateChildren(ups).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
            return if ((e.message ?: "").contains("permission", ignoreCase = true)) tx("This UTR was already used, or the request could not be saved") else e.message
        }
    }

    // Smooth scrolling: Firebase calls onDataChange on the MAIN thread. Parsing big snapshots (matches, games, banners...) there
    // froze swipes and scrolls. Now only the raw snapshot is handed over here; the parsing runs on a background thread,
    // and if several updates arrive quickly only the newest one is parsed (conflate).
    internal fun <T> watch(q: Query, parse: (DataSnapshot) -> T): Flow<T> = callbackFlow<DataSnapshot> {
        val l = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { trySend(s) }
            override fun onCancelled(e: DatabaseError) { close(e.toException()) }
        }
        q.addValueEventListener(l)
        awaitClose { q.removeEventListener(l) }
    }.conflate().map { parse(it) }.flowOn(kotlinx.coroutines.Dispatchers.Default).catch { }

    /** Like DataSnapshot.getValue(cls) but a record with a wrong field type returns null instead of throwing (one bad record must not stop a whole list / screen). */
    internal fun <T : Any> DataSnapshot.safe(cls: Class<T>): T? = try { getValue(cls) } catch (e: Exception) { null }

    // ---------- Streams ----------
    fun appConfig() = watch(db.child("appConfig")) { s ->
        AppConfig(
            maintenance = s.child("maintenance").value == true,
            maintenanceMsg = s.child("maintenanceMsg").value?.toString() ?: "",
            updateOn = s.child("updateOn").value != false,
            latestCode = (s.child("latestCode").value as? Number)?.toLong() ?: 0L,
            minCode = (s.child("minCode").value as? Number)?.toLong() ?: 0L,
            latestName = s.child("latestName").value?.toString() ?: "",
            updateUrl = s.child("updateUrl").value?.toString() ?: "",
            updateNotes = s.child("updateNotes").value?.toString() ?: "",
            popupOn = s.child("popupOn").value == true,
            popupId = s.child("popupId").value?.toString() ?: "",
            popupTitle = s.child("popupTitle").value?.toString() ?: "",
            popupMsg = s.child("popupMsg").value?.toString() ?: "",
            popupSupport = s.child("popupSupport").value != false,
            popupImage = s.child("popupImage").value?.toString() ?: "",
            popupButton = s.child("popupButton").value?.toString() ?: "",
            popupAction = s.child("popupAction").value?.toString() ?: "none",
            popupLink = s.child("popupLink").value?.toString() ?: "",
            popupFreq = s.child("popupFreq").value?.toString() ?: "every_open"
        )
    }
    fun me() = watch(db.child("users").child(uid())) { it.safe(User::class.java) ?: User() }
    fun setting(k: String) = watch(db.child("settings").child(k)) { it.value?.toString() ?: "" }
    fun settings() = watch(db.child("settings")) { s -> s.children.mapNotNull { c -> c.key?.let { it to c.value } }.toMap() }
    fun playerTheme(uid: String) = watch(db.child("users").child(uid).child("theme")) { it.value?.toString() ?: "" }
    fun gameName(id: String) = watch(db.child("games").child(id).child("name")) { it.value?.toString() ?: "" }
    fun sections() = watch(db.child("sections")) { s ->
        s.children.mapNotNull { c -> c.safe(Section::class.java)?.also { it.id = c.key ?: "" } }.filter { it.active }.sortedBy { it.order }
    }
    fun games(section: String) = watch(db.child("games")) { s ->
        s.children.mapNotNull { c -> c.safe(Game::class.java)?.also { it.id = c.key!! } }
            .filter { it.active && (it.section == section || (section == "freefire" && (it.section.isBlank() || it.section == "private"))) }.sortedBy { it.order }
    }
    fun banners(section: String) = watch(db.child("banners")) { s ->
        s.children.mapNotNull { c -> c.safe(Banner::class.java)?.also { it.id = c.key!! } }
            .filter { it.active && it.section == section }.sortedBy { it.order }
    }
    fun matches(gameId: String) = watch(db.child("matches").orderByChild("gameId").equalTo(gameId)) { s ->
        s.children.mapNotNull { c -> c.safe(Match::class.java)?.also { it.id = c.key!! } }.filter { it.status != "cancelled" }.sortedBy { it.startTime }
    }
    fun match(id: String) = watch(db.child("matches").child(id)) { it.safe(Match::class.java)?.also { m -> m.id = id } }
    fun slots(id: String) = watch(db.child("matches/$id/slots")) { s ->
        s.children.mapNotNull { c -> c.safe(Slot::class.java)?.let { c.key!! to it } }.toMap()
    }
    /** Player edits the in-game name of his own slot (allowed while the match is still upcoming). Returns an error text or null. */
    suspend fun updateIgn(matchId: String, key: String, name: String): String? {
        val n = name.trim().take(30)
        if (n.isBlank()) return tx("Enter a valid name")
        return try { db.child("matches/$matchId/slots/$key/ign").setValue(n).await(); null } catch (e: Exception) { e.message ?: tx("Could not save") }
    }

    /** Results copy saved in this player's own history (used when the admin has deleted the match). */
    fun savedResults(id: String) = watch(db.child("joinedByUser/${uid()}/$id/results")) { s -> s.children.mapNotNull { it.safe(Res::class.java) } }
    /** In-game name(s) this player used in the match, saved in the player's own history when joining (used if the admin deletes the match without declaring a result). */
    fun savedNames(id: String) = watch(db.child("joinedByUser/${uid()}/$id/myNames")) { s -> s.children.mapNotNull { it.value?.toString()?.takeIf { n -> n.isNotBlank() } } }
    fun results(id: String) = watch(db.child("matches/$id/results")) { s -> s.children.mapNotNull { it.safe(Res::class.java) } }
    fun room(id: String) = watch(db.child("rooms/$id")) {
        (it.child("roomId").value?.toString() ?: "") to (it.child("roomPass").value?.toString() ?: "")
    }
    fun myMatchIds() = watch(db.child("joinedByUser").child(uid())) { s -> s.children.mapNotNull { it.key } }
    /**
     * All-time list of the matches this account joined. It lives in Firebase under joinedByUser/<uid>, so it comes back after
     * uninstalling / reinstalling / logging in on a new phone. A small copy of each match is saved too, so a match the admin
     * later deletes still stays in the player's Completed history.
     */
    fun myMatches() = watch(db.child("joinedByUser").child(uid())) { s -> s.children.mapNotNull { c -> c.key?.let { it to c.value } } }
        .map { entries ->
            // All matches are fetched at the same time (not one after another) so the list opens fast.
            coroutineScope { entries.map { (id, saved) -> async {
                val live = try { db.child("matches").child(id).get().await().getValue(Match::class.java)?.also { it.id = id } } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { null }
                if (live?.status == "cancelled") null   // cancelled matches are hidden everywhere in the player app (the refund shows in the wallet history)
                else if (live != null) {
                    // Keep a private copy (details + final results) in the player's own history so it survives the admin deleting the match.
                    val needCopy = saved !is Map<*, *> || (live.status == "completed" && !saved.containsKey("results"))
                    if (needCopy) try {
                        val snap = matchSnapshot(live).toMutableMap()
                        (saved as? Map<*, *>)?.get("myNames")?.let { snap["myNames"] = it }   // keep the player's own in-game name(s)
                        if (live.status == "completed") {
                            val rs = db.child("matches/$id/results").get().await().children.mapNotNull { it.safe(Res::class.java) }
                                .sortedWith(compareByDescending<Res> { it.prize }.thenByDescending { it.kills }).take(400)
                            if (rs.isNotEmpty()) snap["results"] = rs.map { mapOf("username" to it.username, "ign" to it.ign, "kills" to it.kills, "prize" to it.prize) }
                        }
                        db.child("joinedByUser/${uid()}/$id").setValue(snap).await()
                    } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { }
                    live
                } else (saved as? Map<*, *>)?.let { fromSnapshot(id, it) }
            } }.map { it.await() }.filterNotNull() }.sortedByDescending { it.startTime }
        }.catch { emit(emptyList()) }

    private fun matchSnapshot(m: Match): Map<String, Any?> = mapOf(
        "title" to m.title, "matchNo" to m.matchNo, "matchId" to m.matchId, "gameId" to m.gameId, "mode" to m.mode, "map" to m.map,
        "entryFee" to m.entryFee, "prizePool" to m.prizePool, "perKill" to m.perKill, "startTime" to m.startTime,
        "maxPlayers" to m.maxPlayers, "joined" to m.joined, "image" to m.image, "type" to m.type, "comment" to m.comment, "liveUrl" to m.liveUrl,
        "prizeDetails" to m.prizeDetails, "savedAt" to System.currentTimeMillis())

    private fun fromSnapshot(id: String, v: Map<*, *>): Match {
        fun str(k: String) = v[k]?.toString().orEmpty()
        fun num(k: String) = (v[k] as? Number)?.toDouble() ?: 0.0
        return Match(id = id, matchId = str("matchId"), gameId = str("gameId"), title = str("title"), matchNo = str("matchNo"),
            mode = str("mode").ifBlank { "Solo" }, map = str("map").ifBlank { "Bermuda" }, entryFee = num("entryFee"), prizePool = num("prizePool"),
            perKill = num("perKill"), startTime = num("startTime").toLong(), maxPlayers = num("maxPlayers").toLong().takeIf { it > 0 } ?: 48L,
            joined = num("joined").toLong(), image = str("image"), status = "completed", type = str("type").ifBlank { "PAID" }, comment = str("comment"),
            liveUrl = str("liveUrl"), prizeDetails = str("prizeDetails"), archived = true)
    }
    fun txs() = watch(db.child("transactions").child(uid()).orderByChild("ts").limitToLast(100)) { s ->
        s.children.mapNotNull { it.safe(Tx::class.java) }.sortedByDescending { it.ts }
    }
    fun lbPeriod() = watch(db.child("leaderboardConfig/period")) { s -> s.safe(String::class.java)?.takeIf { it in setOf("daily", "weekly", "monthly") } ?: "weekly" }
    fun lbTop() = watch(db.child("leaderboardCycle")) { s ->
        val totals = linkedMapOf<String, LBE>()
        s.children.forEach { cycle -> cycle.children.forEach entry@ { c ->
            val e = c.safe(LBE::class.java) ?: return@entry
            val uid = c.key ?: return@entry
            val total = totals.getOrPut(uid) { LBE(uid = uid, username = e.username) }
            if (e.username.isNotBlank()) total.username = e.username
            total.score += e.score
        } }
        totals.values.filter { it.score > 0 }.sortedByDescending { it.score }.take(20)
    }
    /** How many players the admin wants on each game's Top Players list (Admin -> Leaderboard). Default 10. */
    fun lbTopN() = watch(db.child("leaderboardConfig/topN")) { s -> (s.value as? Number)?.toInt()?.coerceIn(1, 100) ?: 10 }
    /** Top players of ONE game in the current cycle (written by the admin app when a result is declared). */
    fun lbTopGame(gameId: String, n: Int) = watch(db.child("leaderboardGame")) { s ->
        val totals = linkedMapOf<String, LBE>()
        s.children.forEach { cycle -> cycle.child(gameId).children.forEach entry@ { c ->
            val e = c.safe(LBE::class.java) ?: return@entry
            val uid = c.key ?: return@entry
            val total = totals.getOrPut(uid) { LBE(uid = uid, username = e.username) }
            if (e.username.isNotBlank()) total.username = e.username
            total.score += e.score
        } }
        totals.values.filter { it.score > 0 }.sortedByDescending { it.score }.take(n)
    }
    /** Every active game, whatever its section: each game added by the admin gets its own card in Top Players. */
    fun allGames() = watch(db.child("games")) { s ->
        s.children.mapNotNull { c -> c.safe(Game::class.java)?.also { it.id = c.key!! } }
            .filter { it.active }.sortedBy { it.order }
    }
    /** Referral Leaderboard: the 10 players who invited the most people (each signup with their code = +1). */
    fun refTop() = watch(db.child("referralStats").orderByChild("count").limitToLast(10)) { s ->
        s.children.mapNotNull { c ->
            val n = (c.child("count").value as? Number)?.toLong() ?: 0L
            val name = c.child("username").value?.toString().orEmpty()
            if (n > 0 && name.isNotBlank()) name to n else null
        }.sortedByDescending { it.second }
    }
    fun announcements() = watch(db.child("announcements")) { s ->
        s.children.mapNotNull { c -> c.safe(Ann::class.java)?.also { it.id = c.key ?: "" } }.sortedByDescending { it.ts }
    }

    private fun parseSupportTicket(s: DataSnapshot): SupportTicket {
        val messages = s.child("messages").children.mapNotNull { c ->
            c.safe(SupportTicketMessage::class.java)?.also { it.id = c.key ?: "" }
        }.sortedBy { it.createdAt }
        return SupportTicket(
            id = s.key ?: "", uid = s.child("uid").value?.toString() ?: "",
            username = s.child("username").value?.toString() ?: "", subject = s.child("subject").value?.toString() ?: "",
            category = s.child("category").value?.toString() ?: "Other", status = s.child("status").value?.toString() ?: "open",
            createdAt = (s.child("createdAt").value as? Number)?.toLong() ?: 0L,
            updatedAt = (s.child("updatedAt").value as? Number)?.toLong() ?: 0L,
            lastMessage = s.child("lastMessage").value?.toString() ?: "", messages = messages
        )
    }

    fun supportTickets() = watch(db.child("supportTickets").child(uid())) { s ->
        s.children.map(::parseSupportTicket).sortedByDescending { it.updatedAt }
    }

    fun supportTicket(ticketId: String) = watch(db.child("supportTickets").child(uid()).child(ticketId)) { s ->
        if (s.exists()) parseSupportTicket(s) else null
    }

    suspend fun createSupportTicket(username: String, subject: String, category: String, body: String): Result<String> {
        val owner = uid()
        if (owner.isBlank()) return Result.failure(IllegalStateException(tx("Please sign in first")))
        val cleanSubject = subject.trim().take(100)
        val cleanBody = body.trim().take(2000)
        if (cleanSubject.isBlank()) return Result.failure(IllegalArgumentException(tx("Enter a subject")))
        if (cleanBody.length < 10) return Result.failure(IllegalArgumentException(tx("Please describe the issue in at least 10 characters")))
        return try {
            val ticketRef = db.child("supportTickets").child(owner).push()
            val ticketId = ticketRef.key ?: return Result.failure(IllegalStateException("Could not create ticket ID"))
            val messageId = ticketRef.child("messages").push().key ?: return Result.failure(IllegalStateException("Could not create message ID"))
            val now = System.currentTimeMillis()
            val firstMessage = mapOf("senderUid" to owner, "senderName" to username.ifBlank { "Player" }, "senderRole" to "user", "body" to cleanBody, "createdAt" to now)
            val ticket = mapOf(
                "uid" to owner, "username" to username.ifBlank { "Player" }, "subject" to cleanSubject,
                "category" to category, "status" to "open", "createdAt" to now, "updatedAt" to now,
                "lastMessage" to cleanBody, "messages" to mapOf(messageId to firstMessage)
            )
            ticketRef.setValue(ticket).await()
            AdminEventApi.notifyBestEffort("support_ticket", ticketId)
            Result.success(ticketId)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun replyToSupportTicket(ticketId: String, username: String, body: String): String? {
        val owner = uid()
        val cleanBody = body.trim().take(2000)
        if (owner.isBlank()) return tx("Please sign in first")
        if (cleanBody.length < 2) return tx("Write a reply first")
        return try {
            val ticketRef = db.child("supportTickets").child(owner).child(ticketId)
            val current = ticketRef.get().await()
            if (!current.exists()) return tx("Ticket not found")
            val status = current.child("status").value?.toString() ?: "open"
            if (status == "closed") return tx("This ticket is closed")
            val messageId = ticketRef.child("messages").push().key ?: return tx("Could not create reply")
            val now = System.currentTimeMillis()
            val message = mapOf("senderUid" to owner, "senderName" to username.ifBlank { "Player" }, "senderRole" to "user", "body" to cleanBody, "createdAt" to now)
            val updates = hashMapOf<String, Any?>("messages/$messageId" to message, "lastMessage" to cleanBody, "updatedAt" to now)
            if (status == "resolved") updates["status"] = "open"
            ticketRef.updateChildren(updates).await()
            AdminEventApi.notifyBestEffort("support_reply", ticketId, messageId)
            null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { e.message ?: tx("Could not send reply") }
    }

    // ---------- Player vs Player matches ----------
    fun pvpGames() = watch(db.child("pvpGames")) { s ->
        s.children.mapNotNull { c -> c.safe(PvpGame::class.java)?.also { it.id = c.key ?: "" } }.filter { it.active }.sortedBy { it.order }
    }
    private fun parsePvp(c: DataSnapshot): PvpMatch? = c.safe(PvpMatch::class.java)?.also {
        it.id = c.key ?: ""; it.joined = c.child("players").childrenCount
    }
    /** Matches players can still join: upcoming or ongoing, with a free seat. */
    fun pvpLobby(): Flow<List<PvpMatch>> {
        fun q(st: String) = watch(db.child("pvpMatches").orderByChild("status").equalTo(st)) { s -> s.children.mapNotNull { parsePvp(it) } }
        return combine(q("upcoming"), q("ongoing")) { a, b -> (a + b).filter { !it.resultDeclared && it.joined < it.slots && it.startTime > System.currentTimeMillis() - 3 * 3600_000L }.sortedBy { it.startTime } }
    }
    /** Every player match for the Join tab (like the normal Ongoing / Upcoming / Results lists): upcoming + ongoing + the latest finished ones. */
    fun pvpAll(): Flow<List<PvpMatch>> {
        fun q(st: String, last: Int = 0) = watch(db.child("pvpMatches").orderByChild("status").equalTo(st).let { if (last > 0) it.limitToLast(last) else it }) { s -> s.children.mapNotNull { parsePvp(it) } }
        return combine(q("upcoming"), q("ongoing"), q("completed", 50)) { a, b, c -> a + b + c }
    }
    fun pvpMatch(id: String) = watch(db.child("pvpMatches").child(id)) { parsePvp(it) }
    fun pvpPlayers(id: String) = watch(db.child("pvpMatches/$id/players")) { s ->
        s.children.mapNotNull { c -> c.key?.let { PvpPlayer(it, c.child("uid").value?.toString() ?: "", c.child("username").value?.toString() ?: "", (c.child("ts").value as? Number)?.toLong() ?: 0L, c.child("ign").value?.toString() ?: "") } }
            .sortedBy { it.seat.removePrefix("s").toIntOrNull() ?: 0 }
    }
    fun pvpReports(id: String) = watch(db.child("pvpMatches/$id/reports")) { s ->
        s.children.mapNotNull { c -> c.key?.let { PvpReport(it, c.child("username").value?.toString() ?: "", c.child("winnerName").value?.toString() ?: "",
            c.child("note").value?.toString() ?: "", (c.child("ts").value as? Number)?.toLong() ?: 0L) } }.sortedBy { it.ts }
    }
    fun pvpRoom(id: String) = watch(db.child("pvpRooms/$id")) { (it.child("roomId").value?.toString() ?: "") to (it.child("roomPass").value?.toString() ?: "") }
    suspend fun pvpShot(mid: String, uid: String): String = try { db.child("pvpShots/$mid/$uid").get().await().value?.toString() ?: "" } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { "" }

    /** Every player match this account created or joined (live): the latest 40. */
    fun myPvp(): Flow<List<PvpMatch>> = callbackFlow<List<PvpMatch>> {
        val idx = db.child("pvpByUser").child(uid())
        val listeners = HashMap<String, Pair<DatabaseReference, ValueEventListener>>()
        val cur = HashMap<String, PvpMatch>()
        fun push() { trySend(cur.values.sortedByDescending { it.startTime }) }
        val idxL = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val ids = s.children.sortedByDescending { (it.value as? Number)?.toLong() ?: 0L }.take(40).mapNotNull { it.key }.toSet()
                (listeners.keys - ids).toList().forEach { k -> listeners.remove(k)?.let { (r, l) -> r.removeEventListener(l) }; cur.remove(k) }
                ids.filter { it !in listeners }.forEach { id ->
                    val r = db.child("pvpMatches").child(id)
                    val l = object : ValueEventListener {
                        override fun onDataChange(m: DataSnapshot) { val v = parsePvp(m); if (v != null) cur[id] = v else cur.remove(id); push() }
                        override fun onCancelled(e: DatabaseError) { }
                    }
                    listeners[id] = r to l; r.addValueEventListener(l)
                }
                push()
            }
            override fun onCancelled(e: DatabaseError) { close(e.toException()) }
        }
        idx.addValueEventListener(idxL)
        awaitClose { idx.removeEventListener(idxL); listeners.values.forEach { (r, l) -> r.removeEventListener(l) } }
    }.catch { emit(emptyList()) }

    /** Next running match number (#767, #768 ...). The admin can set where it starts (Admin -> Player matches -> NEXT NO). */
    private suspend fun nextPvpNo(): Long = suspendCancellableCoroutine { c ->
        var got = 0L
        db.child("pvpCounter").runTransaction(object : Transaction.Handler {
            override fun doTransaction(d: MutableData): Transaction.Result { got = ((d.value as? Number)?.toLong() ?: 0L) + 1; d.value = got; return Transaction.success(d) }
            override fun onComplete(e: DatabaseError?, ok: Boolean, s: DataSnapshot?) { c.resume(if (ok && e == null) got else 0L) }
        })
    }

    /** Creates a player match. The creator pays the entry fee and takes seat 1. The winning amount is generated automatically (Pvp.prize). Returns an error text or null. */
    suspend fun createPvp(g: PvpGame, slots: Int, fee: Double, startTime: Long, note: String, username: String, ign: String): String? {
        val uid = uid()
        if (uid.isBlank()) return tx("Please sign in first")
        if (fee < Pvp.MIN_FEE) return tx("Minimum entry fee is") + " " + money(Pvp.MIN_FEE)
        if (slots !in g.slotOptions()) return tx("Choose the number of players")
        if (ign.trim().isBlank()) return tx("Enter your in-game name")
        if (startTime < System.currentTimeMillis() - 60_000) return tx("Choose a match time in the future")
        try {
            val u = db.child("users").child(uid).get().await().getValue(User::class.java) ?: return tx("User not found")
            if (u.banned) return tx("Your account is banned")
            if (u.balance() < fee) return tx("Insufficient balance. Add coins first.")
            val prize = Pvp.prize(fee, slots, g.commission)
            val id = db.child("pvpMatches").push().key ?: return tx("Could not create the match")
            val fromDep = minOf(u.deposited, fee); val fromWin = fee - fromDep
            val ok1 = fromDep <= 0 || db.child("users/$uid/deposited").tx(dec(fromDep))
            val ok2 = fromWin <= 1e-9 || db.child("users/$uid/winning").tx(dec(fromWin))
            if (!(ok1 && ok2)) return tx("Payment failed. Try again.")
            val now = System.currentTimeMillis()
            val no = nextPvpNo()
            val code = (100000 + java.security.SecureRandom().nextInt(900000)).toString()
            val tid = db.child("transactions/$uid").push().key!!
            db.updateChildren(mapOf(
                "pvpMatches/$id" to mapOf(
                    "gameId" to g.id, "gameName" to g.name, "gameImage" to g.image, "creatorUid" to uid, "creatorName" to username,
                    "entryFee" to fee, "prize" to prize, "slots" to slots, "startTime" to startTime, "note" to note.trim().take(300),
                    "status" to "upcoming", "commission" to g.commission, "createdAt" to now, "matchCode" to code, "matchNo" to no, "title" to g.title.trim().ifBlank { g.name },
                    "players" to mapOf("s1" to mapOf("uid" to uid, "username" to username, "ign" to ign.trim().take(30), "ts" to now, "dep" to fromDep, "win" to fromWin))),
                "pvpByUser/$uid/$id" to now,
                "transactions/$uid/$tid" to Tx(tid, "join", -fee, "Created match ${g.name} #${if (no > 0) no.toString() else code}", now, "success")
            )).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message ?: tx("Could not create the match") }
    }

    /** Joins a player match: takes a free seat, pays the entry fee. Returns an error text or null. */
    suspend fun joinPvp(m: PvpMatch, username: String, ign: String): String? {
        val uid = uid()
        if (uid.isBlank()) return tx("Please sign in first")
        if (ign.trim().isBlank()) return tx("Enter your in-game name")
        try {
            val u = db.child("users").child(uid).get().await().getValue(User::class.java) ?: return tx("User not found")
            if (u.banned) return tx("Your account is banned")
            val live = db.child("pvpMatches/${m.id}").get().await()
            val cur = parsePvp(live) ?: return tx("Match not found")
            if (cur.resultDeclared || cur.status == "completed" || cur.status == "cancelled") return tx("This match is closed")
            val taken = live.child("players").children.toList()
            if (taken.any { it.child("uid").value == uid }) return tx("You have already joined this match")
            if (taken.size >= cur.slots) return tx("This match is full")
            val fee = cur.entryFee
            if (u.balance() < fee) return tx("Insufficient balance. Add coins first.")
            val fromDep = minOf(u.deposited, fee); val fromWin = fee - fromDep
            var seat: String? = null
            for (i in 1..cur.slots.toInt()) {
                val key = "s$i"
                val ok = db.child("pvpMatches/${m.id}/players/$key").tx { d ->
                    if (d.value == null) {
                        d.value = mapOf("uid" to uid, "username" to username, "ign" to ign.trim().take(30), "ts" to System.currentTimeMillis(), "dep" to fromDep, "win" to fromWin)
                        Transaction.success(d)
                    } else Transaction.abort()
                }
                if (ok) { seat = key; break }
            }
            if (seat == null) return tx("This match is full")
            val ok1 = fromDep <= 0 || db.child("users/$uid/deposited").tx(dec(fromDep))
            val ok2 = fromWin <= 1e-9 || db.child("users/$uid/winning").tx(dec(fromWin))
            if (!(ok1 && ok2)) { try { db.child("pvpMatches/${m.id}/players/$seat").removeValue().await() } catch (_: Exception) { }; return tx("Payment failed. Try again.") }
            val now = System.currentTimeMillis(); val tid = db.child("transactions/$uid").push().key!!
            db.updateChildren(mapOf(
                "pvpByUser/$uid/${m.id}" to now,
                "transactions/$uid/$tid" to Tx(tid, "join", -fee, "Joined ${cur.label()}", now, "success")
            )).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message ?: tx("Join failed") }
    }

    /** A player can change his own in-game name until the result is declared. Time, fee, rules and players cannot be edited. */
    suspend fun updatePvpIgn(m: PvpMatch, seat: String, ign: String): String? {
        val v = ign.trim().take(30)
        if (v.isBlank()) return tx("Enter your in-game name")
        if (m.resultDeclared || m.status == "completed" || m.status == "cancelled") return tx("This match is closed")
        return try { db.child("pvpMatches/${m.id}/players/$seat/ign").setValue(v).await(); null }
        catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { e.message ?: tx("Could not save") }
    }

    /** Only the creator can save / change the Room ID and password. Saving it the first time moves the match to Ongoing. */
    suspend fun savePvpRoom(m: PvpMatch, roomId: String, pass: String): String? {
        val rid = roomId.trim().take(60)
        if (rid.isBlank()) return tx("Enter the Room ID")
        if (m.creatorUid != uid()) return tx("Only the match creator can do this")
        return try {
            val ups = HashMap<String, Any?>()
            ups["pvpRooms/${m.id}"] = mapOf("roomId" to rid, "roomPass" to pass.trim().take(60), "ts" to System.currentTimeMillis(), "by" to uid())
            if (m.status == "upcoming") ups["pvpMatches/${m.id}/status"] = "ongoing"
            db.updateChildren(ups).await(); null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { e.message ?: tx("Could not save") }
    }

    /** A player sends his match screenshot (+ optional winner name and note). Each player can send once; both screenshots stay inside the match for the admin. */
    suspend fun submitPvpReport(m: PvpMatch, username: String, shot: String, winnerName: String, note: String): String? {
        val uid = uid()
        if (uid.isBlank()) return tx("Please sign in first")
        if (shot.isBlank()) return tx("Attach the match screenshot")
        return try {
            val ups = HashMap<String, Any?>()
            ups["pvpShots/${m.id}/$uid"] = shot
            ups["pvpMatches/${m.id}/reports/$uid"] = mapOf("uid" to uid, "username" to username, "winnerName" to winnerName.trim().take(40),
                "note" to note.trim().take(500), "ts" to System.currentTimeMillis())
            db.updateChildren(ups).await(); null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
            if ((e.message ?: "").contains("permission", true)) tx("You already sent your screenshot for this match") else e.message ?: tx("Could not send")
        }
    }

    // ---------- Auth ----------
    suspend fun login(idf: String, pass: String): String? {
        val invalid = tx("Invalid email/username/number")
        try {
            var email = idf.trim()
            if (!email.contains("@")) {
                val key = email.removePrefix("+").replace(" ", "").lowercase()
                if (key.isBlank() || Regex("[.#\$\\[\\]/]").containsMatchIn(key)) return invalid
                email = db.child("loginMap").child(key).get().await().value?.toString() ?: return invalid
            }
            auth.signInWithEmailAndPassword(email.trim(), pass).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: com.google.firebase.auth.FirebaseAuthInvalidUserException) {
            return if (e.errorCode == "ERROR_USER_DISABLED") tx("This account is disabled") else invalid
        }
        catch (e: com.google.firebase.auth.FirebaseAuthInvalidCredentialsException) {
            // Firebase answers "invalid credential" for a wrong password (and, with its e-mail protection on, also for an unknown e-mail).
            return if (idf.contains("@")) tx("Wrong password or invalid email") else tx("Wrong password")
        }
        catch (e: com.google.firebase.FirebaseTooManyRequestsException) { return tx("Too many attempts. Please try again later") }
        catch (e: Exception) { return e.message ?: tx("Login failed") }
    }

    /** True when this referral code (a username) exists. Used by the APPLY button on Sign Up. */
    suspend fun referralCodeExists(code: String): Boolean {
        val c = code.trim().lowercase()
        if (c.isBlank()) return false
        return try { !db.child("referralCodes").child(c).get().await().value?.toString().isNullOrBlank() }
        catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { false }
    }

    suspend fun signup(f: String, l: String, un0: String, phone0: String, email: String, promo: String, pass: String, dial: String = "+91"): String? {
        try {
            val un = un0.trim().lowercase()
            if (!Regex("[a-z0-9_]{3,20}").matches(un)) return tx("Username: 3-20 chars (a-z, 0-9, _)")
            val digits = phone0.filter { it.isDigit() }
            // India: 10 digits as before. Other countries are saved with their country code in front (for example 8801712345678).
            val phone = if (dial == "+91") digits else dial.removePrefix("+") + digits
            if (dial == "+91") { if (!Regex("[0-9]{10}").matches(digits)) return tx("Enter a valid 10 digit phone number") }
            else if (digits.length !in 6..13) return tx("Enter a valid phone number")
            if (db.child("loginMap").child(un).get().await().exists()) return tx("Username already taken")
            if (db.child("loginMap").child(phone).get().await().exists()) return tx("Phone already registered")
            val res = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val uid = res.user!!.uid
            val u = User(firstName = f.trim(), lastName = l.trim(), username = un, phone = phone, email = email.trim(),
                referralCode = un, referredBy = promo.trim().lowercase(), kyc = true, createdAt = System.currentTimeMillis())
            try {
                db.updateChildren(mapOf(
                    "users/$uid" to u, "loginMap/$un" to email.trim(), "loginMap/$phone" to email.trim(),
                    "referralCodes/$un" to uid
                )).await()
            } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) {
                // Profile could not be saved: remove the half-created login so the player can try again with the same e-mail.
                try { res.user?.delete()?.await() } catch (_: Exception) { }
                throw e
            }
            val code = promo.trim().lowercase()
            if (code.isNotBlank() && code != un) {
                try {
                    val refUid = db.child("referralCodes").child(code).get().await().value?.toString()
                    if (!refUid.isNullOrBlank()) {
                        val entry = Referral(un, System.currentTimeMillis(), "pending")
                        try {
                            // One atomic write: the referral entry + the referrer's Leaderboard count (+1, used by Account -> Leaderboard).
                            db.updateChildren(mapOf(
                                "referrals/$refUid/$uid" to entry,
                                "referralStats/$refUid/username" to code,
                                "referralStats/$refUid/count" to com.google.firebase.database.ServerValue.increment(1)
                            )).await()
                        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) {
                            // Rules for /referralStats not published yet -> still save the normal referral entry like before.
                            db.child("referrals/$refUid/$uid").setValue(entry).await()
                        }
                    }
                } catch (_: Exception) { }
            }
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return signupError(e) }
    }

    /** Readable signup error. For unknown errors the Firebase error code / class is shown so the real cause is visible (not just "Not found"). */
    private fun signupError(e: Exception): String = when (e) {
        is com.google.firebase.auth.FirebaseAuthUserCollisionException -> tx("This email is already registered")
        is com.google.firebase.auth.FirebaseAuthWeakPasswordException -> tx("Password is too weak")
        is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException -> tx("Enter a valid email")
        is com.google.firebase.FirebaseNetworkException -> tx("No internet connection")
        is com.google.firebase.auth.FirebaseAuthException -> "${tx("Signup failed")}: ${e.errorCode}"
        is com.google.firebase.database.DatabaseException -> "${tx("Signup failed")}: Database - ${e.message ?: ""}"
        else -> "${tx("Signup failed")}: ${e.javaClass.simpleName} ${e.message ?: ""}".trim()
    }

    /**
     * Forgot password: Firebase sends a "reset password" e-mail with a link. The player opens it on the phone, types a new password
     * on that page and then logs in. Typed e-mail / mobile / username -> the account e-mail. Returns (maskedEmail, null) or (null, message).
     */
    suspend fun resetPassword(idf: String): Pair<String?, String?> {
        return try {
            var email = idf.trim()
            if (email.isBlank()) return Pair(null, tx("Enter email/username first"))
            if (!email.contains("@")) {
                val key = email.removePrefix("+").replace(" ", "").lowercase()
                if (key.isBlank() || Regex("[.#\$\\[\\]/]").containsMatchIn(key)) return Pair(null, tx("Invalid email/username/number"))
                email = db.child("loginMap").child(key).get().await().value?.toString() ?: return Pair(null, tx("Invalid email/username/number"))
            }
            email = email.trim()
            auth.sendPasswordResetEmail(email).await()
            val local = email.substringBefore("@"); val shown = local.take(if (local.length <= 2) 1 else 2)
            Pair(shown + "*".repeat(maxOf(3, minOf(6, local.length - shown.length))) + "@" + email.substringAfter("@"), null)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: com.google.firebase.auth.FirebaseAuthInvalidUserException) { Pair(null, tx("Invalid email/username/number")) }
        catch (e: Exception) { Pair(null, e.message ?: tx("Failed")) }
    }

    // ---------- Transactions ----------
    private suspend fun DatabaseReference.tx(f: (MutableData) -> Transaction.Result): Boolean =
        suspendCancellableCoroutine { c ->
            runTransaction(object : Transaction.Handler {
                override fun doTransaction(d: MutableData) = f(d)
                override fun onComplete(e: DatabaseError?, ok: Boolean, s: DataSnapshot?) { c.resume(ok && e == null) }
            })
        }

    private fun dec(by: Double): (MutableData) -> Transaction.Result = { d ->
        val cur = (d.value as? Number)?.toDouble()
        if (cur == null) Transaction.success(d)
        else if (cur < by - 1e-9) Transaction.abort()
        else { d.value = cur - by; Transaction.success(d) }
    }

    suspend fun join(m: Match, picks: List<String>, ign: Map<String, String>, username: String): String? {
        val uid = uid()
        val total = m.fee() * picks.size
        try {
            val u = db.child("users").child(uid).get().await().getValue(User::class.java) ?: return tx("User not found")
            if (u.banned) return tx("Your account is banned")
            if (db.child("matches/${m.id}/status").get().await().value?.toString() == "cancelled") return tx("This match is cancelled")
            val mine = db.child("matches/${m.id}/slots").get().await().children.count { it.child("uid").value == uid }
            if (mine > 0) return tx("You have already joined this match")
            if (mine + picks.size > m.perTeam()) return "${m.mode}: " + tx("Max slots per player") + " ${m.perTeam()}"
            if (u.balance() < total) return tx("Insufficient balance. Add coins first.")
            // Same order as the payment below (deposit first, then winning). Saved in each slot so a cancelled match can be refunded to the same wallet part.
            var depLeft = u.deposited
            val depPaid = HashMap<String, Double>()
            for (p in picks) { val d = minOf(maxOf(depLeft, 0.0), m.fee()); depPaid[p] = d; depLeft -= d }
            val taken = mutableListOf<String>()
            suspend fun release() { taken.forEach { db.child("matches/${m.id}/slots/$it").removeValue().await() } }
            for (p in picks) {
                val ok = db.child("matches/${m.id}/slots/$p").tx { d ->
                    if (d.value == null) {
                        d.value = mapOf("uid" to uid, "username" to username, "ign" to (ign[p] ?: ""), "ts" to System.currentTimeMillis(),
                            "dep" to (depPaid[p] ?: 0.0), "win" to (m.fee() - (depPaid[p] ?: 0.0)))
                        Transaction.success(d)
                    } else Transaction.abort()
                }
                if (ok) taken += p else { release(); return "Position $p already taken. Choose another." }
            }
            if (total > 0) {
                val fromDep = minOf(u.deposited, total)
                val fromWin = total - fromDep
                val ok1 = fromDep <= 0 || db.child("users/$uid/deposited").tx(dec(fromDep))
                val ok2 = fromWin <= 1e-9 || db.child("users/$uid/winning").tx(dec(fromWin))
                if (!(ok1 && ok2)) { release(); return tx("Payment failed. Try again.") }
            }
            db.child("matches/${m.id}/joined").tx { d ->
                d.value = ((d.value as? Number)?.toLong() ?: 0L) + picks.size; Transaction.success(d)
            }
            val tid = db.child("transactions/$uid").push().key!!
            db.updateChildren(mapOf(
                "joinedByUser/$uid/${m.id}" to (matchSnapshot(m) + mapOf("myNames" to picks.mapNotNull { p -> ign[p]?.trim()?.takeIf { it.isNotBlank() } })),
                "transactions/$uid/$tid" to Tx(tid, "join", -total, "Joined ${m.title} #${m.matchNo}", System.currentTimeMillis(), "success")
            )).await()
            try { FirebaseMessaging.getInstance().subscribeToTopic("m_${m.id}") } catch (_: Exception) { }
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message ?: tx("Join failed") }
    }

    /**
     * Access-code check. The player writes the typed code to matchAccessOk/{match}/{uid}; the database rules accept that write only
     * when it equals the code the admin saved (players can never read the real code), and the seat can only be taken after that.
     */
    suspend fun verifyAccessCode(m: Match, code: String): String? {
        val c = code.trim()
        if (c.isEmpty()) return tx("Enter the access code")
        return try { db.child("matchAccessOk/${m.id}/${uid()}").setValue(c).await(); null }
        catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { if (e.message.orEmpty().contains("permission", true)) tx("Wrong access code") else (e.message ?: tx("Join failed")) }
    }

    suspend fun requestWithdraw(amount: Double, upi: String, username: String, method: String = "upi", methodTitle: String = "UPI ID", feePct: Double = 0.0): String? {
        val uid = uid()
        try {
            val u = db.child("users").child(uid).get().await().getValue(User::class.java) ?: return tx("User not found")
            if (u.winning < amount) return tx("Only winning balance can be withdrawn")
            if (!db.child("users/$uid/winning").tx(dec(amount))) return "Withdraw failed. Try again."
            val id = db.child("withdrawals").push().key!!
            val now = System.currentTimeMillis()
            db.updateChildren(mapOf(
                "withdrawals/$id" to mapOf("uid" to uid, "username" to username, "amount" to amount, "upi" to upi.trim(), "method" to method, "methodTitle" to methodTitle, "feePct" to feePct, "net" to amount * (100.0 - feePct) / 100.0, "status" to "pending", "ts" to now),
                "transactions/$uid/$id" to Tx(id, "withdraw", -amount, "Withdraw request to ${upi.trim()} ($methodTitle)", now, "pending")
            )).await()
            AdminEventApi.notifyBestEffort("withdrawal_request", id)
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message }
    }

    fun referrals() = watch(db.child("referrals").child(uid())) { s -> s.children.mapNotNull { it.safe(Referral::class.java) }.sortedByDescending { it.ts } }
    fun rewards() = watch(db.child("rewards").child(uid())) { s -> s.children.mapNotNull { it.safe(Reward::class.java) }.sortedByDescending { it.ts } }

    suspend fun updateProfile(first: String, last: String, dob: String, gender: String): String? {
        try {
            db.child("users").child(uid()).updateChildren(mapOf("firstName" to first.trim(), "lastName" to last.trim(), "dob" to dob.trim(), "gender" to gender)).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message ?: tx("Update failed") }
    }

    suspend fun changePassword(old: String, new: String): String? {
        try {
            val u = auth.currentUser ?: return tx("Not logged in")
            u.reauthenticate(EmailAuthProvider.getCredential(u.email ?: "", old)).await()
            u.updatePassword(new).await()
            return null
        } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { return e.message ?: tx("Password change failed") }
    }

    suspend fun setPush(on: Boolean) {
        try {
            db.child("users/${uid()}/pushEnabled").setValue(on).await()
            val m = FirebaseMessaging.getInstance()
            if (on) m.subscribeToTopic("all").await() else m.unsubscribeFromTopic("all").await()
        } catch (_: Exception) { }
    }
}
