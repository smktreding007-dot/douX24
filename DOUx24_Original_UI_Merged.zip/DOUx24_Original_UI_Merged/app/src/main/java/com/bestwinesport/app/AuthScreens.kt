package com.bestwinesport.app

import androidx.compose.foundation.background
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.Icons
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.isActive
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

/** White pill text field, same size as the reference design (50dp tall, 17sp). */
@Composable
fun AuthField(v: String, onV: (String) -> Unit, hint: String, modifier: Modifier = Modifier, pw: Boolean = false, kb: KeyboardType = KeyboardType.Text, trailing: (@Composable () -> Unit)? = null) {
    // Password fields get an eye icon at the right end: tap = the typed password is shown, tap again = hidden.
    var show by remember { mutableStateOf(false) }
    BasicTextField(v, onV, modifier.height(50.dp).clip(RoundedCornerShape(25.dp)).background(Color.White), singleLine = true,
        textStyle = TextStyle(fontSize = 17.sp, color = Color.Black), cursorBrush = SolidColor(Color.Black),
        visualTransformation = if (pw && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        decorationBox = { inner ->
            Row(Modifier.fillMaxSize().padding(start = 20.dp, end = if (pw || trailing != null) 6.dp else 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (v.isEmpty()) Text(hint, color = Color(0xFF6B6B6B), fontSize = 17.sp, maxLines = 1)
                    inner()
                }
                if (pw) Icon(
                    if (show) androidx.compose.material.icons.Icons.Default.Visibility else androidx.compose.material.icons.Icons.Default.VisibilityOff,
                    contentDescription = if (show) "Hide password" else "Show password", tint = Color(0xFF6B6B6B),
                    modifier = Modifier.size(40.dp).clip(CircleShape).clickable { show = !show }.padding(8.dp)
                )
                trailing?.invoke()
            }
        })
}

/** Big pill button in the theme's button colour (54dp tall, bold 18sp). */
@Composable
fun AuthButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick, modifier.height(54.dp), enabled = enabled, shape = RoundedCornerShape(27.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ButtonC, contentColor = OnButton)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

/** PERMANENT purple (same in every theme): Choose Language CONTINUE button and the "Welcome to, Login / Sign Up" headings. */
private val AuthPurple = Color(0xFF6100FF)

@Composable
fun LanguageScreen(nav: NavController) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().background(BgBrush).statusBarsPadding()) {
        Text(tr("choose_language"), Modifier.padding(start = 24.dp, top = 28.dp, bottom = 24.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AppLanguage.options.forEach { option ->
                val picked = AppLanguage.current == option.code
                // Square white box with a theme-coloured border (4 sharp corners), radio on the left.
                Row(Modifier.fillMaxWidth().height(52.dp).background(Color.White).border(1.dp, Purple)
                    .clickable { AppLanguage.select(ctx, option.code) }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(picked, { AppLanguage.select(ctx, option.code) }, colors = RadioButtonDefaults.colors(selectedColor = Color.Black, unselectedColor = Color(0xFF6B6B6B)))
                    Spacer(Modifier.width(18.dp))
                    Text(option.label, color = Color.Black, fontSize = 17.sp)
                    if (option.nativeName != option.label) Text("  (${option.nativeName})", color = Color(0xFF6B6B6B), fontSize = 14.sp)
                }
            }
        }
        Button({ if (Repo.auth.currentUser != null) nav.back() else nav.go("welcome") { popUpTo("lang") { inclusive = true } } },
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 24.dp).height(48.dp), shape = RoundedCornerShape(6.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AuthPurple, contentColor = Color.White)) {
            Text(tr("continue"), fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

private val DEFAULT_SLIDES = listOf(
    "SELECT A GAME" to "Join the contest of your favorite game and win real money",
    "REFER & EARN" to "Invite your friends to play their favorite game and get rewarded",
    "JOIN A MATCH" to "Join contest as per your gameplay like SOLO, DUO, SQUAD"
)

/**
 * Welcome page: sliding pictures (swipe sideways + auto-slide). The TEXTS are fixed (DEFAULT_SLIDES); the sliding PICTURES are fixed (built-in).
 * Admin -> App settings -> "Welcome page BACKGROUND image" is the only thing admin can change here.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WelcomeScreen(nav: NavController) {
    // Admin -> App settings -> "Welcome page BACKGROUND image": one static layer behind every sliding picture.
    val bgImg by rflow(init = "") { Repo.setting("welcomeBg") }
    val hasBg = bgImg.isNotBlank()
    val count = DEFAULT_SLIDES.size
    val state = androidx.compose.foundation.pager.rememberPagerState(pageCount = { count })
    LaunchedEffect(count) {
        while (true) {
            delay(3500)
            if (count > 1 && !state.isScrollInProgress) {
                try { state.animateScrollToPage((state.currentPage + 1) % count) }
                catch (e: CancellationException) { if (!isActive) throw e }
            }
        }
    }
    // Every slide uses the same picture frame. With no admin background it stays white; slide text and footer keep their fixed colors.
    // With an admin background picture, use light status-bar icons. Restore the previous status-bar style when the page is left.
    val view = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(hasBg) {
        val ctrl = (view.context as? android.app.Activity)?.window?.let { androidx.core.view.WindowCompat.getInsetsController(it, view) }
        val old = ctrl?.isAppearanceLightStatusBars
        ctrl?.isAppearanceLightStatusBars = !hasBg
        onDispose { if (old != null) ctrl.isAppearanceLightStatusBars = old }
    }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
      Box(Modifier.weight(1f).fillMaxWidth()) {
        // One background layer stays fixed while the foreground slides move across the pager.
        if (hasBg) coil.compose.AsyncImage(bgImg.trim(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        androidx.compose.foundation.pager.HorizontalPager(state, Modifier.fillMaxSize()) { p ->
            val def = DEFAULT_SLIDES[p % DEFAULT_SLIDES.size]
            val url = "" // pictures are fixed (built-in); admin can change only the background image
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth().background(if (hasBg) Color.Transparent else Color.White)) {
                  // Picture sits flush on the text block (no bottom gap): aligned to the bottom, only side/top spacing.
                  Box(Modifier.fillMaxSize().statusBarsPadding().padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 0.dp), contentAlignment = Alignment.BottomCenter) {
                    if (url.isNotBlank()) coil.compose.AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit, alignment = Alignment.BottomCenter)
                    else androidx.compose.foundation.Image(painterResource(R.drawable.onboarding_default), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit, alignment = Alignment.BottomCenter)
                  }
                }
                // Text block is ALWAYS white with dark text (fixed, not controlled by theme or admin).
                Column(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp)) {
                    Spacer(Modifier.height(14.dp))
                    Text(tx(def.first), color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(tx(def.second), color = Color.Black.copy(alpha = 0.72f), fontSize = 13.sp, lineHeight = 18.sp, minLines = 2)
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
      }
        Column(Modifier.fillMaxWidth().background(Color.Black).padding(horizontal = 20.dp)) {
            if (count > 1) Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.Center) {
                repeat(count) { i ->
                    Box(Modifier.padding(horizontal = 3.dp).size(if (i == state.currentPage) 9.dp else 7.dp).clip(CircleShape)
                        .background(if (i == state.currentPage) Purple else Color.White.copy(alpha = 0.25f)))
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.clickable { nav.go("signup") }) {
                    Text(tx("Don't have an account? Sign Up"), color = Color.White, fontSize = 12.sp)
                    Text(tx("REGISTER"), color = Purple, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.clickable { nav.go("login") }) {
                    Text(tx("Already a user?"), color = Color.White, fontSize = 12.sp)
                    Text(tx("LOGIN"), color = Color(0xFF00A859), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun LoginScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showForgot by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(BgBrush).statusBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(130.dp))
        Text(tx("Welcome to,\nLogin"), fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 38.sp, color = AuthPurple)
        Spacer(Modifier.height(40.dp))
        AuthField(id, { id = it }, tx("Email/Mobile No/Username"), Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        AuthField(pw, { pw = it }, tx("Password"), Modifier.fillMaxWidth(), pw = true)
        Text(tx("Forgot Password?"), color = Color.White, fontSize = 17.sp, modifier = Modifier.align(Alignment.End).padding(vertical = 14.dp).clickable { showForgot = true })
        // Forgot password: dialog (email/mobile/username) -> Firebase sends the reset-link e-mail. See ForgotPasswordScreens.kt.
        if (showForgot) ForgotPasswordDialog(id, onDismiss = { showForgot = false })
        Spacer(Modifier.height(16.dp))
        AuthButton(tx("LOGIN"), Modifier.fillMaxWidth()) {
            if (busy) return@AuthButton
            if (id.isBlank() || pw.isBlank()) { ctx.toast(tx("Fill all fields")); return@AuthButton }
            busy = true
            scope.launch {
                val err = Repo.login(id, pw); busy = false
                if (err == null) { ctx.toast(tx("Login Successfully")); nav.navigate("main") { popUpTo(0) } } else ctx.toast(err)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.align(Alignment.CenterHorizontally)) {
            Text(tx("Don't have an account? "), color = Color.White, fontSize = 18.sp)
            Text(tx("Sign Up"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { nav.goOrBack("signup") })
        }
    }
}

@Composable
fun SignupScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var f by remember { mutableStateOf("") }; var l by remember { mutableStateOf("") }
    var un by remember { mutableStateOf("") }; var ph by remember { mutableStateOf("") }
    var em by remember { mutableStateOf("") }; var promo by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }; var codeMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    // Referral code check: 0 = not checked, 1 = applied (code is valid), 2 = wrong code.
    var promoState by remember { mutableIntStateOf(0) }; var promoBusy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(BgBrush).statusBarsPadding().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(28.dp))
        Text(tx("Welcome to,\nSign Up"), fontSize = 30.sp, fontWeight = FontWeight.Bold, lineHeight = 38.sp, color = AuthPurple)
        Spacer(Modifier.height(36.dp))
        val gap = Modifier.fillMaxWidth().padding(bottom = 10.dp)
        AuthField(f, { f = it }, tx("First Name"), gap); AuthField(l, { l = it }, tx("Last Name"), gap); AuthField(un, { un = it }, tx("Username"), gap)
        Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            // Country code: shows "Code" first; tapping opens a small white card (+91 India only) over a dimmed screen.
            Row(Modifier.height(50.dp).clip(RoundedCornerShape(25.dp)).background(Color.White).clickable { codeMenu = true }.padding(start = 16.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(code.ifBlank { tx("Code") }, color = if (code.isBlank()) Color(0xFF4A4A4A) else Color.Black, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Icon(Icons.Default.ArrowDropDown, null, Modifier.size(26.dp), tint = Color.Black)
            }
            if (codeMenu) androidx.compose.ui.window.Dialog(onDismissRequest = { codeMenu = false },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
                // Wide + short white card (like the reference), close button floating above its right corner.
                Box(Modifier.fillMaxWidth().padding(horizontal = 47.dp).padding(top = 32.dp)) {
                    Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(10.dp)).background(Color.White)
                        .clickable { code = "+91"; codeMenu = false; ph = ph.take(10) }, contentAlignment = Alignment.Center) {
                        Text("+91 (India)", color = Color.Black, fontSize = 17.sp)
                    }
                    Box(Modifier.align(Alignment.TopEnd).offset(x = 3.dp, y = (-32).dp).size(24.dp).clip(CircleShape).background(Color(0xFFE01B10))
                        .clickable { codeMenu = false }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Close, null, Modifier.size(15.dp), tint = Color.White)
                    }
                }
            }
            Spacer(Modifier.width(10.dp))
            AuthField(ph, { ph = it.filter(Char::isDigit).take(if (code == "+91" || code.isBlank()) 10 else 15) }, tx("Phone number"), Modifier.weight(1f), kb = KeyboardType.Phone)
        }
        AuthField(em, { em = it }, tx("Email"), gap, kb = KeyboardType.Email)
        AuthField(pw, { pw = it }, tx("Password"), gap, pw = true)
        AuthField(promo, { promo = it.replace(" ", ""); promoState = 0 }, tx("Referral Code"), Modifier.fillMaxWidth().padding(bottom = if (promoState != 0) 4.dp else 10.dp),
            trailing = {
                val applied = promoState == 1
                Box(Modifier.height(38.dp).clip(RoundedCornerShape(19.dp)).background(if (applied) Color(0xFF2ECC71) else Orange)
                    .clickable(enabled = !promoBusy && !applied) {
                        if (promo.isBlank()) { ctx.toast(tx("Enter referral code")); return@clickable }
                        promoBusy = true
                        scope.launch { promoState = if (Repo.referralCodeExists(promo)) 1 else 2; promoBusy = false }
                    }.padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
                    if (promoBusy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text(if (applied) tx("APPLIED") else tx("APPLY"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            })
        if (promoState == 1) Text("✓ " + tx("Referral code applied"), Modifier.padding(start = 20.dp, bottom = 10.dp), color = Color(0xFF2ECC71), fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (promoState == 2) Text("✗ " + tx("Wrong referral code"), Modifier.padding(start = 20.dp, bottom = 10.dp), color = Color(0xFFFF5252), fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        Text(tx("By Registering, I agree to the"), Modifier.align(Alignment.CenterHorizontally), color = Color.White, fontSize = 16.sp)
        Row(Modifier.align(Alignment.CenterHorizontally)) {
            Text(tx("Terms and Conditions"), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { nav.go("info/terms/Terms and Conditions") })
            Text(" and ", color = Color.White, fontSize = 16.sp); Text(tx("Privacy Policy"), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { nav.go("info/terms/Privacy Policy") })
        }
        Spacer(Modifier.height(20.dp))
        AuthButton(tx("SIGN UP"), Modifier.fillMaxWidth()) {
            if (busy) return@AuthButton
            when {
                code.isBlank() -> ctx.toast(tx("Select country code"))
                listOf(f, un, ph, em, pw).any { it.isBlank() } -> ctx.toast(tx("Fill all required fields"))
                pw.length < 6 -> ctx.toast(tx("Password min 6 characters"))
                promo.isNotBlank() && promoState == 2 -> ctx.toast(tx("Wrong referral code"))
                else -> { busy = true; scope.launch {
                    // A typed code that was never checked with APPLY is verified here, so a wrong code never slips through.
                    if (promo.isNotBlank() && promoState != 1 && !Repo.referralCodeExists(promo)) {
                        promoState = 2; busy = false; ctx.toast(tx("Wrong referral code")); return@launch
                    }
                    val err = Repo.signup(f, l, un, ph, em, promo, pw, code); busy = false
                    if (err == null) nav.navigate("main") { popUpTo(0) } else ctx.toast(err)
                } }
            }
        }
        Spacer(Modifier.height(28.dp))
        Row(Modifier.align(Alignment.CenterHorizontally)) {
            Text(tx("Already have an account? "), color = Color.White, fontSize = 18.sp)
            Text(tx("Login"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { nav.goOrBack("login") })
        }
        Spacer(Modifier.height(36.dp))
    }
}
