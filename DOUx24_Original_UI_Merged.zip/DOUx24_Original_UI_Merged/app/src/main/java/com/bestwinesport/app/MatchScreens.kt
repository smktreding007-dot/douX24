package com.bestwinesport.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.flowOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ONE formatter for all cards (creating a SimpleDateFormat for every card on every scroll frame was slow). Only used on the main thread.
private val dateFmt = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.US)
fun matchDate(ms: Long): String = if (ms <= 0L) tx("Date TBA") else dateFmt.format(Date(ms))

/** Game names seen on the games page, so the match page can show its title the moment it opens. */
object GameNameCache { val names = java.util.concurrent.ConcurrentHashMap<String, String>() }

@Composable
fun GamesScreen(nav: NavController, section: String) {
    var rev by remember { mutableIntStateOf(0) }
    val gamesN by rflowKeep(section, rev, init = null as List<Game>?) { Repo.games(section) }
    val games = gamesN ?: return Loader()
    LaunchedEffect(games) { games.forEach { g -> if (g.id.isNotBlank() && g.name.isNotBlank()) GameNameCache.names[g.id] = g.name } }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // Title bar like the reference: back arrow + "Tournaments" in the theme accent colour.
        Row(Modifier.fillMaxWidth().background(glassOr(Color(0xFF190236))).padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(22.dp).clickable { nav.back() })
            Spacer(Modifier.width(14.dp))
            Text(tx("Tournaments"), color = Purple, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        if (games.isEmpty()) Text(tx("Match not found"), Modifier.fillMaxWidth().padding(48.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 16.sp)
        PullRefresh({ rev++ }, Modifier.weight(1f).fillMaxWidth()) {
        LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(17.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            items(games) { g ->
                val gameMatches by rflow(g.id, init = emptyList<Match>()) { Repo.matches(g.id) }
                val liveCount = gameMatches.count { it.status == "upcoming" || it.status == "ongoing" }
                Column(Modifier.clip(RoundedCornerShape(10.dp)).background(CardC).bounceClick { nav.go("matches/${g.id}") }) {
                    Box {
                        AsyncImage(g.image, null, Modifier.fillMaxWidth().aspectRatio(1.23f), contentScale = ContentScale.Crop)
                        MatchCountBadge(liveCount, Modifier.align(Alignment.TopEnd))
                    }
                    Text(g.name, Modifier.fillMaxWidth().background(LabelC).padding(vertical = 4.dp, horizontal = 2.dp), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, color = onC(LabelC))
                }
            }
        }
        }
    }
}

@Composable
fun MatchCard(m: Match, onClick: () -> Unit, onJoin: () -> Unit, joinedByMe: Boolean = false, showTour: Boolean = false, onTourBounds: (androidx.compose.ui.geometry.Rect, androidx.compose.ui.geometry.Rect) -> Unit = { _, _ -> }) {
    val cardCtx = LocalContext.current
    var joinRect by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    var cardRect by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    LaunchedEffect(showTour, cardRect, joinRect) { val c = cardRect; val j = joinRect; if (showTour && c != null && j != null) onTourBounds(c, j) }
    var showPrize by remember { mutableStateOf(false) }
    if (showPrize) PrizePoolDialog(m) { showPrize = false }
    // Room ID / password the admin already saved: only the player who JOINED sees the green bar (and only then is it readable).
    val room by rflow(m.id, joinedByMe, init = "" to "") { if (joinedByMe) Repo.room(m.id) else flowOf("" to "") }
    var showRoom by remember { mutableStateOf(false) }
    val hasRoom = joinedByMe && m.status != "completed" && (room.first.isNotBlank() || room.second.isNotBlank())
    if (showRoom && hasRoom) RoomDialog(m, room.first, room.second) { showRoom = false }
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
    Column(Modifier.fillMaxWidth().then(if (showTour) Modifier.onGloballyPositioned { cardRect = it.boundsInWindow() } else Modifier).clip(RoundedCornerShape(12.dp)).background(MatchC).slateEdge(RoundedCornerShape(12.dp)).clickable(onClick = onClick)) {
        // FIXED CARD SIZE: every match card has exactly the same height, whatever the banner / title / map text is.
        AsyncImage(m.image, null, Modifier.fillMaxWidth().aspectRatio(2.2f).background(Color(0xFF0D0220)), contentScale = ContentScale.Crop)
        Row(Modifier.fillMaxWidth().height(42.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tag(m.mode, Red); Box(Modifier.weight(1f, fill = false)) { Tag(m.map, Orange) }
        }
        // Round DOUx24 logo before the title: always the app's own logo, nothing to upload or add per match.
        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(androidx.compose.ui.res.painterResource(com.bestwinesport.app.R.drawable.bestwin_loading_logo), null,
                Modifier.size(40.dp).border(2.dp, Color.White, CircleShape).padding(2.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Text("${m.title} - Match #${m.matchNo}", Modifier.weight(1f), fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        if (hasRoom) Text(tx("Click here for Id and Password"), Modifier.fillMaxWidth().padding(top = 8.dp).background(if (m.status == "ongoing") Color(0xFF3D8BFF) else Color(0xFF5ECFB1)).clickable { showRoom = true }.padding(vertical = 2.dp),
            textAlign = TextAlign.Center, color = Color.White, fontSize = 15.sp)
        HorizontalDivider(Modifier.padding(top = 8.dp), color = Color.Gray)
        Row(Modifier.fillMaxWidth().height(78.dp)) {
            Cell(Modifier.weight(1f)) { Text(matchDate(m.startTime), fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2) }
            VerticalDivider(color = Color.Gray)
            Cell(Modifier.weight(1f).clickable(enabled = m.status != "completed") { showPrize = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(tx("PRIZE POOL"), color = Orange, fontSize = 12.sp); if (m.status != "completed") Icon(Icons.Default.KeyboardArrowDown, null, Modifier.size(18.dp), tint = Orange) }
                CoinAmount(money(m.prizePool), 15)
            }
            VerticalDivider(color = Color.Gray)
            Cell(Modifier.weight(1f)) { Text(tx("PER KILL"), color = Orange, fontSize = 12.sp); CoinAmount(money(m.perKill), 15) }
        }
        HorizontalDivider(color = Color.Gray)
        Column(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = 12.dp), verticalArrangement = Arrangement.Center) {
            if (m.status == "upcoming" || m.status == "ongoing" || m.status == "completed") {
                val full = m.status == "upcoming" && !joinedByMe && m.joined >= m.maxPlayers
                val canJoin = m.status == "upcoming" && !joinedByMe && !full
                // Coin + entry fee + JOIN (upcoming) / JOINED / FULL / NOT JOINED. Tapping JOIN starts the join flow.
                val statusBox: @Composable (Modifier) -> Unit = { mod ->
                    val sbBg = if (joinedByMe) Color(0xFF3FBF9F) else ButtonC; val sbFg = onC(sbBg)
                    Row(mod.height(40.dp).then(if (showTour) Modifier.onGloballyPositioned { joinRect = it.boundsInWindow() } else Modifier).clip(RoundedCornerShape(6.dp)).background(sbBg)
                        .clickable(onClick = if (canJoin) onJoin else onClick),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        CoinIcon(18); Spacer(Modifier.width(4.dp)); Text(money(m.fee()), fontWeight = FontWeight.Bold, color = sbFg, fontSize = 14.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(if (joinedByMe) tx("JOINED") else if (full) tx("FULL") else if (canJoin) tx("JOIN") else tx("NOT JOINED"), fontWeight = FontWeight.Bold, color = sbFg, fontSize = 14.sp)
                        if (canJoin) Icon(Icons.Default.ChevronRight, null, Modifier.size(20.dp), tint = sbFg)
                    }
                }
                when (m.status) {
                    // Upcoming: slots filled + progress bar on the left, JOIN button on the right (no WATCH).
                    "upcoming" -> if (full) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${m.joined}/${m.maxPlayers}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            LinearProgressIndicator(progress = { (m.joined.toFloat() / m.maxPlayers.coerceAtLeast(1)).coerceIn(0f, 1f) },
                                Modifier.fillMaxWidth().padding(top = 6.dp), color = Purple, trackColor = Color(0xFF4A1C1C))
                        }
                        Box(Modifier.widthIn(min = 150.dp).height(40.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF757575)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
                            Text(tx("MATCH FULL"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        }
                    } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${m.joined}/${m.maxPlayers}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            LinearProgressIndicator(progress = { (m.joined.toFloat() / m.maxPlayers.coerceAtLeast(1)).coerceIn(0f, 1f) },
                                Modifier.fillMaxWidth().padding(top = 6.dp), color = Purple, trackColor = Color(0xFF4A1C1C))
                        }
                        statusBox(Modifier.widthIn(min = 150.dp))
                    }
                    // Ongoing: one full-width red SPECTATE box (opens the live link). No WATCH / JOINED box.
                    "ongoing" -> Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(8.dp)).background(SpectateRed)
                        .clickable { openLive(cardCtx, watchUrl(m)) }, contentAlignment = Alignment.Center) {
                        Text(tx("SPECTATE"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                    }
                    // Completed (results): WATCH + status box side by side.
                    else -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(6.dp)).background(ButtonC)
                            .clickable { openLive(cardCtx, watchUrl(m)) }, contentAlignment = Alignment.Center) {
                            Text(tx("WATCH"), fontWeight = FontWeight.Bold, color = OnButton, fontSize = 14.sp)
                        }
                        statusBox(Modifier.weight(1f))
                    }
                }
            } else Text(m.status.uppercase(), color = Orange, fontWeight = FontWeight.Bold)
        }
    }
    }
}

@Composable
private fun Cell(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.fillMaxHeight().padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, content = content)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MatchListScreen(nav: NavController, gameId: String) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = 1, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    val tourCtx = LocalContext.current
    var tourId by remember { mutableStateOf<String?>(null) }
    var tourCard by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    var tourJoin by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }   // the one card showing the first-time "Tap here to join" hint
    val allN by rflowKeep(gameId, rev, init = null as List<Match>?) { Repo.matches(gameId) }
    val mine by rflowKeep(rev, init = emptyList<String>()) { Repo.myMatchIds() }
    // Title = the name of the game the player tapped (CS 1 VS 1, LW 1 VS 1 ...), not a fixed text.
    val gameTitle by rflow(gameId, init = GameNameCache.names[gameId].orEmpty()) { Repo.gameName(gameId) }
    val mineSet = remember(mine) { mine.toHashSet() }
    val minDone = rememberMinDelay(300)   // the grey placeholder cards are shown for a moment first; with slow/no internet they simply stay until the list arrives
    val all = allN
    val tabSkel = rememberTapSkeleton(pager.currentPage, showFirst = false)   // tap on ONGOING / UPCOMING / RESULTS: grey cards for a moment first
    // Right after the tap: title + tabs + grey shimmering placeholder cards (same shape as a real match card), then the real matches.
    if (all == null || !minDone) return SkeletonPage(gameTitle, nav, showBalance = true, banner = { SpinBanner(nav, gameId) })
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        BackBar(gameTitle, nav, showBalance = true)
        TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), pager.currentPage) { i -> scope.launch { pager.animateScrollToPage(i) } }
        // Lucky Wheel banner: only shown in the games where the admin turned the spin on.
        SpinBanner(nav, gameId)
        // Swipe left / right to move between Ongoing, Upcoming and Results.
        PullRefresh({ rev++ }, Modifier.fillMaxSize()) {
        androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxSize(), beyondBoundsPageCount = 2) { page ->
            val status = listOf("ongoing", "upcoming", "completed")[page]
            val list = remember(all, page) { all.filter { it.status == status }.let { if (page == 2) it.reversed() else it } }
            if (tabSkel) MatchSkeletonList()
            else if (list.isEmpty()) EmptyMatches(status)
            else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp)) {
                items(list, key = { it.id }) { m ->
                    // First ever tap on an upcoming card (card or JOIN): show the hint on THAT card only, once, and do nothing else.
                    fun firstTap(go: () -> Unit) {
                        if (m.status == "upcoming" && tourId == null && JoinTour.pending(tourCtx)) { JoinTour.markDone(tourCtx); tourId = m.id } else go()
                    }
                    MatchCard(m, { firstTap { nav.go("match/${m.id}") } }, { firstTap { nav.go("pick/${m.id}") } }, m.id in mineSet,
                        showTour = tourId == m.id, onTourBounds = { c, j -> tourCard = c; tourJoin = j })
                }
            }
        }
        }
    }
    // First-time hint (full screen, round spotlight on JOIN). Shown only after the tapped card has reported where it is.
    val tc = tourCard; val tj = tourJoin
    if (tourId != null && tc != null && tj != null) JoinTourOverlay(tc, tj, { tourId = null; tourCard = null; tourJoin = null }, Modifier.fillMaxSize())
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MyMatchesScreen(nav: NavController, start: String) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(initialPage = listOf("ongoing", "upcoming", "completed").indexOf(start).coerceAtLeast(0), pageCount = { 3 })
    val scope = rememberCoroutineScope()
    var rev by remember { mutableIntStateOf(0) }
    val allN by rflowKeep(rev, init = null as List<Match>?) { Repo.myMatches() }
    val tabSkel = rememberTapSkeleton(pager.currentPage, showFirst = false)
    val all = allN ?: return SkeletonPage(tx("My Matches"), nav)
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("My Matches"), nav)
        TabsRow(listOf(tx("ONGOING"), tx("UPCOMING"), tx("RESULTS")), pager.currentPage) { i -> scope.launch { pager.animateScrollToPage(i) } }
        PullRefresh({ rev++ }, Modifier.fillMaxSize()) {
        androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxSize(), beyondBoundsPageCount = 2) { page ->
            val status = listOf("ongoing", "upcoming", "completed")[page]
            val shown = remember(all, page) { all.filter { it.status == status } }
            if (tabSkel) MatchSkeletonList()
            else if (shown.isEmpty()) EmptyMatches(status)
            else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp)) {
                items(shown, key = { it.id }) { m ->
                    MatchCard(m, { if (m.archived) nav.go("myresult/${m.id}") else nav.go("match/${m.id}") }, { nav.go("pick/${m.id}") }, true)
                }
            }
        }
        }
    }
}

@Composable
fun MatchDetailScreen(nav: NavController, id: String) {
    var rev by remember { mutableIntStateOf(0) }
    val m by rflowKeep(id, rev, init = null as Match?) { Repo.match(id) }
    val slots by rflowKeep(id, rev, init = emptyMap<String, Slot>()) { Repo.slots(id) }
    val results by rflowKeep(id, rev, init = emptyList<Res>()) { Repo.results(id) }
    val mySlots = slots.values.count { it.uid == Repo.uid() }
    val joined = mySlots > 0
    val room by rflowKeep(id, joined, rev, init = "" to "") { if (joined) Repo.room(id) else flowOf("" to "") }
    var tab by remember { mutableIntStateOf(0) }
    var editKey by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val minShown = rememberMinDelay(100)
    val match = m
    if (match == null || !minShown) return Loader()
    val liveCtx = LocalContext.current
    if (match.status == "completed") { MatchResultPage(nav, match); return }
    editKey?.let { k ->
        val cur = slots[k]?.ign.orEmpty().ifBlank { slots[k]?.username.orEmpty() }
        EditNameDialog(cur, onDismiss = { editKey = null }) { newName ->
            if (newName.trim() == cur.trim()) liveCtx.toast(tx("Player name not changed"))
            else scope.launch { val err = Repo.updateIgn(id, k, newName); liveCtx.toast(err ?: tx("Player name updated")); if (err == null) editKey = null }
        }
    }
    // FIXED LOOK: this page keeps the same colours and the same box sizes in every theme (white page, black bar + tabs, orange headings, purple button).
    androidx.compose.runtime.CompositionLocalProvider(LocalContentColor provides Color.Black) {
    Column(Modifier.fillMaxSize().background(Color.White)) {
        DetailBackBar(match.title, nav)
        PullRefresh({ rev++ }, Modifier.weight(1f).fillMaxWidth()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            AsyncImage(match.image, null, Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 10.dp)
                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)).aspectRatio(2.07f).background(Color(0xFF0D0220)), contentScale = ContentScale.Crop)
            DetailTabs(listOfNotNull(tx("DESCRIPTION"), tx("JOINED MEMBER"), if (match.status == "completed") tx("RESULT") else null), tab) { tab = it }
            when (tab) {
                0 -> Column(Modifier.padding(horizontal = 10.dp, vertical = 14.dp)) {
                    Text("${match.title} - Match #${match.matchNo}", color = DetailOrange, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    if (match.matchId.isNotBlank()) { DetailChip("Match ID", match.matchId); Spacer(Modifier.height(8.dp)) }
                    // One chip per line (like the reference) so long texts never get squeezed.
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { DetailChip("Team", match.mode); DetailChip("Entry Fee", money(match.fee()), coin = true) }
                        DetailChip("Match Type", match.type)
                        DetailChip("Map", match.map)
                        DetailChip("Match Schedule", matchDate(match.startTime))
                    }
                    if (joined) {
                        // "Room Detail": my team / position / player name, with a pencil to edit the in-game name (until the match starts).
                        val teal = Color(0xFF5ECFB1)
                        Text(tx("Room Detail"), Modifier.padding(top = 14.dp, bottom = 6.dp), color = DetailOrange, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        // Separate card for the Room ID / Password the admin gave. Tapping the card does nothing - only the COPY buttons copy.
                        if (room.first.isNotBlank() || room.second.isNotBlank()) { RoomCard(room.first, room.second); Spacer(Modifier.height(10.dp)) }
                        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 3.dp).lifted().clip(RoundedCornerShape(4.dp))) {
                            Row(Modifier.fillMaxWidth().background(teal).padding(vertical = 9.dp, horizontal = 8.dp)) {
                                Text(tx("Team"), Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                                Text(tx("Position"), Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                                Text(tx("Player Name"), Modifier.weight(1.5f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                            }
                            slots.entries.filter { it.value.uid == Repo.uid() }.sortedBy { it.key }.forEach { (k, sl) ->
                                val t = k.substringAfter('t').substringBefore('_'); val pos = k.substringAfter('_').toIntOrNull() ?: 1
                                val solo = match.perTeam() == 1
                                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (solo) tx("Solo") else "Team$t", Modifier.weight(1f), color = Color(0xFF2B2B2B), fontSize = 13.sp, textAlign = TextAlign.Center)
                                    Text(if (solo) t else "ABCD".getOrElse(pos - 1) { '?' }.toString(), Modifier.weight(1f), color = Color(0xFF2B2B2B), fontSize = 13.sp, textAlign = TextAlign.Center)
                                    Row(Modifier.weight(1.5f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                        Text(sl.ign.ifBlank { sl.username }, color = Color(0xFF2B2B2B), fontSize = 13.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                        if (match.status == "upcoming") Icon(Icons.Default.Edit, null, Modifier.padding(start = 8.dp).size(18.dp).clickable { editKey = k }, tint = Color(0xFF2B2B2B))
                                    }
                                }
                            }
                        }
                    }
                    Text(tx("Price Details"), Modifier.padding(top = 14.dp, bottom = 6.dp), color = DetailOrange, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { DetailChip("Winning Prize", money(match.prizePool), coin = true); DetailChip("Per Kill", money(match.perKill), coin = true) }
                    Text(tx("About this Match"), Modifier.padding(top = 14.dp, bottom = 6.dp), color = DetailOrange, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(tx("Rules :-"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(match.rules, Modifier.padding(top = 10.dp), fontSize = 13.sp, lineHeight = 20.sp)
                }
                1 -> Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                    // Everyone who joined, numbered 1, 2, 3 ... in the order they joined (older joins without a time fall back to slot order).
                    if (slots.isEmpty()) Text(tx("No one has joined yet"), color = Color.Gray)
                    else Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color.White)) {
                        val ordered = slots.entries.sortedWith(compareBy<Map.Entry<String, Slot>>({ if (it.value.ts > 0) it.value.ts else Long.MAX_VALUE }, { it.key.filter(Char::isDigit).padStart(6, '0') }))
                        ordered.forEachIndexed { i, (_, s) ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${i + 1}.", Modifier.width(34.dp), color = Color(0xFF2B2B2B), fontSize = 15.sp)
                                Text(s.ign.ifBlank { s.username }, Modifier.weight(1f), color = Color(0xFF2B2B2B), fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            }
                            HorizontalDivider(color = Color(0xFFDADADA))
                        }
                    }
                }
                else -> Column(Modifier.padding(14.dp)) {
                    results.sortedByDescending { it.prize }.forEach { r ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp)).background(MatchC).slateEdge(RoundedCornerShape(8.dp)).padding(14.dp)) {
                            Text(r.ign.ifBlank { r.username }, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text("${r.kills} kills", color = Color.Gray); Spacer(Modifier.width(12.dp)); Row(verticalAlignment = Alignment.CenterVertically) { CoinIcon(16); Spacer(Modifier.width(4.dp)); Text(money(r.prize), color = Color(0xFFFFC107)) }
                        }
                    }
                }
            }
        }
        }
        if (match.status == "ongoing") DetailBottomBtn(tx("SPECTATE"), true) { openLive(liveCtx, watchUrl(match)) }
        if (match.status == "upcoming") DetailBottomBtn(if (!joined) (if (match.joined >= match.maxPlayers) tx("MATCH FULL") else tx("JOIN NOW")) else tx("JOINED"),
            !joined && match.joined < match.maxPlayers) { nav.go("pick/$id") }
    }
    }
}

private val DetailOrange = Color(0xFFEF6002)
private val DetailButton = Color(0xFF6100FF)

/** Bottom button of the match page: flat, full width, 40 dp high, same SOLID purple in every theme and every state (JOIN NOW / JOINED / MATCH FULL - never faded). */
@Composable
private fun DetailBottomBtn(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(40.dp).background(DetailButton).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

/** Top bar of the match page: always black with white text, whatever the theme. */
@Composable
private fun DetailBackBar(title: String, nav: NavController) {
    Column(Modifier.fillMaxWidth().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(22.dp).clickable { nav.back() }, tint = Color.White)
            Spacer(Modifier.width(14.dp))
            Text(title, Modifier.weight(1f), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
    }
}

/** DESCRIPTION / JOINED MEMBER strip: fixed black strip, orange when selected, white otherwise (same in every theme). */
@Composable
private fun DetailTabs(tabs: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp).height(40.dp).background(Color.Black)) {
        tabs.forEachIndexed { i, t ->
            Box(Modifier.weight(1f).fillMaxHeight().clickable { onSel(i) }, contentAlignment = Alignment.Center) {
                Text(t, color = if (i == sel) DetailOrange else Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            }
        }
    }
}

/** The ONE look for every white box on the match page: lifted off the page by the same soft shadow as the "Per Kill" box (no outline). */
private fun Modifier.lifted(radius: androidx.compose.ui.unit.Dp = 4.dp): Modifier =
    this.shadow(3.dp, RoundedCornerShape(radius)).background(Color.White)

/** White info box of the match page: fixed height (38 dp), fixed padding, label normal + value bold. */
@Composable
private fun DetailChip(label: String, value: String, coin: Boolean = false) {
    // Soft shadow only (no hard grey line under the box).
    Row(Modifier.padding(start = 3.dp, bottom = 3.dp).lifted().height(38.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(tx(label), color = Color.Black, fontSize = 13.sp)
        if (coin) { Spacer(Modifier.width(8.dp)); CoinIcon(17); Spacer(Modifier.width(8.dp)) }
        Text(" : ", color = Color.Black, fontSize = 13.sp)
        Text(value, color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** Remembers the player's in-game name per game (e.g. Free Fire) on this phone, so the next match of that game is pre-filled. */
object SavedIgn {
    private fun prefs(ctx: android.content.Context) = ctx.getSharedPreferences("saved_ign", android.content.Context.MODE_PRIVATE)
    fun get(ctx: android.content.Context, uid: String, gameId: String): String =
        if (uid.isBlank() || gameId.isBlank()) "" else prefs(ctx).getString("$uid|$gameId", "").orEmpty()
    fun set(ctx: android.content.Context, uid: String, gameId: String, name: String) {
        if (uid.isBlank() || gameId.isBlank() || name.isBlank()) return
        prefs(ctx).edit().putString("$uid|$gameId", name.trim()).apply()
    }
}

@Composable
fun PickScreen(nav: NavController, id: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val m by rflow(id, init = null as Match?) { Repo.match(id) }
    val slots by rflow(id, init = emptyMap<String, Slot>()) { Repo.slots(id) }
    val user by rflow(init = User()) { Repo.me() }
    val gName by rflow(m?.gameId ?: "", init = "") { val gid = m?.gameId.orEmpty(); if (gid.isBlank()) flowOf("") else Repo.gameName(gid) }
    val picked = remember { mutableStateListOf<String>() }
    val ign = remember { mutableStateMapOf<String, String>() }
    var stage by remember { mutableIntStateOf(0) }
    var editKey by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showCode by remember { mutableStateOf(false) }
    var codeOk by remember { mutableStateOf(false) }
    val cfg by rflow(init = emptyMap<String, Any?>()) { Repo.settings() }
    val minShown = rememberMinDelay(100)
    val match = m
    if (match == null || !minShown) return Loader()
    val letters = "ABCDEF"
    val myCount = slots.values.count { it.uid == Repo.uid() }
    val remaining = if (myCount > 0) 0 else match.perTeam()   // one join per match: once joined, only "JOINED" is shown
    fun goHome() { if (!nav.popBackStack("main", false)) nav.navigate("main") { popUpTo(0) } }
    fun toggle(key: String, checked: Boolean) {
        if (!checked) picked.remove(key)
        else { if (remaining == 1) picked.clear(); if (picked.size >= remaining) ctx.toast("${match.mode}: ${tx("Max slots per player")} ${match.perTeam()}") else {
            picked.add(key)
            // First position = the player himself: fill the name he used before for this game (he can still tap it to change).
            if (picked.size == 1 && ign[key].isNullOrBlank()) SavedIgn.get(ctx, Repo.uid(), match.gameId).takeIf { it.isNotBlank() }?.let { ign[key] = it }
        } }
    }
    BackHandler(stage == 1) { stage = 0 }
    BackHandler(stage == 2) { goHome() }
    val nameLabel = if (gName.isBlank()) tx("In-game name") else "$gName ${tx("Name")}"
    fun doJoin() {
        if (busy) return   // a join is already running: a second tap does nothing (the button keeps its JOIN look)
        val missing = picked.firstOrNull { ign[it].isNullOrBlank() }
        if (missing != null) { if (picked.size == 1) editKey = missing else ctx.toast(tx("Add in-game name for every position")); return }
        // Match with an access code: the Verify Code card opens first; the seat is taken only after the code is correct.
        if (match.hasAccessCode && !codeOk) { showCode = true; return }
        busy = true
        scope.launch {
            val err = Repo.join(match, picked.toList(), ign.toMap(), user.username); busy = false
            if (err == null) {
                SavedIgn.set(ctx, Repo.uid(), match.gameId, ign[picked.sorted().first()].orEmpty())
                stage = 2
            } else ctx.toast(err)
        }
    }

    StepSlide(stage) { st ->
    if (st == 2) {
        // "Joined" page: FIXED look (black page, teal tick, dark-purple HOME button) - it does not follow the app theme / colour scheme.
        val joinTeal = Color(0xFF5DCEB2); val joinBtn = Color(0xFF190236)
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 25.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(105.dp).clip(androidx.compose.foundation.shape.CircleShape).background(joinTeal), contentAlignment = Alignment.Center) {
                    androidx.compose.foundation.Canvas(Modifier.size(105.dp)) {
                        val c = center; val d = density
                        val tick = androidx.compose.ui.graphics.Path().apply {
                            moveTo(c.x - 32f * d, c.y + 2.3f * d); lineTo(c.x - 9f * d, c.y + 26f * d); lineTo(c.x + 33f * d, c.y - 17f * d)
                        }
                        drawPath(tick, Color.Black, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 10f * d, join = androidx.compose.ui.graphics.StrokeJoin.Miter))
                    }
                }
                Spacer(Modifier.height(42.dp))
                Text("${match.title}  - Match #${match.matchNo}", textAlign = TextAlign.Center, fontSize = 13.sp, color = Color.White)
                Spacer(Modifier.height(26.dp))
                Text(tx("You have joined successfully."), color = joinTeal, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(36.dp))
                Button({ goHome() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = joinBtn, contentColor = Color.White)) {
                    Text(tx("HOME"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                }
            }
        }
    } else if (st == 0) {
        Column(Modifier.fillMaxSize()) {
            BackBar(match.title, nav)
            Text(tx("Select Match Position"), Modifier.fillMaxWidth().padding(top = 12.dp, start = 12.dp, end = 12.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            Text(if (remaining == 0) tx("You have already joined this match") else "${match.mode} • ${tx("Max slots per player")}: ${match.perTeam()}",
                Modifier.fillMaxWidth().padding(bottom = 8.dp), textAlign = TextAlign.Center, fontSize = 12.sp, color = if (remaining == 0) Orange else Color.Gray)
            if (match.perTeam() == 1) {
                // SOLO: numbered grid, 4 per row. Orange tick = already taken.
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                    items((1..match.teams()).toList().chunked(4)) { nums ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            nums.forEach { n ->
                                val key = "t${n}_1"; val taken = slots.containsKey(key)
                                // Number and box sit close together (number in a fixed-width slot, box right next to it); one row = 30 dp; the whole cell is the tap area.
                                Row(Modifier.weight(1f).height(30.dp).clickable(enabled = !taken) { toggle(key, key !in picked) },
                                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                    Text("$n", Modifier.width(26.dp), fontSize = 15.sp, textAlign = TextAlign.Center, maxLines = 1)
                                    Spacer(Modifier.width(3.dp))
                                    CompactCheckbox(taken || key in picked, enabled = !taken) { c -> toggle(key, c) }
                                }
                            }
                            repeat(4 - nums.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            } else {
                // DUO / SQUAD / 3vs3 / 5vs5 / 6vs6: one row per team with A, B, C... positions.
                Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                    Text(tx("Team"), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    repeat(match.perTeam()) { Text(letters[it].toString(), Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 24.dp)) {
                    items((1..match.teams()).toList()) { t ->
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Team $t", Modifier.weight(1f))
                            for (p in 1..match.perTeam()) {
                                val key = "t${t}_$p"
                                val taken = slots.containsKey(key)
                                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                    Text("$p")
                                    if (match.perTeam() > 4) CompactCheckbox(taken || key in picked, enabled = !taken) { c -> toggle(key, c) }   // 5 / 6 per team: smaller boxes so the row fits
                                    else Checkbox(taken || key in picked, { c -> toggle(key, c) }, enabled = !taken,
                                        colors = CheckboxDefaults.colors(checkedColor = Orange, uncheckedColor = Orange))
                                }
                            }
                        }
                    }
                }
            }
            Btn(tx("JOIN NOW"), Modifier.fillMaxWidth(), enabled = picked.isNotEmpty()) { stage = 1 }
        }
    } else {
        val total = match.fee() * picked.size
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().background(JoinBoxC).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.clickable { stage = 0 }, tint = Purple); Spacer(Modifier.width(16.dp))
                Text(tx("Joining Match"), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Purple)
            }
            Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.Top) {
                // Wallet picture on the left (same size as the reference screenshot: ~83 x 91 dp), balance lines on the right
                androidx.compose.foundation.Image(androidx.compose.ui.res.painterResource(com.bestwinesport.app.R.drawable.ic_wallet_join), null,
                    Modifier.padding(top = 4.dp).width(83.dp).height(91.dp), contentScale = ContentScale.Fit)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    InfoLine(tx("Your Current Balance :"), fmt(user.balance()))
                    InfoLine(tx("Match Entry Fee Per Person :"), money(match.fee()))
                    InfoLine(tx("Total Payable Amount :"), money(total))
                }
            }
            Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(8.dp))) {
                Text(tx("Selected Position"), Modifier.fillMaxWidth().background(JoinBoxC).padding(14.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, color = Purple)
                Column(Modifier.fillMaxWidth().background(JoinBodyC).padding(vertical = 14.dp, horizontal = 8.dp)) {
                    Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tx("Team"), Modifier.weight(1f), color = Color.Black, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, fontSize = 14.sp)
                        Text(tx("Position"), Modifier.weight(1f), color = Color.Black, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, fontSize = 14.sp)
                        Text(nameLabel, Modifier.weight(1.4f), color = Color.Black, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, fontSize = 14.sp)
                    }
                    picked.sorted().forEach { k ->
                        val (t, p) = k.removePrefix("t").split("_")
                        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Team $t", Modifier.weight(1f), color = JoinInkC, textAlign = TextAlign.Center)
                            Text(p, Modifier.weight(1f), color = JoinInkC, textAlign = TextAlign.Center)
                            val nm = ign[k].orEmpty()
                            Box(Modifier.weight(1.4f), contentAlignment = Alignment.Center) {
                                if (nm.isBlank()) {
                                    // "Add info": dark pill with white text (like the reference), readable on the white box
                                    Text(tx("Add info"), Modifier.clip(RoundedCornerShape(6.dp)).background(JoinAddInfoC).clickable { editKey = k }.padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = Color.White, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 1)
                                } else {
                                    Text(nm, Modifier.clickable { editKey = k }, color = JoinInkC, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            Row(Modifier.padding(24.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                // CANCEL: solid yellow-orange button, white text, NO outline (fixed colour, same in every theme)
                Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp)).background(JoinCancelC)
                    .clickable { stage = 0 }, contentAlignment = Alignment.Center) {
                    Text(tx("CANCEL"), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                Btn(tx("JOIN"), Modifier.weight(1f)) { doJoin() }   // always reads JOIN, never turns grey / "..." while the join runs
            }
            // Note sits LOWER on the page (big gap under the buttons), like the reference screenshot
            Spacer(Modifier.height(185.dp))
            Text(tx("Note - Please Enter Your In Game Username/ Name."), Modifier.padding(horizontal = 20.dp), color = Orange, fontSize = 17.sp, lineHeight = 23.sp)
        }
        if (showCode) {
            var code by remember { mutableStateOf("") }
            var checking by remember { mutableStateOf(false) }
            fun link(k: String) = cfg[k]?.toString().orEmpty()
            AppDialog(title = tx("Verify Code"), onDismiss = { showCode = false }, confirmText = tx("VERIFY"), confirmEnabled = true,   // always reads VERIFY, never turns grey / "..." while checking
                onConfirm = {
                    if (checking) { /* a check is already running: a second tap does nothing */ }
                    else if (code.isBlank()) ctx.toast(tx("Enter the access code"))
                    else { checking = true; scope.launch {
                        val err = Repo.verifyAccessCode(match, code); checking = false
                        if (err == null) { codeOk = true; showCode = false; doJoin() } else ctx.toast(err)
                    } }
                }) {
                // Both links come from Admin -> Settings.
                Text("\u2B50 " + tx("How To Get Access Code"), Modifier.fillMaxWidth().clickable { ctx.openLink(link("accessHowToUrl")) }.padding(vertical = 8.dp),
                    textAlign = TextAlign.Center, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text("\u2B50 " + tx("Click Here To Get Access Code"), Modifier.fillMaxWidth().clickable { ctx.openLink(link("accessCodeUrl")) }.padding(vertical = 8.dp),
                    textAlign = TextAlign.Center, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                TextField(code, { code = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text(tx("Enter Access Code")) }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Color.Black,
                        focusedIndicatorColor = Color.DarkGray, unfocusedIndicatorColor = Color.DarkGray,
                        focusedLabelColor = Color.DarkGray, unfocusedLabelColor = Color.DarkGray))
            }
        }
        editKey?.let { k ->
            var v by remember(k) { mutableStateOf(ign[k] ?: "") }
            val single = picked.size == 1
            AppDialog(title = tx("Join Match"), onDismiss = { editKey = null }, dismissText = tx("CANCEL"),
                confirmText = if (single) tx("JOIN") else tx("SAVE"),
                onConfirm = {
                    if (v.isBlank()) ctx.toast(tx("Add in-game name for every position"))
                    else { ign[k] = v.trim(); editKey = null }  // only saves the name; the user stays on this page and taps JOIN again to really join
                }) {
                TextField(v, { v = it }, Modifier.fillMaxWidth(), label = { Text(nameLabel) }, singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 20.sp),
                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Color.Black,
                        focusedIndicatorColor = Color.DarkGray, unfocusedIndicatorColor = Color.DarkGray,
                        focusedLabelColor = Color.DarkGray, unfocusedLabelColor = Color.DarkGray))
                Text(tx("Make sure you have entered correct information"), Modifier.padding(top = 22.dp, bottom = 12.dp), fontSize = 17.sp, lineHeight = 22.sp)
            }
        }
    }
    }
}

/** Same fixed box colour as the Home Ongoing / Upcoming / Completed icon boxes. */
private val JoinBoxC = Color(0xFF190236)
/** Joining Match: name box is PERMANENTLY white (all themes); dark text on it; CANCEL is a solid yellow-orange button. */
private val JoinBodyC = Color.White
private val JoinInkC = Color(0xFF333333)
private val JoinAddInfoC = Color(0xFF212538)
private val JoinCancelC = Color(0xFFF6AF08)

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp); Spacer(Modifier.width(6.dp)); CoinIcon(22); Spacer(Modifier.width(6.dp)); Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}


/** A match image shown COMPLETE (never cropped): full width, natural height. */
@Composable
fun FullImage(url: String, modifier: Modifier = Modifier, corner: Int = 0) {
    // The image's real shape is remembered per link, so the card keeps its size while the picture loads and list does not jump when scrolling.
    var ratio by remember(url) { mutableFloatStateOf(imageRatios[url] ?: 2.07f) }
    AsyncImage(model = url, contentDescription = null, modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(corner.dp)).aspectRatio(ratio),
        contentScale = ContentScale.FillWidth,
        onSuccess = { st ->
            val d = st.result.drawable
            if (d.intrinsicWidth > 0 && d.intrinsicHeight > 0) { val r = d.intrinsicWidth.toFloat() / d.intrinsicHeight; imageRatios[url] = r; ratio = r }
        })
}

private val imageRatios = java.util.concurrent.ConcurrentHashMap<String, Float>()

@Composable
fun CoinAmount(value: String, sp: Int, color: Color = Color.Unspecified) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CoinIcon(sp + 3); Spacer(Modifier.width(4.dp)); Text(value, fontSize = sp.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

/** White label + gold coin + amount, e.g. "Winning Prize : (C) 300". */
@Composable
fun CoinChip(label: String, value: String, big: Boolean = true) {
    val sp = if (big) 13 else 12
    Row(Modifier.padding(bottom = 3.dp).lifted().padding(horizontal = if (big) 10.dp else 8.dp, vertical = if (big) 7.dp else 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("${tx(label)} : ", color = Color.Black, fontSize = sp.sp)
        CoinIcon(sp + 5); Spacer(Modifier.width(4.dp))
        Text(value, color = Color.Black, fontSize = sp.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ResultTable(title: String, rows: List<Res>, decimals: Boolean, pinned: List<Int> = emptyList()) {
    // pinned = positions (0-based) of the logged-in player's own rows: they are shown FIRST with their real rank, then the rest of the list follows (without them).
    // The player's own row(s) move to the top and are taken OUT of the list below, so the name never shows twice.
    val top = pinned.distinct().filter { it in rows.indices }
    val order = top + rows.indices.filter { it !in top }
    val dark = ResultHeadBg; val ink = Color(0xFF222222)
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 18.dp).clip(RoundedCornerShape(4.dp))) {
        Text(title, Modifier.fillMaxWidth().background(ResultTitleBg).padding(vertical = 11.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
        Row(Modifier.fillMaxWidth().background(dark).padding(vertical = 10.dp, horizontal = 4.dp)) {
            listOf("#" to 0.6f, tx("Player Name") to 2.2f, tx("Kills") to 1f, tx("Winning") to 1.3f).forEach { (t, w) ->
                Text(t, Modifier.weight(w), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White, maxLines = 1)
            }
        }
        order.forEachIndexed { n, i ->
            val r = rows[i]
            Row(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 9.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${i + 1}", Modifier.weight(0.6f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp)
                Text(r.ign.ifBlank { r.username }, Modifier.weight(2.2f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text("${r.kills}", Modifier.weight(1f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp)
                Text(if (decimals) fmt(r.prize) else money(r.prize), Modifier.weight(1.3f), textAlign = TextAlign.Center, color = ink, fontSize = 14.sp)
            }
            if (n < order.lastIndex) HorizontalDivider(color = Color(0xFFDDDDDD))
        }
    }
}

/**
 * Finished match page: full image, details, a separate WINNER card (Solo = top 1, Duo = top 2, Squad = top 4)
 * and the full Match Result table below (the winners stay in it too).
 */
/** Fixed (theme-independent) colours of the Winner / Match Result tables: they never change with the selected theme. */
internal val ResultTitleBg = Color(0xFF1A0038)   // dark purple title strips ("Winner", "Match Result")
internal val ResultHeadBg = Color(0xFF343A40)    // dark grey column header row (# / Player Name / Kills / Winning)

@Composable
fun MatchResultPage(nav: NavController, match: Match) {
    val resN by rflow(match.id, match.archived, init = null as List<Res>?) { if (match.archived) Repo.savedResults(match.id) else Repo.results(match.id) }
    val me by rflow(init = User()) { Repo.me() }
    // null = still loading (so the username is never flashed/used while the saved game name is on its way)
    val myNamesN by rflow(match.id, match.archived, init = null as List<String>?) { if (match.archived) Repo.savedNames(match.id) else flowOf(emptyList<String>()) }
    val resCtx = LocalContext.current
    // Fallback chain for a deleted match: saved in-game name(s) of this match -> in-game name last used for this game on this phone. Never the account username.
    val myNames = remember(myNamesN, match.gameId) {
        myNamesN.orEmpty().ifEmpty { SavedIgn.get(resCtx, Repo.uid(), match.gameId).takeIf { it.isNotBlank() }?.let { listOf(it) } ?: emptyList() }
    }
    val waited = rememberMinDelay(2500)
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Match Result"), nav)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
            FullImage(match.image, Modifier.fillMaxWidth().padding(14.dp), 6)
            Text("${match.title} - Match #${match.matchNo}", Modifier.padding(horizontal = 14.dp), color = Orange, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.padding(bottom = 3.dp).lifted().padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Text("${tx("Organised on")} ", color = Color.Black, fontSize = 13.sp)
                    Text(matchDate(match.startTime).lowercase(), color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CoinChip("Winning Prize", money(match.prizePool)); CoinChip("Per Kill", money(match.perKill))
                }
                CoinChip("Entry Fee", money(match.fee()))
            }
            if (match.comment.isNotBlank()) Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 8.dp)) {
                Text(tx("Comment"), color = Color(0xFF4FD1A5), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text(match.comment.trim(), Modifier.padding(top = 4.dp), color = Color(0xFF8E8EA0), fontSize = 16.sp, lineHeight = 22.sp)
            }
            // The admin deleted this match without declaring a result (nothing was paid): the player still gets the Winner title strip and the
            // Match Result table (his own name, Kills 0, Winning 0); the Winner card itself is not built, only its title strip.
            val noResultRows = if (match.archived && resN?.isEmpty() == true && me.username.isNotBlank())
                (myNames.ifEmpty { listOf("-") }).map { n -> Res(username = me.username, ign = n, kills = 0, prize = 0.0) } else emptyList()
            val res = if (noResultRows.isNotEmpty()) noResultRows else resN
            val waitingForName = match.archived && resN?.isEmpty() == true && (me.username.isBlank() || myNamesN == null) && !waited
            if (res == null || waitingForName) Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { RotatingLoadingLogo() }
            else if (res.isEmpty()) Text(tx("Result will be updated soon"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 16.sp)
            else {
                val ranked = res.sortedWith(compareByDescending<Res> { it.prize }.thenByDescending { it.kills })
                // Deleted match without a result: nobody won, so the Winner card is NOT built - only its title strip is shown.
                if (noResultRows.isNotEmpty()) Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 18.dp).clip(RoundedCornerShape(4.dp))) {
                    Text(tx("Winner"), Modifier.fillMaxWidth().background(ResultTitleBg).padding(vertical = 11.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                } else ResultTable(tx("Winner"), ranked.take(match.perTeam()), true)
                // The player's own row(s) come first in the Match Result table, so nobody has to scroll down to find their result.
                val mine = if (me.username.isBlank()) emptyList() else ranked.indices.filter { ranked[it].username.equals(me.username, ignoreCase = true) }
                ResultTable(tx("Match Result"), ranked, false, mine)
            }
        }
    }
}


/** Popup opened by tapping PRIZE POOL on a match card: docked at the BOTTOM of the screen. Lines come from the admin's "Prize pool details" (plain text, no coin icon). */
@Composable
fun PrizePoolDialog(m: Match, onDismiss: () -> Unit) {
    val none = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().clickable(interactionSource = none, indication = null) { onDismiss() }, contentAlignment = Alignment.BottomCenter) {
            Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 46.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color.White).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Close, null, Modifier.size(16.dp), tint = Color(0xFFE01B10))
                }
                Spacer(Modifier.height(6.dp))
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).clickable(interactionSource = none, indication = null) { }) {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF1B0238)).padding(horizontal = 10.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(tx("PRIZE POOL"), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${m.title} - Match #${m.matchNo}", color = Color.White, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
                    }
                    Column(Modifier.fillMaxWidth().heightIn(min = 38.dp).padding(horizontal = 12.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val lines = m.prizeDetails.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        // No prize details written by the admin = empty white box (nothing is invented here).
                        lines.forEach { ln ->
                            val parts = ln.split(":-", limit = 2)
                            if (parts.size == 2) Text("${parts[0].trim()} :-  ${parts[1].trim().removePrefix("\u20B9").trim()}", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                            else Text(ln, color = Color.Black, fontSize = 13.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

/** "Edit Playername" popup (black title bar, CANCEL / SAVE) like the reference. */
@Composable
fun EditNameDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var v by remember { mutableStateOf(current) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(Color.White).padding(14.dp)) {
            Box(Modifier.fillMaxWidth().background(Color.Black).padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Text(tx("Edit Playername"), color = Color.White, fontSize = 16.sp)
            }
            TextField(v, { v = it.take(30) }, Modifier.fillMaxWidth().padding(top = 14.dp), singleLine = true,
                colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, focusedIndicatorColor = Color.Black, unfocusedIndicatorColor = Color.Black, cursorColor = Color.Black))
            Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF1B0035)).clickable { onDismiss() }, contentAlignment = Alignment.Center) {
                    Text(tx("CANCEL"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF5ECFB1)).clickable { onSave(v) }, contentAlignment = Alignment.Center) {
                    Text(tx("SAVE"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Opened from the green "Click here for Id and Password" bar on a joined match card. */
@Composable
fun RoomDialog(m: Match, roomId: String, roomPass: String, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White)) {
            Box(Modifier.fillMaxWidth().background(Color(0xFF1B0238)).padding(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tx("Room ID & Password"), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${m.title} - Match #${m.matchNo}", color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
                }
                Icon(Icons.Default.Close, null, Modifier.align(Alignment.TopEnd).size(22.dp).clickable(onClick = onDismiss), tint = Color.White)
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (roomId.isNotBlank()) CopyLine(roomId, tx("Room ID Copied Successfully"))
                if (roomPass.isNotBlank()) CopyLine(roomPass, tx("Password Copied Successfully"))
                Text(tx("Tap to copy"), color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}


/** WATCH / SPECTATE: opens the link straight in the YouTube app; if YouTube is not installed it falls back to the default app / browser. */
fun openLive(ctx: android.content.Context, url: String) {
    val uri = android.net.Uri.parse(url.trim())
    fun view() = android.content.Intent(android.content.Intent.ACTION_VIEW, uri).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(view().setPackage("com.google.android.youtube")) }
    catch (e: Exception) {
        try { ctx.startActivity(view()) } catch (e2: Exception) { ctx.toast(tx("Could not open the link")) }
    }
}


/** Link behind SPECTATE / WATCH: the admin's "Live / Watch link" of the match, or this permanent channel when the admin leaves it empty. */
const val DEFAULT_WATCH_URL = "https://www.youtube.com/@developercodex"
fun watchUrl(m: Match): String = m.liveUrl.trim().ifBlank { DEFAULT_WATCH_URL }


/** Result page opened from "My Matches -> Results" for a match the admin has since removed (built from the player's own saved copy). */
@Composable
fun MyResultScreen(nav: NavController, id: String) {
    val all by rflow(init = null as List<Match>?) { Repo.myMatches() }
    val m = all?.firstOrNull { it.id == id }
    if (m != null) MatchResultPage(nav, m)
    else Column(Modifier.fillMaxSize()) {
        BackBar(tx("Match Result"), nav)
        if (all == null) Loader() else Text(tx("Match not found"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
    }
}


/** One tappable line: tapping the text copies it and shows a toast. */
@Composable
private fun CopyLine(value: String, copiedMsg: String) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    Text(value, Modifier.clip(RoundedCornerShape(4.dp)).clickable { clip.setText(AnnotatedString(value)); ctx.toast(copiedMsg) }.padding(horizontal = 14.dp, vertical = 6.dp),
        color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)
}

/** White card shown only when the admin has given a Room ID / Password: ID on top, password below, both centred. Tap a line to copy it. */
@Composable
fun RoomCard(roomId: String, roomPass: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 3.dp).lifted().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (roomId.isNotBlank()) CopyLine(roomId, tx("Room ID Copied Successfully"))
        if (roomPass.isNotBlank()) CopyLine(roomPass, tx("Password Copied Successfully"))
    }
}
