package com.bestwinesport.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * World chat (WhatsApp style: text, stickers, voice and photos): every player writes in one shared room (Firebase: worldChat/messages).
 *  - Owner = the admin account (shows a OWNER badge). The owner can make any player a "chat admin" (worldChat/admins) who gets an ADMIN badge
 *    and can delete messages / mute players inside the chat.
 *  - Title and round icon of the chat are set by the admin (settings/worldChatTitle, settings/worldChatIcon).
 *  - "Online" = players who have the chat screen open right now (worldChat/online, a heartbeat every 30 seconds).
 *  - Safety: max 200 characters, 3 second wait, no links / phone numbers / money talk / bad words, report button, mute, chat ON/OFF.
 *    The database rules enforce length, wait time, mute, ON/OFF and the badges as well.
 */
data class ChatMember(val uid: String, val name: String, val owner: Boolean, val ts: Long)
data class ChatClip(val id: String, val name: String, val durationMs: Long, val ts: Long)
data class ChatMsg(val id: String, val uid: String, val username: String, val text: String, val ts: Long, val role: String,
                   val kind: String = "text", val sticker: String = "", val voiceId: String = "", val durationMs: Long = 0L, val imageId: String = "")

object ChatRules {
    private val defaultBlocked = setOf("fuck", "shit", "bitch", "asshole", "chutiya", "madarchod", "bhenchod", "behenchod", "randi", "harami", "gandu", "lund", "bsdk", "mc", "bc", "mkc",
        "upi", "paytm", "gpay", "phonepe")
    private val link = Regex("(https?://|www\\.|t\\.me|wa\\.me|\\.(com|in|net|org|me|xyz|gg|link|app)\\b)", RegexOption.IGNORE_CASE)

    /** null = the text is fine, otherwise the reason (English key, shown with tx()). */
    fun check(text: String, extra: List<String>): String? {
        val t = text.lowercase()
        if (link.containsMatchIn(t)) return "Links are not allowed in chat"
        if (t.count { it.isDigit() } >= 8) return "Phone numbers are not allowed in chat"
        val tokens = t.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }.toSet()
        if (tokens.any { it in defaultBlocked }) return "This word is not allowed in chat"
        for (w in extra) { if (w.isBlank()) continue; if (w in tokens || (w.length >= 4 && t.contains(w))) return "This word is not allowed in chat" }
        return null
    }
}

/** The time of the newest chat message this player has seen (used for the red number on the header chat icon). */
object ChatSeen {
    var last by mutableLongStateOf(0L)
        private set
    /** The red number on the header chat icon can be switched off on this phone (Group info -> button). */
    var badgeOn by mutableStateOf(true)
        private set
    private var loadedFor = ""

    fun setBadge(ctx: Context, on: Boolean) {
        badgeOn = on
        val uid = Repo.uid()
        if (uid.isNotBlank()) ctx.getSharedPreferences("world_chat", Context.MODE_PRIVATE).edit().putBoolean("badge_$uid", on).apply()
    }

    fun load(ctx: Context) {
        val uid = Repo.uid()
        if (uid.isBlank() || loadedFor == uid) return
        loadedFor = uid
        val sp = ctx.getSharedPreferences("world_chat", Context.MODE_PRIVATE)
        if (!sp.contains("seen_$uid")) sp.edit().putLong("seen_$uid", System.currentTimeMillis()).apply()   // first time: old messages do not count
        last = sp.getLong("seen_$uid", System.currentTimeMillis())
        badgeOn = sp.getBoolean("badge_$uid", true)
    }

    fun mark(ctx: Context, ts: Long) {
        val uid = Repo.uid()
        if (uid.isBlank() || ts <= last) return
        last = ts
        ctx.getSharedPreferences("world_chat", Context.MODE_PRIVATE).edit().putLong("seen_$uid", ts).apply()
    }
}

object ChatRepo {
    fun messages(): Flow<List<ChatMsg>> = Repo.watch(Repo.db.child("worldChat/messages").orderByChild("ts").limitToLast(100)) { s ->
        s.children.mapNotNull { c ->
            val id = c.key ?: return@mapNotNull null
            val m = c.value as? Map<*, *> ?: return@mapNotNull null
            ChatMsg(id, m["uid"]?.toString().orEmpty(), m["username"]?.toString().orEmpty(), m["text"]?.toString().orEmpty(), (m["ts"] as? Number)?.toLong() ?: 0L, m["role"]?.toString().orEmpty(),
                m["kind"]?.toString().orEmpty().ifBlank { "text" }, m["sticker"]?.toString().orEmpty(), m["voiceId"]?.toString().orEmpty(), (m["durationMs"] as? Number)?.toLong() ?: 0L, m["imageId"]?.toString().orEmpty())
        }.sortedBy { it.ts }
    }

    /** How many new messages (not mine) came after [since]. */
    fun unread(since: Long): Flow<Int> = Repo.watch(Repo.db.child("worldChat/messages").orderByChild("ts").startAt(since.toDouble() + 1).limitToLast(100)) { s ->
        s.children.count { it.child("uid").value?.toString() != Repo.uid() }
    }

    /** Time (ms) until which this player is muted; 0 = not muted. */
    fun myMute(): Flow<Long> = Repo.watch(Repo.db.child("worldChat/mutes/${Repo.uid()}/until")) { (it.value as? Number)?.toLong() ?: 0L }

    /** Voice clips the owner recorded (worldChat/clips). Their audio lives in worldChat/voice/clip_<id>. */
    fun clips(): Flow<List<ChatClip>> = Repo.watch(Repo.db.child("worldChat/clips")) { s ->
        s.children.mapNotNull { c ->
            val id = c.key ?: return@mapNotNull null
            val m = c.value as? Map<*, *> ?: return@mapNotNull null
            ChatClip(id, m["name"]?.toString().orEmpty(), (m["durationMs"] as? Number)?.toLong() ?: 0L, (m["ts"] as? Number)?.toLong() ?: 0L)
        }.sortedBy { it.ts }
    }

    /** Chat admin (made by the owner) changes the round chat picture shown INSIDE the chat. Returns an error text or null. */
    suspend fun setIcon(ctx: Context, uri: android.net.Uri): String? {
        return try {
        val data = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
            val src = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }) }
                ?: return@withContext null
            val side = minOf(src.width, src.height)
            val sq = android.graphics.Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = android.graphics.Bitmap.createScaledBitmap(sq, 256, 256, true)
            val bos = java.io.ByteArrayOutputStream()
            out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bos)
            "data:image/jpeg;base64," + android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
        }
        if (data == null) tx("Could not read this picture")
        else {
            val id = Repo.db.child("imageData").push().key ?: return tx("Could not save")
            Repo.db.child("imageData/$id").setValue(data).await()
            Repo.db.child("settings/worldChatIcon").setValue("dbimg:$id").await()
            null
        }
        } catch (e: CancellationException) { throw e } catch (e: Exception) { e.message ?: tx("Could not save") }
    }

    fun amChatAdmin(): Flow<Boolean> = Repo.watch(Repo.db.child("worldChat/admins/${Repo.uid()}")) { it.exists() }

    /** Heartbeat times of everybody who has the chat open. */
    fun onlineTimes(): Flow<List<Long>> = Repo.watch(Repo.db.child("worldChat/online")) { s -> s.children.mapNotNull { (it.value as? Number)?.toLong() } }

    /** Everybody who has opened the chat at least once (they register themselves: worldChat/members). */
    fun members(): Flow<List<ChatMember>> = Repo.watch(Repo.db.child("worldChat/members")) { s ->
        s.children.mapNotNull { c ->
            val uid = c.key ?: return@mapNotNull null
            val m = c.value as? Map<*, *> ?: return@mapNotNull null
            ChatMember(uid, m["name"]?.toString().orEmpty(), m["owner"] == true, (m["ts"] as? Number)?.toLong() ?: 0L)
        }.sortedBy { it.ts }
    }

    fun chatAdminIds(): Flow<Set<String>> = Repo.watch(Repo.db.child("worldChat/admins")) { s -> s.children.mapNotNull { it.key }.toSet() }

    suspend fun join(me: User) {
        val uid = Repo.uid()
        if (uid.isBlank() || me.username.isBlank()) return
        try {
            val ref = Repo.db.child("worldChat/members/$uid")
            if (!ref.get().await().exists()) ref.setValue(mapOf("name" to me.username, "owner" to (me.role == "admin"), "ts" to ServerValue.TIMESTAMP)).await()
        } catch (e: CancellationException) { throw e } catch (_: Exception) { }
    }

    fun blockedWords(): Flow<List<String>> = Repo.setting("chatBlockedWords").map { s -> s.lowercase().split(',', '\n').map { it.trim() }.filter { it.isNotBlank() } }

    /** null = sent, otherwise the error text. */
    suspend fun send(me: User, text: String, chatAdmin: Boolean): String? {
        if (me.username.isBlank()) return tx("Set your username first")
        val uid = Repo.uid()
        val id = Repo.db.child("worldChat/messages").push().key ?: return tx("Could not send. Try again")
        val role = if (me.role == "admin") "owner" else if (chatAdmin || me.role == "staff") "admin" else "user"
        return try {
            val ups = hashMapOf<String, Any?>(
                "worldChat/messages/$id" to mapOf("uid" to uid, "username" to me.username, "text" to text, "role" to role, "ts" to ServerValue.TIMESTAMP),
                "worldChat/last/$uid" to ServerValue.TIMESTAMP)
            Repo.db.updateChildren(ups).await()
            null
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { tx("Could not send. Chat may be off or you are muted") }
    }

    private suspend fun postSpecial(me: User, label: String, chatAdmin: Boolean, kind: String, extra: Map<String, Any?>): String? {
        if (me.username.isBlank()) return tx("Set your username first")
        val uid = Repo.uid()
        val id = Repo.db.child("worldChat/messages").push().key ?: return tx("Could not send. Try again")
        val role = if (me.role == "admin") "owner" else if (chatAdmin || me.role == "staff") "admin" else "user"
        return try {
            val msg = hashMapOf<String, Any?>("uid" to uid, "username" to me.username, "text" to label, "role" to role, "kind" to kind, "ts" to ServerValue.TIMESTAMP)
            msg.putAll(extra)
            Repo.db.updateChildren(hashMapOf<String, Any?>("worldChat/messages/$id" to msg, "worldChat/last/$uid" to ServerValue.TIMESTAMP)).await()
            null
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { tx("Could not send. Chat may be off or you are muted") }
    }

    suspend fun sendSticker(me: User, stickerId: String, chatAdmin: Boolean): String? = postSpecial(me, "Sticker", chatAdmin, "sticker", mapOf("sticker" to stickerId))

    suspend fun sendClip(me: User, c: ChatClip, chatAdmin: Boolean): String? = postSpecial(me, "Voice message", chatAdmin, "voice", mapOf("voiceId" to "clip_" + c.id, "durationMs" to c.durationMs))

    /** Saves the audio first, then writes the chat message. null = sent, otherwise the error text. */
    suspend fun sendVoice(me: User, file: java.io.File, durationMs: Long, chatAdmin: Boolean): String? {
        val vid = try { ChatVoice.upload(file) } catch (e: CancellationException) { throw e } catch (_: Exception) { return tx("Voice could not be sent. Try again") }
        return postSpecial(me, "Voice message", chatAdmin, "voice", mapOf("voiceId" to vid, "durationMs" to durationMs))
    }

    /** Shrinks the picture, saves it, then writes the chat message. null = sent, otherwise the error text. */
    suspend fun sendImage(ctx: Context, me: User, uri: android.net.Uri, chatAdmin: Boolean): String? {
        val data = try { ChatImages.prepare(ctx, uri) } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
            ?: return tx("Could not read this picture")
        val imgId = try { ChatImages.upload(data) } catch (e: CancellationException) { throw e } catch (_: Exception) { return tx("Photo could not be sent. Try again") }
        val err = postSpecial(me, "Photo", chatAdmin, "image", mapOf("imageId" to imgId))
        if (err != null) { try { Repo.db.child("worldChat/images/$imgId").removeValue() } catch (_: Exception) { } }
        return err
    }

    suspend fun report(me: User, m: ChatMsg): Boolean {
        return try {
        val id = Repo.db.child("worldChat/reports").push().key ?: return false
        Repo.db.child("worldChat/reports/$id").setValue(mapOf("msgId" to m.id, "ofUid" to m.uid, "ofName" to m.username, "text" to m.text.take(200),
            "byUid" to Repo.uid(), "byName" to me.username, "ts" to ServerValue.TIMESTAMP)).await()
        true
        } catch (e: CancellationException) { throw e } catch (_: Exception) { false }
    }

    suspend fun delete(id: String, voiceId: String = "", imageId: String = ""): Boolean = try {
        val ups = hashMapOf<String, Any?>("worldChat/messages/$id" to null)
        if (voiceId.isNotBlank() && !voiceId.startsWith("clip_")) ups["worldChat/voice/$voiceId"] = null
        if (imageId.isNotBlank()) ups["worldChat/images/$imageId"] = null
        Repo.db.updateChildren(ups).await(); true } catch (e: CancellationException) { throw e } catch (_: Exception) { false }

    suspend fun mute(m: ChatMsg, hours: Long): Boolean = try {
        Repo.db.child("worldChat/mutes/${m.uid}").setValue(mapOf("until" to System.currentTimeMillis() + hours * 3_600_000L, "name" to m.username, "by" to Repo.uid(), "ts" to System.currentTimeMillis())).await()
        true
    } catch (e: CancellationException) { throw e } catch (_: Exception) { false }
}

private val NameColors = listOf(Color(0xFF1F9D55), Color(0xFF8E44AD), Color(0xFFD35400), Color(0xFF2980B9), Color(0xFFE01B10), Color(0xFF16A085), Color(0xFFB7950B), Color(0xFF6C5CE7))

/** The round chat icon in the Home header (with the red number of new messages). This icon is PERMANENT: the chat picture the admin / chat admins change only shows INSIDE the chat. */
@Composable
fun ChatHeaderIcon(nav: NavController) {
    val ctx = LocalContext.current
    ChatSeen.load(ctx)
    val unread by rflow(ChatSeen.last, init = 0) { ChatRepo.unread(ChatSeen.last) }
    Box(Modifier.size(42.dp).clickable { nav.go("worldchat") }) {
        Box(Modifier.align(Alignment.Center).size(36.dp).clip(CircleShape).background(Purple.copy(alpha = 0.18f)).border(1.5.dp, Purple, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Forum, null, Modifier.size(20.dp), tint = Purple)
        }
        if (unread > 0 && ChatSeen.badgeOn) Box(Modifier.align(Alignment.TopEnd).clip(CircleShape).background(Color(0xFFE01B10)).border(1.dp, Color.White, CircleShape).padding(horizontal = 5.dp, vertical = 1.dp)) {
            Text(if (unread > 99) "99+" else "$unread", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WorldChatScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by rflow(init = User()) { Repo.me() }
    val msgsN by rflow(init = null as List<ChatMsg>?) { ChatRepo.messages() }
    val chatOn by rflow(init = "") { Repo.setting("worldChatOn") }
    val titleSet by rflow(init = "") { Repo.setting("worldChatTitle") }
    val iconSet by rflow(init = "") { Repo.setting("worldChatIcon") }
    val muteUntil by rflow(init = 0L) { ChatRepo.myMute() }
    val chatAdmin by rflow(init = false) { ChatRepo.amChatAdmin() }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { val err = ChatRepo.setIcon(ctx, uri); ctx.toast(err ?: tx("Chat icon changed")) }
    }
    val onlineTimes by rflow(init = emptyList<Long>()) { ChatRepo.onlineTimes() }
    val blocked by rflow(init = emptyList<String>()) { ChatRepo.blockedWords() }
    var text by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var lastSent by remember { mutableLongStateOf(0L) }
    var lastText by remember { mutableStateOf("") }
    var nowTick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var actionFor by remember { mutableStateOf<ChatMsg?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var showInfo by remember { mutableStateOf(false) }
    var showStickers by remember { mutableStateOf(false) }
    var showClips by remember { mutableStateOf(false) }
    val clips by rflow(init = emptyList<ChatClip>()) { ChatRepo.clips() }
    var recording by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    val player = rememberVoicePlayer()
    val rec = remember { VoiceRec(ctx, ChatVoice.USER_MAX_MS) }
    val descSet by rflow(init = "") { Repo.setting("worldChatDesc") }
    val members by rflow(init = emptyList<ChatMember>()) { ChatRepo.members() }
    val adminIds by rflow(init = emptySet<String>()) { ChatRepo.chatAdminIds() }
    val listState = rememberLazyListState()
    val atBottom by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }
    var baselineTs by remember { mutableLongStateOf(0L) }
    val newestTs = msgsN?.lastOrNull()?.ts ?: 0L
    LaunchedEffect(newestTs, atBottom) { if (atBottom) baselineTs = newestTs }
    val remaining = if (atBottom) 0 else (msgsN ?: emptyList()).count { it.ts > baselineTs && it.uid != Repo.uid() }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val off = !chatOn.trim().equals("true", true)
    val muted = muteUntil > System.currentTimeMillis()
    val owner = me.role == "admin"
    val canMod = owner || chatAdmin
    val privileged = canMod || me.role == "staff"
    val canWrite = !off && !muted && !me.banned
    val onlineCount = onlineTimes.count { it > nowTick - 120_000L }.coerceAtLeast(1)
    val title = titleSet.ifBlank { tx("World Chat") }

    // "online" heartbeat while this screen is open
    LaunchedEffect(Unit) {
        val uid = Repo.uid()
        if (uid.isBlank()) return@LaunchedEffect
        val ref = Repo.db.child("worldChat/online/$uid")
        try { ref.onDisconnect().removeValue() } catch (_: Exception) { }
        while (true) {
            nowTick = System.currentTimeMillis()
            try { ref.setValue(ServerValue.TIMESTAMP) } catch (_: Exception) { }
            delay(30_000)
        }
    }
    DisposableEffect(Unit) { onDispose { val uid = Repo.uid(); if (uid.isNotBlank()) try { Repo.db.child("worldChat/online/$uid").removeValue() } catch (_: Exception) { } } }
    LaunchedEffect(me.username) { ChatRepo.join(me) }   // register in the member list
    // everything up to the newest message is "seen"
    LaunchedEffect(msgsN?.lastOrNull()?.ts) { msgsN?.lastOrNull()?.ts?.let { ChatSeen.mark(ctx, it) } }

    fun doSend() {
        val t = text.trim()
        if (t.isBlank() || sending) return
        val now = System.currentTimeMillis()
        if (now - lastSent < 3000) { ctx.toast(tx("Wait a few seconds before the next message")); return }
        if (t == lastText) { ctx.toast(tx("Do not send the same message again")); return }
        if (!privileged) ChatRules.check(t, blocked)?.let { ctx.toast(tx(it)); return }
        sending = true
        scope.launch {
            val err = ChatRepo.send(me, t, chatAdmin)
            sending = false
            if (err == null) { text = ""; lastSent = System.currentTimeMillis(); lastText = t; listState.scrollToItem(0) } else ctx.toast(err)
        }
    }

    fun waitedEnough(): Boolean {
        if (System.currentTimeMillis() - lastSent < 3000) { ctx.toast(tx("Wait a few seconds before the next message")); return false }
        return true
    }
    fun doSticker(id: String) {
        if (sending || !waitedEnough()) return
        sending = true; showStickers = false
        scope.launch {
            val err = ChatRepo.sendSticker(me, id, chatAdmin)
            sending = false
            if (err == null) { lastSent = System.currentTimeMillis(); listState.scrollToItem(0) } else ctx.toast(err)
        }
    }
    fun doClip(c: ChatClip) {
        if (sending || !waitedEnough()) return
        sending = true; showClips = false
        scope.launch {
            val err = ChatRepo.sendClip(me, c, chatAdmin)
            sending = false
            if (err == null) { lastSent = System.currentTimeMillis(); listState.scrollToItem(0) } else ctx.toast(err)
        }
    }
    fun beginRec() {
        player.stop()
        val err = rec.start()
        if (err != null) { ctx.toast(err); return }
        showStickers = false; showClips = false; elapsed = 0L; recording = true
    }
    fun cancelRec() { if (!recording) return; recording = false; rec.cancel() }
    fun finishRec() {
        if (!recording) return
        recording = false
        val ms = rec.stop()
        val f = rec.file
        if (ms < 700L || f == null) { ctx.toast(tx("Recording is too short. Speak a little longer.")); return }
        if (!waitedEnough()) { try { f.delete() } catch (_: Exception) { }; return }
        sending = true
        scope.launch {
            try {
                val err = ChatRepo.sendVoice(me, f, ms, chatAdmin)
                if (err == null) { lastSent = System.currentTimeMillis(); listState.scrollToItem(0) } else ctx.toast(err)
            } finally { try { f.delete() } catch (_: Exception) { }; sending = false }
        }
    }
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginRec() else ctx.toast(tx("Allow the microphone to record a voice message"))
    }
    fun tapMic() {
        if (sending) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginRec()
        else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }
    var viewImage by remember { mutableStateOf("") }
    fun doImage(uri: android.net.Uri) {
        if (sending || !waitedEnough()) return
        sending = true; showStickers = false; showClips = false
        scope.launch {
            try {
                val err = ChatRepo.sendImage(ctx, me, uri, chatAdmin)
                if (err == null) { lastSent = System.currentTimeMillis(); listState.scrollToItem(0) } else ctx.toast(err)
            } finally { sending = false }
        }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) doImage(uri) }
    LaunchedEffect(recording) {
        if (recording) {
            val t0 = System.currentTimeMillis()
            while (recording) {
                elapsed = System.currentTimeMillis() - t0
                if (elapsed >= ChatVoice.USER_MAX_MS) { finishRec(); break }
                delay(200)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { rec.cancel() } }

    Column(Modifier.fillMaxSize().background(Color(0xFFEFEAE2))) {
        // top bar like WhatsApp
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.clip(CircleShape).clickable { nav.back() }.padding(8.dp).size(24.dp), tint = Color(0xFF111B21))
            Box(Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF25D366), Color(0xFF128C7E)))), contentAlignment = Alignment.Center) {
                if (iconSet.isNotBlank()) AsyncImage(BackendConfig.resolve(iconSet), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Default.Forum, null, Modifier.size(22.dp), tint = Color.White)
            }
            Column(Modifier.weight(1f).clickable { showInfo = true }.padding(horizontal = 10.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color(0xFF111B21), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(tx("Online") + ": $onlineCount", fontSize = 12.sp, color = Color(0xFF667781))
            }
            Box {
                Icon(Icons.Default.MoreVert, null, Modifier.clip(CircleShape).clickable { menuOpen = true }.padding(8.dp).size(24.dp), tint = Color(0xFF111B21))
                DropdownMenu(menuOpen, { menuOpen = false }) { DropdownMenuItem(text = { Text(tx("Group info")) }, onClick = { menuOpen = false; showInfo = true }) }
            }
        }
        val list = msgsN
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (list == null) Loader()
            else if (list.isEmpty()) Text(tx("No messages yet. Say hello!"), Modifier.align(Alignment.Center).padding(30.dp), color = Color(0xFF667781), textAlign = TextAlign.Center)
            else LazyColumn(Modifier.fillMaxSize(), state = listState, reverseLayout = true, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(list.asReversed(), key = { it.id }) { m ->
                    val mine = m.uid == Repo.uid()
                    val isOwner = m.role == "owner"
                    val isAdm = m.role == "admin" || m.role == "staff" || m.uid in adminIds
                    val special = isOwner || isAdm
                    val isSticker = m.kind == "sticker" && Stickers.find(m.sticker) != null
                    val bg = if (isSticker) Color.Transparent else if (isOwner) Color(0xFFFFF3C4) else if (isAdm) Color(0xFFE8FBF5) else if (mine) Color(0xFFD9FDD3) else Color.White
                    val shape = RoundedCornerShape(12.dp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(min = 70.dp, max = 300.dp).clip(shape).background(bg)
                            .then(if (special && !isSticker) (if (isOwner) Modifier.border(1.dp, Color(0xFFF2B01E), shape) else Modifier.border(1.5.dp, Color(0xFF6FD6BD), shape).drawBehind { drawRect(Color(0xFF1FA67A), size = Size(5.dp.toPx(), size.height)) }) else Modifier)
                            .combinedClickable(onClick = { }, onLongClick = { actionFor = m })
                            .padding(horizontal = 10.dp, vertical = 6.dp)) {
                            if (isOwner) Box(Modifier.clip(RoundedCornerShape(5.dp)).background(Color(0xFFFFD54F)).padding(horizontal = 7.dp, vertical = 1.dp)) { Text("\uD83D\uDC51 OWNER", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7A4B00)) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (mine) m.username + " (" + tx("You") + ")" else m.username, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                                    color = if (isOwner) Color(0xFFB26A00) else if (isAdm) Color(0xFF0B6B57) else if (mine) Color(0xFF1F9D55) else NameColors[Math.abs(m.username.hashCode()) % NameColors.size])
                                if (!isOwner && isAdm) { Spacer(Modifier.width(6.dp)); Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFFFC83D)).padding(horizontal = 8.dp, vertical = 2.dp)) { Text("\uD83D\uDEE1\uFE0F Staff", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5A3A00)) } }
                            }
                            when {
                                isSticker -> Box(Modifier.padding(top = 2.dp)) { StickerView(Stickers.find(m.sticker)!!, 120.dp) }
                                m.kind == "image" && m.imageId.isNotBlank() -> ChatPhoto(m.imageId, onClick = { viewImage = m.imageId }, onLongClick = { actionFor = m })
                                m.kind == "voice" && m.voiceId.isNotBlank() -> {
                                    val vkey = "v_" + m.id
                                    val playing = player.playingId == vkey
                                    val loading = player.loadingId == vkey
                                    val progress = if (playing && m.durationMs > 0) (player.posMs.toFloat() / m.durationMs).coerceIn(0f, 1f) else 0f
                                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF00A884)).clickable { player.toggle(vkey) { ChatVoice.audioFile(ctx, m.voiceId) } }, contentAlignment = Alignment.Center) {
                                            if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                            else Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(26.dp), tint = Color.White)
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            LinearProgressIndicator(progress = { progress }, Modifier.width(150.dp).height(4.dp).clip(RoundedCornerShape(2.dp)), color = Color(0xFF00A884), trackColor = Color(0xFFCFD8DC))
                                            Text((if (playing) ChatVoice.fmt(player.posMs.toLong()) else "0:00") + " / " + ChatVoice.fmt(m.durationMs), Modifier.padding(top = 3.dp), fontSize = 11.sp, color = Color(0xFF667781))
                                        }
                                    }
                                }
                                else -> Text(m.text, fontSize = 15.sp, color = Color(0xFF111B21))
                            }
                            Text((if (m.ts > 0) timeFmt.format(java.util.Date(m.ts)) else "") + (if (mine) "  \u2713" else ""), Modifier.align(Alignment.End), fontSize = 10.sp, color = Color(0xFF667781))
                        }
                    }
                }
            }
            if (remaining > 0) Box(Modifier.align(Alignment.BottomEnd).padding(12.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFD9F3EC)).clickable { scope.launch { listState.animateScrollToItem(0) } }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text("\u2193 " + tx("New") + " $remaining", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0B6B57))
            }
        }
        if (!canWrite) {
            Text(if (off) tx("Chat is off right now.") else if (me.banned) tx("Your account is banned.") else tx("You are muted by the admin for some time."),
                Modifier.fillMaxWidth().background(Color.White).padding(16.dp), textAlign = TextAlign.Center, color = Color(0xFFD35400), fontSize = 13.sp)
        } else {
            if (showStickers && !recording) Column(Modifier.fillMaxWidth().background(Color(0xFFF7F8FA))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("\uD83D\uDD25 " + tx("Stickers (tap to send)"), Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111B21))
                    Icon(Icons.Default.Close, null, Modifier.clip(CircleShape).clickable { showStickers = false }.padding(2.dp).size(22.dp), tint = Color(0xFF111B21))
                }
                LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxWidth().height(250.dp), contentPadding = PaddingValues(6.dp)) {
                    gridItems(Stickers.all, key = { it.id }) { st ->
                        Box(Modifier.padding(3.dp).clickable { doSticker(st.id) }, contentAlignment = Alignment.Center) { StickerView(st, 80.dp) }
                    }
                }
            }
            if (showClips && !recording) Column(Modifier.fillMaxWidth().background(Color(0xFFF7F8FA))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("\uD83C\uDF99\uFE0F " + tx("Voice clips: tap to listen, long-press to send"), Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0B6B57))
                    Icon(Icons.Default.Close, null, Modifier.clip(CircleShape).clickable { showClips = false }.padding(2.dp).size(22.dp), tint = Color(0xFF111B21))
                }
                if (clips.isEmpty()) Text(tx("No voice clips yet"), Modifier.fillMaxWidth().padding(20.dp), fontSize = 13.sp, color = Color(0xFF667781), textAlign = TextAlign.Center)
                else LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxWidth().height(250.dp), contentPadding = PaddingValues(6.dp)) {
                    gridItems(clips, key = { it.id }) { c ->
                        val ck = "c_" + c.id
                        ClipTile(c.name + "  " + ChatVoice.fmt(c.durationMs), player.playingId == ck, player.loadingId == ck,
                            { player.toggle(ck) { ChatVoice.audioFile(ctx, "clip_" + c.id) } }, { doClip(c) })
                    }
                }
            }
            if (recording) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Delete, null, Modifier.clip(CircleShape).clickable { cancelRec() }.padding(6.dp).size(24.dp), tint = Color(0xFFE01B10))
                    Spacer(Modifier.width(8.dp))
                    Text("\uD83D\uDD34 " + tx("Recording...") + "  ${ChatVoice.fmt(elapsed)} / 0:30", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111B21))
                }
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(50.dp).clip(CircleShape).background(Color(0xFF00A884)).clickable { finishRec() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Filled.Send, tx("Send"), Modifier.size(22.dp), tint = Color.White)
                }
            } else Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
                Row(Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(Color.White).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (showStickers) "\u2328\uFE0F" else "\uD83D\uDE0A", Modifier.clip(CircleShape).clickable { showStickers = !showStickers; if (showStickers) showClips = false }.padding(horizontal = 4.dp), fontSize = 22.sp)
                    Text("\uD83C\uDF99\uFE0F", Modifier.clip(CircleShape).clickable { showClips = !showClips; if (showClips) showStickers = false }.padding(horizontal = 4.dp), fontSize = 20.sp)
                    Text("\uD83D\uDCF7", Modifier.clip(CircleShape).clickable { if (!sending) pickPhoto.launch("image/*") }.padding(horizontal = 4.dp), fontSize = 20.sp)
                    Spacer(Modifier.width(6.dp))
                    BasicTextField(text, { if (it.length <= 200) text = it }, Modifier.weight(1f), textStyle = TextStyle(fontSize = 16.sp, color = Color(0xFF111B21)), maxLines = 4, cursorBrush = SolidColor(Color(0xFF00A884)),
                        decorationBox = { inner -> if (text.isEmpty()) Text(tx("Write a message..."), fontSize = 16.sp, color = Color(0xFF8696A0)); inner() })
                    if (text.length >= 150) Text("${text.length}/200", Modifier.padding(start = 6.dp), fontSize = 10.sp, color = Color(0xFF8696A0))
                }
                Spacer(Modifier.width(8.dp))
                val hasText = text.isNotBlank()
                Box(Modifier.size(50.dp).clip(CircleShape).background(if (sending) Color(0xFF8BC9B8) else Color(0xFF00A884)).clickable { if (hasText) doSend() else tapMic() }, contentAlignment = Alignment.Center) {
                    if (hasText) Icon(Icons.AutoMirrored.Filled.Send, tx("Send"), Modifier.size(22.dp), tint = Color.White)
                    else Icon(Icons.Default.Mic, null, Modifier.size(26.dp), tint = Color.White)
                }
            }
        }
    }

    if (showInfo) Dialog(onDismissRequest = { showInfo = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.9f).clip(RoundedCornerShape(16.dp)).background(Color.White)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tx("Group info"), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color(0xFF111B21))
                Icon(Icons.Default.Close, null, Modifier.clip(CircleShape).clickable { showInfo = false }.padding(4.dp).size(24.dp), tint = Color(0xFF111B21))
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF25D366), Color(0xFF128C7E)))), contentAlignment = Alignment.Center) {
                            if (iconSet.isNotBlank()) AsyncImage(BackendConfig.resolve(iconSet), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Icon(Icons.Default.Forum, null, Modifier.size(38.dp), tint = Color.White)
                        }
                        Column(Modifier.padding(start = 14.dp)) {
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF111B21))
                            Text(descSet.ifBlank { tx("Rules: no abuse, links, phone numbers or money talk. Be respectful.") }, Modifier.padding(top = 4.dp), fontSize = 12.sp, color = Color(0xFF667781))
                        }
                    }
                }
                if (chatAdmin) item {
                    Box(Modifier.padding(top = 14.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFDCE8FF)).clickable { pickIcon.launch("image/*") }.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(tx("Change chat icon"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1A4FB8))
                    }
                }
                item {
                    Box(Modifier.padding(top = 14.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE6F4EF)).clickable { ChatSeen.setBadge(ctx, !ChatSeen.badgeOn) }.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(if (ChatSeen.badgeOn) tx("Turn off chat badge on this phone") else tx("Turn on chat badge on this phone"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0B6B57))
                    }
                }
                item {
                    Text(tx("Total joined members"), Modifier.padding(top = 16.dp), fontSize = 12.sp, color = Color(0xFF667781))
                    Text("${members.size} " + tx("people"), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color(0xFF111B21))
                    Text(tx("Members list"), Modifier.padding(top = 14.dp, bottom = 6.dp), fontSize = 12.sp, color = Color(0xFF667781))
                }
                items(members, key = { it.uid }) { mem ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(mem.name, fontSize = 14.sp, color = Color(0xFF111B21), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        if (mem.owner) { Spacer(Modifier.width(8.dp)); Box(Modifier.clip(RoundedCornerShape(5.dp)).background(Color(0xFFC8F0DC)).padding(horizontal = 6.dp, vertical = 1.dp)) { Text("OWNER", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0B6B57)) } }
                        else if (mem.uid in adminIds) { Spacer(Modifier.width(8.dp)); Box(Modifier.clip(RoundedCornerShape(5.dp)).background(Color(0xFFFFC83D)).padding(horizontal = 6.dp, vertical = 1.dp)) { Text("Staff", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5A3A00)) } }
                        if (mem.uid == Repo.uid()) { Spacer(Modifier.width(8.dp)); Text("(" + tx("You") + ")", fontSize = 11.sp, color = Color(0xFF667781)) }
                    }
                    Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFFE6E6E6)))
                }
            }
        }
    }
    if (viewImage.isNotBlank()) ChatPhotoViewer(viewImage) { viewImage = "" }
    actionFor?.let { m ->
        val own = m.uid == Repo.uid()
        val targetIsStaff = m.role == "owner" || m.role == "admin" || m.role == "staff"
        Dialog(onDismissRequest = { actionFor = null }) {
            Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(m.username, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF111B21))
                Text(if (m.kind == "voice") "\uD83C\uDF99\uFE0F " + tx("Voice message") else if (m.kind == "sticker") "Sticker" else if (m.kind == "image") "\uD83D\uDCF7 " + tx("Photo") else m.text, fontSize = 13.sp, color = Color(0xFF667781), maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (!own) ChatBtn(tx("Report"), Color(0xFFD35400), Modifier.fillMaxWidth()) {
                    actionFor = null
                    scope.launch { ctx.toast(if (ChatRepo.report(me, m)) tx("Reported. Thank you") else tx("Could not report. Try again")) }
                }
                if (canMod) ChatBtn(tx("Delete message"), Color(0xFFE01B10), Modifier.fillMaxWidth()) {
                    actionFor = null
                    scope.launch { if (!ChatRepo.delete(m.id, m.voiceId, m.imageId)) ctx.toast(tx("Could not delete. Try again")) }
                }
                if (canMod && !own && !targetIsStaff) {
                    ChatBtn(tx("Mute 1 hour"), Color(0xFF6C5CE7), Modifier.fillMaxWidth()) { actionFor = null; scope.launch { ctx.toast(if (ChatRepo.mute(m, 1)) tx("Player muted") else tx("Could not mute. Try again")) } }
                    ChatBtn(tx("Mute 24 hours"), Color(0xFF6C5CE7), Modifier.fillMaxWidth()) { actionFor = null; scope.launch { ctx.toast(if (ChatRepo.mute(m, 24)) tx("Player muted") else tx("Could not mute. Try again")) } }
                }
                ChatBtn(tx("CANCEL"), Color(0xFF8696A0), Modifier.fillMaxWidth()) { actionFor = null }
            }
        }
    }
}

@Composable
private fun ChatBtn(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(color).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

/** One grey tile of the voice clip grid: tap = listen (green while playing), long-press = send into the chat. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ClipTile(label: String, playing: Boolean, loading: Boolean, onTap: () -> Unit, onLong: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Row(Modifier.padding(3.dp).fillMaxWidth().height(46.dp).clip(shape).background(if (playing) Color(0xFF00A884) else Color(0xFFEDEDED))
        .border(1.dp, Color(0xFFC8C8C8), shape).combinedClickable(onClick = onTap, onLongClick = onLong).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        if (loading) CircularProgressIndicator(Modifier.size(16.dp), color = Color(0xFF00A884), strokeWidth = 2.dp)
        else Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(20.dp), tint = if (playing) Color.White else Color(0xFF00A884))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (playing) Color.White else Color(0xFF111B21), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
