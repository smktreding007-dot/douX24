package com.bestwinesport.app

private val zapupiTranslations = mapOf(
    "en" to mapOf(
        "pay" to "PAY WITH ZAPUPI", "creating" to "CREATING PAYMENT...", "manual" to "USE MANUAL UPI INSTEAD",
        "verified_note" to "ZapUPI payments are verified by the server before wallet credit.", "complete" to "Complete ZapUPI payment",
        "secure_info" to "Complete the payment on the secure ZapUPI page. Your wallet is credited only after server verification.",
        "open" to "OPEN SECURE PAYMENT PAGE", "checking" to "CHECKING...", "check" to "CHECK PAYMENT STATUS", "close" to "CLOSE",
        "success" to "Payment verified. Wallet updated.", "failed" to "Payment was not completed. No wallet credit was added.",
        "review" to "Payment needs manual review. Contact support if you paid.", "pending" to "Payment is still pending. Check again shortly.",
        "open_error" to "Could not open the payment page", "start_error" to "Could not start payment. Try again.", "status_error" to "Could not check payment yet",
        "secure_payment" to "Secure Payment", "created" to "Order Create Successful", "verifying" to "Verifying transaction...", "retry" to "RETRY", "no_app" to "This payment app is not installed",
        "late" to "Payment not confirmed yet. If you already paid, coins will be added automatically."
    ),
    "hi" to mapOf(
        "pay" to "ZAPUPI से भुगतान करें", "creating" to "भुगतान बनाया जा रहा है...", "manual" to "इसके बजाय मैनुअल UPI इस्तेमाल करें",
        "verified_note" to "वॉलेट में पैसे जोड़ने से पहले ZapUPI भुगतान सर्वर से सत्यापित होगा।", "complete" to "ZapUPI भुगतान पूरा करें",
        "secure_info" to "सुरक्षित ZapUPI पेज पर भुगतान पूरा करें। सर्वर सत्यापन के बाद ही वॉलेट में राशि जुड़ेगी।",
        "open" to "सुरक्षित भुगतान पेज खोलें", "checking" to "जाँच हो रही है...", "check" to "भुगतान की स्थिति जाँचें", "close" to "बंद करें",
        "success" to "भुगतान सत्यापित। वॉलेट अपडेट हो गया।", "failed" to "भुगतान पूरा नहीं हुआ। वॉलेट में राशि नहीं जोड़ी गई।",
        "review" to "भुगतान की मैन्युअल जाँच आवश्यक है। भुगतान किया हो तो सहायता से संपर्क करें।", "pending" to "भुगतान लंबित है। थोड़ी देर बाद फिर जाँचें।",
        "open_error" to "भुगतान पेज नहीं खुला", "start_error" to "भुगतान शुरू नहीं हुआ। फिर कोशिश करें।", "status_error" to "अभी भुगतान की स्थिति जाँच नहीं सके",
        "secure_payment" to "सुरक्षित भुगतान", "created" to "ऑर्डर सफलतापूर्वक बन गया", "verifying" to "लेनदेन की जाँच हो रही है...", "retry" to "फिर कोशिश करें", "no_app" to "यह पेमेंट ऐप इंस्टॉल नहीं है",
        "late" to "भुगतान की पुष्टि अभी नहीं हुई। अगर आपने भुगतान कर दिया है तो कॉइन अपने आप जुड़ जाएँगे।"
    ),
)

fun zapupiText(key: String): String = zapupiTranslations[AppLanguage.current]?.get(key)
    ?: zapupiTranslations["en"]?.get(key) ?: key
