package com.bestwinesport.app

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext

/**
 * Opens the ZapUPI payment page full screen (see ZapupiCheckoutActivity: loader, then the QR / UPI apps page).
 * When the player leaves that screen, [onClose] runs and the caller checks the payment status.
 * Name and parameters are unchanged, so Add Coins needs no other edit.
 */
@Composable
fun ZapupiCheckoutDialog(pageUrl: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val close by rememberUpdatedState(onClose)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { close() }
    LaunchedEffect(pageUrl) {
        launcher.launch(Intent(ctx, ZapupiCheckoutActivity::class.java).putExtra(ZapupiCheckoutActivity.EXTRA_URL, pageUrl))
    }
}
