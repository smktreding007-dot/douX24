package com.bestwinesport.app

import android.content.Context
import android.media.MediaPlayer
import android.util.Base64
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sign
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.google.firebase.database.DataSnapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/** A voice message sent by the admin (Admin app -> Send notification -> Voice). Shown in Account -> Voice messages until the player deletes it from his own list. */
data class VoiceMsg(val id: String, val title: String, val body: String, val durationMs: Long, val ts: Long, val target: String, val matchKey: String)

object VoiceRepo {
    /** A voice message lives 24 hours (like a normal notification); after that it is gone from the players' lists and the admin app removes it from Firebase. */
    const val TTL_MS = 24L * 60 * 60 * 1000

    private fun parse(s: DataSnapshot): List<VoiceMsg> = s.children.mapNotNull { c ->
        val id = c.key ?: return@mapNotNull null
        val m = c.value as? Map<*, *> ?: return@mapNotNull null
        VoiceMsg(id, m["title"]?.toString().orEmpty(), m["body"]?.toString().orEmpty(), (m["durationMs"] as? Number)?.toLong() ?: 0L,
            (m["ts"] as? Number)?.toLong() ?: 0L, m["target"]?.toString().orEmpty(), m["matchKey"]?.toString().orEmpty())
    }

    // If a stream fails (for example the new database rules are not published yet) it still gives a value, so the screen never hangs.
    private fun <T> Flow<T>.orDefaultOnFail(default: T): Flow<T> = flow {
        var got = false
        collect { got = true; emit(it) }
        if (!got) emit(default)
    }

    /** Messages for everybody + messages for the matches this player joined + messages only for this player, newest first. Voices the player deleted are left out. */
    fun inbox(): Flow<List<VoiceMsg>> {
        val uid = Repo.uid()
        val broadcast = Repo.watch(Repo.db.child("voiceMessages").orderByChild("ts").limitToLast(100)) { parse(it) }.orDefaultOnFail(emptyList())
        val direct = Repo.watch(Repo.db.child("voiceDirect/$uid").orderByChild("ts").limitToLast(100)) { parse(it) }.orDefaultOnFail(emptyList())
        val joined = Repo.myMatchIds().orDefaultOnFail(emptyList())
        val hidden = Repo.watch(Repo.db.child("voiceHidden/$uid")) { s -> s.children.mapNotNull { it.key }.toSet() }.orDefaultOnFail(emptySet())
        return combine(broadcast, direct, joined, hidden) { b, d, mids, hid ->
            (b.filter { it.target != "match" || it.matchKey in mids } + d).filter { it.id !in hid && it.ts > System.currentTimeMillis() - TTL_MS }.sortedByDescending { it.ts }
        }
    }

    /** The player deletes voices from HIS list only (voiceHidden/<uid>/<id>); other players and the admin list are not touched. */
    suspend fun hide(ctx: Context, ids: Collection<String>) {
        val uid = Repo.uid()
        if (uid.isBlank() || ids.isEmpty()) return
        val ups = HashMap<String, Any?>()
        ids.forEach { ups["voiceHidden/$uid/$it"] = true }
        Repo.db.updateChildren(ups).await()
        withContext(Dispatchers.IO) { ids.forEach { try { File(File(ctx.cacheDir, "voice"), it.filter { c -> c.isLetterOrDigit() || c == '_' || c == '-' } + ".m4a").delete() } catch (_: Exception) { } } }
    }

    /** The audio as a file on this phone (downloaded once, then kept). */
    suspend fun audioFile(ctx: Context, id: String): File? = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "voice").apply { mkdirs() }
        val f = File(dir, id.filter { it.isLetterOrDigit() || it == '_' || it == '-' } + ".m4a")
        if (f.exists() && f.length() > 0) return@withContext f
        val snap = Repo.db.child("voiceData/$id").get().await()
        val parts = snap.children.mapNotNull { c -> c.key?.removePrefix("c")?.toIntOrNull()?.let { it to (c.value?.toString() ?: "") } }.sortedBy { it.first }
        if (parts.isEmpty()) return@withContext null
        val out = java.io.ByteArrayOutputStream()
        parts.forEach { out.write(Base64.decode(it.second, Base64.NO_WRAP)) }
        f.writeBytes(out.toByteArray())
        f
    }
}

/** Remembers which voice messages the player has already seen (for the NEW badge). */
object VoicePrefs {
    var lastSeen by mutableLongStateOf(0L)
        private set
    /** Time of the newest voice the player swiped away from the Home card (the voice stays in Account -> Voice messages). */
    var dismissedTs by mutableLongStateOf(0L)
        private set
    private var loadedFor = ""

    fun load(ctx: Context) {
        val uid = Repo.uid()
        if (uid.isBlank() || loadedFor == uid) return
        loadedFor = uid
        val sp = ctx.getSharedPreferences("voice_msgs", Context.MODE_PRIVATE)
        lastSeen = sp.getLong("seen_$uid", 0L)
        dismissedTs = sp.getLong("dismissed_$uid", 0L)
    }

    fun dismiss(ctx: Context, ts: Long) {
        val uid = Repo.uid()
        if (uid.isBlank() || ts <= dismissedTs) return
        dismissedTs = ts
        ctx.getSharedPreferences("voice_msgs", Context.MODE_PRIVATE).edit().putLong("dismissed_$uid", ts).apply()
    }

    fun markSeen(ctx: Context, ts: Long) {
        val uid = Repo.uid()
        if (uid.isBlank() || ts <= lastSeen) return
        lastSeen = ts
        ctx.getSharedPreferences("voice_msgs", Context.MODE_PRIVATE).edit().putLong("seen_$uid", ts).apply()
    }
}

/** Plays one voice message at a time. */
class VoicePlayer(private val ctx: Context, private val scope: CoroutineScope) {
    var playingId by mutableStateOf<String?>(null)
        private set
    var loadingId by mutableStateOf<String?>(null)
        private set
    var posMs by mutableIntStateOf(0)
        private set
    private var mp: MediaPlayer? = null
    private var job: Job? = null

    fun toggle(key: String, load: suspend () -> File?) {
        if (playingId == key || loadingId == key) { stop(); return }
        stop()
        loadingId = key
        job = scope.launch {
            val f = try { load() } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
            ensureActive()
            if (f == null) { loadingId = null; ctx.toast(tx("Could not load the voice message")); return@launch }
            val p = MediaPlayer()
            try {
                p.setDataSource(f.absolutePath)
                p.setOnCompletionListener { stop() }
                p.setOnErrorListener { _, _, _ -> stop(); true }
                p.prepare()
                mp = p
                p.start()
                playingId = key; loadingId = null
                while (mp === p) {
                    try { if (!p.isPlaying) break; posMs = p.currentPosition } catch (_: Exception) { break }
                    delay(200)
                }
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { if (mp !== p) { try { p.release() } catch (_: Exception) { } }; stop(); ctx.toast(tx("This voice cannot be played")) }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        val p = mp; mp = null
        if (p != null) { try { p.stop() } catch (_: Exception) { }; try { p.release() } catch (_: Exception) { } }
        playingId = null; loadingId = null; posMs = 0
    }
}

@Composable
fun rememberVoicePlayer(): VoicePlayer {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = remember { VoicePlayer(ctx, scope) }
    DisposableEffect(p) { onDispose { p.stop() } }
    return p
}

private fun mmss(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

/**
 * Home card: ONLY the newest voice message is shown (a newer voice replaces the older one). The player can listen to it here,
 * or swipe it away to either side (it is then hidden here; the voice stays in Account -> Voice messages). Colours follow the app theme.
 */
@Composable
fun HomeVoiceCard() {
    val ctx = LocalContext.current
    VoicePrefs.load(ctx)
    val inbox by rflow(init = emptyList<VoiceMsg>()) { VoiceRepo.inbox() }
    val player = rememberVoicePlayer()
    val latest = inbox.firstOrNull()?.takeIf { it.ts > VoicePrefs.dismissedTs }
    LaunchedEffect(latest?.id) { if (latest == null || player.playingId != latest.id) player.stop() }
    if (latest == null) return
    key(latest.id) {
        val scope = rememberCoroutineScope()
        val offset = remember { Animatable(0f) }
        var width by remember { mutableIntStateOf(1) }
        val playing = player.playingId == latest.id
        val loading = player.loadingId == latest.id
        val brand = brandAppName("DOUx24")
        val given = brandAppName(latest.title).trim()
        val title = if (given.isBlank() || given.equals(brand, true)) "$brand " + tx("Voice message") else given
        val progress = if (playing && latest.durationMs > 0) (player.posMs.toFloat() / latest.durationMs).coerceIn(0f, 1f) else 0f
        val shape = RoundedCornerShape(18.dp)
        Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).onSizeChanged { width = it.width.coerceAtLeast(1) }) {
            Column(Modifier
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .graphicsLayer { alpha = 1f - (abs(offset.value) / width).coerceIn(0f, 1f) * 0.85f }
                .fillMaxWidth().clip(shape).background(AccountC).border(1.dp, BorderC, shape)
                .draggable(orientation = Orientation.Horizontal,
                    state = rememberDraggableState { d -> scope.launch { offset.snapTo(offset.value + d) } },
                    onDragStopped = { v ->
                        val far = abs(offset.value) > width * 0.3f || abs(v) > 1400f
                        if (far) {
                            val dir = if (offset.value != 0f) sign(offset.value) else if (v != 0f) sign(v) else 1f
                            offset.animateTo(dir * width * 1.2f)
                            player.stop()
                            VoicePrefs.dismiss(ctx, latest.ts)
                        } else offset.animateTo(0f)
                    })
                .padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Purple).clickable { player.toggle(latest.id) { VoiceRepo.audioFile(ctx, latest.id) } }, contentAlignment = Alignment.Center) {
                        if (loading) CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(32.dp), tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Mic, null, Modifier.size(18.dp), tint = Purple)
                            Spacer(Modifier.width(6.dp))
                            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                        LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().padding(top = 8.dp).height(5.dp).clip(RoundedCornerShape(3.dp)), color = Purple, trackColor = Color.White.copy(alpha = 0.15f))
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((if (playing) mmss(player.posMs.toLong()) else "0:00") + " / " + mmss(latest.durationMs), fontSize = 11.sp, color = Color.Gray)
                            Spacer(Modifier.weight(1f))
                            Text("\u21C4 " + tx("Swipe sideways to remove"), fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

/** Account -> Voice messages: every voice the admin sent, listen again any time, delete one, several or all. */
@Composable
fun VoiceMessagesScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val listN by rflow(init = null as List<VoiceMsg>?) { VoiceRepo.inbox() }
    val player = rememberVoicePlayer()
    val seenAtOpen = remember { VoicePrefs.load(ctx); VoicePrefs.lastSeen }
    val dateFmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()) }
    var selectMode by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var confirmIds by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(listN) {
        val l = listN ?: return@LaunchedEffect
        l.maxOfOrNull { it.ts }?.let { VoicePrefs.markSeen(ctx, it) }
        val ids = l.map { it.id }
        // the voice that is playing was deleted -> stop it; selected voices that are gone are unselected
        val playing = player.playingId
        if (playing != null && playing !in ids) player.stop()
        selected.removeAll { it !in ids }
        if (l.isEmpty()) selectMode = false
    }
    Column(Modifier.fillMaxSize()) {
        BackBar(tx("Voice messages"), nav)
        val list = listN ?: return@Column Loader()
        if (list.isEmpty()) Text(tx("No voice messages yet"), Modifier.fillMaxWidth().padding(40.dp), textAlign = TextAlign.Center, color = Color.Gray)
        else Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!selectMode) {
                Spacer(Modifier.weight(1f))
                VoiceChip(tx("SELECT"), Purple) { player.stop(); selectMode = true }
            } else {
                VoiceChip(if (selected.size == list.size) tx("UNSELECT ALL") else tx("SELECT ALL"), Purple) {
                    if (selected.size == list.size) selected.clear() else { selected.clear(); selected.addAll(list.map { it.id }) }
                }
                Spacer(Modifier.weight(1f))
                VoiceChip(tx("DELETE") + " (${selected.size})", if (selected.isEmpty()) Color.Gray else Red) { if (selected.isNotEmpty()) confirmIds = selected.toList() }
                VoiceChip(tx("CANCEL"), Color.Gray) { selectMode = false; selected.clear() }
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { v ->
                val playing = player.playingId == v.id
                val loading = player.loadingId == v.id
                val title = brandAppName(v.title).trim().ifBlank { tx("Voice message from admin") }
                val picked = v.id in selected
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(AccountC)
                    .then(if (selectMode) Modifier.clickable { if (picked) selected.remove(v.id) else selected.add(v.id) } else Modifier).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (selectMode) { Checkbox(picked, { if (it) selected.add(v.id) else selected.remove(v.id) }); Spacer(Modifier.width(6.dp)) }
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Purple).clickable { player.toggle(v.id) { VoiceRepo.audioFile(ctx, v.id) } }, contentAlignment = Alignment.Center) {
                        if (loading) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(28.dp), tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(title, Modifier.weight(1f, fill = false), fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2)
                            if (v.ts > seenAtOpen) {
                                Spacer(Modifier.width(8.dp))
                                Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Red).padding(horizontal = 6.dp, vertical = 1.dp)) { Text(tx("NEW"), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                            }
                        }
                        if (v.body.isNotBlank()) Text(brandAppName(v.body).trim(), Modifier.padding(top = 2.dp), fontSize = 13.sp)
                        val time = if (playing) mmss(player.posMs.toLong()) + " / " + mmss(v.durationMs) else mmss(v.durationMs)
                        Text(dateFmt.format(java.util.Date(v.ts)) + "  \u2022  " + time, Modifier.padding(top = 2.dp), fontSize = 11.sp, color = Color.Gray)
                    }
                    if (!selectMode) Icon(Icons.Default.Delete, tx("DELETE"), Modifier.padding(start = 8.dp).size(24.dp).clickable { confirmIds = listOf(v.id) }, tint = Color.Gray)
                }
            }
        }
    }
    confirmIds?.let { ids ->
        Dialog(onDismissRequest = { confirmIds = null }) {
            Column(Modifier.clip(RoundedCornerShape(16.dp)).background(AccountC).padding(20.dp)) {
                Text(if (ids.size == 1) tx("Delete this voice message?") else tx("Delete") + " ${ids.size} " + tx("voice messages?"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(tx("It is removed from your list only."), Modifier.padding(top = 6.dp), fontSize = 13.sp, color = Color.Gray)
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.End)) {
                    VoiceChip(tx("CANCEL"), Color.Gray) { confirmIds = null }
                    VoiceChip(tx("DELETE"), Red) {
                        confirmIds = null
                        if (player.playingId in ids) player.stop()
                        scope.launch {
                            try { VoiceRepo.hide(ctx, ids); selected.clear(); selectMode = false }
                            catch (e: CancellationException) { throw e }
                            catch (_: Exception) { ctx.toast(tx("Could not delete. Try again")) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceChip(text: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(color).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
