package com.bestwinesport.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback

/**
 * Full-screen ZapUPI payment page in its own Activity (a normal WebView, not inside a Compose Dialog window).
 * This keeps the page's pop-ups (Cancel Payment? dialog, Payment Failed / Success bottom sheet) centered and
 * anchored to the real screen. Finishing this screen returns to Add Coins, which then checks the payment status.
 */
class ZapupiCheckoutActivity : ComponentActivity() {
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pageUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        if (!pageUrl.startsWith("https://")) { finish(); return }
        current = java.lang.ref.WeakReference(this)

        // Dark "Secure Payment" look: app logo + spinner + title, no white flash while the payment page loads.
        val dark = 0xFF080B14.toInt()
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        window.setBackgroundDrawable(ColorDrawable(dark))
        window.statusBarColor = dark
        window.navigationBarColor = dark
        val root = FrameLayout(this).apply { setBackgroundColor(dark) }
        val wv = try { WebView(this) } catch (_: Exception) { null }
        if (wv == null) { openAppLink(this, pageUrl); finish(); return }
        web = wv

        val loader = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(dark)
            addView(ImageView(this@ZapupiCheckoutActivity).apply { setImageResource(R.drawable.bestwin_loading_logo); scaleType = ImageView.ScaleType.FIT_CENTER },
                LinearLayout.LayoutParams(px(96), px(96)))
            addView(ProgressBar(this@ZapupiCheckoutActivity).apply { indeterminateTintList = ColorStateList.valueOf(0xFF2F6BFF.toInt()) },
                LinearLayout.LayoutParams(px(34), px(34)).apply { topMargin = px(22) })
            addView(TextView(this@ZapupiCheckoutActivity).apply { text = zapupiText("secure_payment"); setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(18) })
            addView(TextView(this@ZapupiCheckoutActivity).apply { text = zapupiText("verifying"); setTextColor(0xFF8A93A6.toInt()); textSize = 12f; gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(6) })
        }
        val error = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(dark); setPadding(64, 64, 64, 64); visibility = View.GONE
        }
        error.addView(TextView(this).apply { text = zapupiText("open_error"); setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER })
        error.addView(Button(this).apply { text = zapupiText("retry"); setOnClickListener { error.visibility = View.GONE; loader.visibility = View.VISIBLE; wv.loadUrl(pageUrl) } })
        error.addView(Button(this).apply { text = zapupiText("close"); setOnClickListener { finish() } })

        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            setSupportMultipleWindows(false)
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
        }
        wv.setBackgroundColor(dark)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        try { CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(wv, true) } } catch (_: Exception) { }
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase().orEmpty()
                if (scheme == "http" || scheme == "https") return false
                openAppLink(this@ZapupiCheckoutActivity, request.url.toString()); return true
            }
            override fun onPageStarted(view: WebView, u: String?, favicon: Bitmap?) { error.visibility = View.GONE }
            override fun onPageFinished(view: WebView, u: String?) { loader.visibility = View.GONE }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, e: WebResourceError) {
                if (request.isForMainFrame) { loader.visibility = View.GONE; error.visibility = View.VISIBLE }
            }
        }
        wv.webChromeClient = object : WebChromeClient() { override fun onCloseWindow(window: WebView?) { finish() } }
        wv.setDownloadListener { link, _, _, _, _ -> openAppLink(this, link) }

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        root.addView(wv, FrameLayout.LayoutParams(match, match))
        root.addView(loader, FrameLayout.LayoutParams(match, match))
        root.addView(error, FrameLayout.LayoutParams(match, match))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (wv.canGoBack()) wv.goBack() else finish() }
        })
        if (savedInstanceState == null) wv.loadUrl(pageUrl) else wv.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); web?.saveState(outState) }
    override fun onResume() { super.onResume(); web?.onResume() }
    override fun onPause() { web?.onPause(); super.onPause() }
    override fun onDestroy() {
        try { web?.stopLoading(); web?.destroy() } catch (_: Exception) { }
        web = null
        if (current?.get() === this) current = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "pageUrl"
        @Volatile private var current: java.lang.ref.WeakReference<ZapupiCheckoutActivity>? = null

        /** Closes the payment page if it is open (used when the payment result is already known). Call from the main thread. */
        fun closeOpen() { try { current?.get()?.takeIf { !it.isFinishing }?.finish() } catch (_: Exception) { } }

        /** Opens a UPI / app link (upi://, intent://, phonepe:// ...) that the payment page asks for, e.g. the GPay / Paytm buttons. */
        fun openAppLink(ctx: Context, link: String) {
            try {
                val i = if (link.startsWith("intent:")) Intent.parseUri(link, Intent.URI_INTENT_SCHEME).apply { addCategory(Intent.CATEGORY_BROWSABLE); component = null; selector = null }
                else Intent(Intent.ACTION_VIEW, Uri.parse(link))
                ctx.startActivity(i)
            } catch (_: ActivityNotFoundException) { ctx.toast(zapupiText("no_app")) }
            catch (_: Exception) { ctx.toast(zapupiText("open_error")) }
        }
    }
}
