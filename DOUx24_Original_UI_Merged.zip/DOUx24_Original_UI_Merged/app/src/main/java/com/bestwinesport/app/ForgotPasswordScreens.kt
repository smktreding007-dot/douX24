package com.bestwinesport.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

/**
 * Forgot password (no server needed): Login -> "Forgot Password?" -> this dialog -> the player types e-mail / mobile / username
 * -> Firebase sends a reset-link e-mail -> the player opens it on the phone, sets a new password, then logs in.
 */
@Composable
fun ForgotPasswordDialog(initial: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf(initial) }
    var busy by remember { mutableStateOf(false) }
    var sentTo by remember { mutableStateOf<String?>(null) }
    fun submit() {
        if (busy) return
        if (id.isBlank()) { ctx.toast(tx("Enter email/username first")); return }
        busy = true
        scope.launch {
            val (masked, err) = Repo.resetPassword(id)
            busy = false
            if (masked != null) sentTo = masked else ctx.toast(err ?: tx("Failed"))
        }
    }
    Dialog(onDismissRequest = { if (!busy) onDismiss() }) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF14141F))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(20.dp)).padding(20.dp)) {
            Text(tx("Forgot Password"), color = Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            val done = sentTo
            if (done == null) {
                Text(tx("Enter your registered email, mobile number or username. We will send a password reset link to your registered email."),
                    color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, lineHeight = 18.sp)
                Spacer(Modifier.height(14.dp))
                AuthField(id, { id = it }, tx("Email/Mobile No/Username"), Modifier.fillMaxWidth())
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onDismiss, Modifier.weight(1f).height(50.dp), enabled = !busy, shape = RoundedCornerShape(25.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text(tx("CANCEL"), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1) }
                    Button({ submit() }, Modifier.weight(1f).height(50.dp), enabled = !busy, shape = RoundedCornerShape(25.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ButtonC, contentColor = OnButton)) {
                        if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = OnButton, strokeWidth = 2.dp)
                        else Text(tx("SEND LINK"), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    }
                }
            } else {
                Text(tx("Reset link sent to") + " " + done, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text(tx("Open your email on this phone, tap the link, set a new password, then come back and login. If you do not see it, check the Spam folder."),
                    color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, lineHeight = 18.sp)
                Spacer(Modifier.height(18.dp))
                Button(onDismiss, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(25.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ButtonC, contentColor = OnButton)) { Text("OK", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            }
        }
    }
}
