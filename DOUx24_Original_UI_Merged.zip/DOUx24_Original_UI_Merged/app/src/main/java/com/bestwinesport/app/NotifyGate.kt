package com.bestwinesport.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage

/** True when the user lets this app show notifications (covers the Android 13+ permission AND the switch in the app's notification settings). */
fun notificationsAllowed(ctx: Context): Boolean = try { NotificationManagerCompat.from(ctx).areNotificationsEnabled() } catch (_: Exception) { true }

/** Permissions the admin can add to the card (Admin panel -> Notification Card). Notification itself is always on the card. */
private class NPerm(val id: String, val emoji: String, val title: String, val sub: String, val btn: String, val onKey: String, val perms: Array<String>)
private val NPERMS: List<NPerm> = listOf(
    NPerm("mic", "\uD83C\uDF99\uFE0F", "Mic (voice) permission", "For voice and speaking features", "ALLOW MIC (VOICE)", "notifyCardMic", arrayOf(Manifest.permission.RECORD_AUDIO)),
    NPerm("camera", "\uD83D\uDCF7", "Camera permission", "To take photos and screenshots", "ALLOW CAMERA", "notifyCardPerm_camera", arrayOf(Manifest.permission.CAMERA)),
    NPerm("photos", "\uD83D\uDDBC\uFE0F", "Photo / Gallery permission", "To send match screenshots", "ALLOW PHOTOS",
        "notifyCardPerm_photos", when {
            android.os.Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            android.os.Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }),
)
private fun NPerm.granted(ctx: Context): Boolean = try { perms.any { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED } } catch (_: Exception) { true }

private fun Context.notifyFindActivity(): Activity? { var c: Context? = this; while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }; return null }

/** Opens THIS app's notification page in the phone settings directly (falls back to the app info page on phones without it). */
fun openNotificationSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { openAppSettings(ctx) }
}

/** Opens this app's info page (where the Microphone permission can be switched on). */
fun openAppSettings(ctx: Context) {
    try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
}

/**
 * Card "Allow notification": it shows while notifications are not allowed (and the admin has the card ON). The admin can add more rows
 * to it (mic, camera, photos, own text). The card goes away ONLY when notification AND every permission row the admin turned
 * on are allowed - the button asks them one by one (permission boxes first, the notification settings page last).
 */
@Composable
fun NotifyPermissionGate() {
    val ctx = LocalContext.current
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var notifState by remember { mutableStateOf(notificationsAllowed(ctx)) }   // is the card still needed?
    var tick by remember { mutableIntStateOf(0) }   // bumped whenever the player comes back / answers a permission box -> statuses are read again
    // Everything below is set by the admin (Admin panel -> Notification Card); empty = built-in default.
    val cfg by rflow(init = emptyMap<String, Any?>()) { Repo.settings() }
    fun sv(k: String): String = cfg[k]?.toString().orEmpty()
    val askLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        tick++
        // "Don't ask again": the system box no longer shows, so take the player to the app's permission page instead.
        val a = ctx.notifyFindActivity()
        if (a != null && res.isNotEmpty() && res.values.none { it } && res.keys.none { ActivityCompat.shouldShowRequestPermissionRationale(a, it) }) openAppSettings(ctx)
    }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) { notifState = notificationsAllowed(ctx); tick++ } }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    // Extra rows the admin wrote himself (emoji + title + small text); they are only shown on the card, they never block anything.
    val customRaw = sv("notifyCardRows")
    val custom = remember(customRaw) {
        try {
            val a = org.json.JSONArray(customRaw.ifBlank { "[]" })
            (0 until a.length()).map { a.getJSONObject(it) }.map { Triple(it.optString("e"), it.optString("t"), it.optString("s")) }.filter { it.second.isNotBlank() || it.third.isNotBlank() }
        } catch (_: Exception) { emptyList<Triple<String, String, String>>() }
    }
    val cardOn = sv("notifyCardEnabled") != "false"                    // admin switch (default ON)
    val wanted = NPERMS.filter { sv(it.onKey) == "true" }               // extra rows the admin turned on (default: none)
    @Suppress("UNUSED_VARIABLE") val readTick = tick   // reading it makes the card recompose after every resume / permission answer
    val notifOk = notifState
    val states = wanted.map { it to it.granted(ctx) }
    val missing = states.firstOrNull { !it.second }?.first
    val showCard = cardOn && !(notifOk && missing == null)   // gone only when notification AND every row the admin turned on are allowed
    // While the card is up, look every 0.5 s: the card goes away the very moment the LAST permission is allowed
    // (also when the settings page is a floating window and the app never pauses).
    LaunchedEffect(showCard, wanted.map { it.id }) {
        if (showCard) {
            var last = listOf(notificationsAllowed(ctx)) + wanted.map { it.granted(ctx) }
            while (true) {
                kotlinx.coroutines.delay(500)
                val now = listOf(notificationsAllowed(ctx)) + wanted.map { it.granted(ctx) }
                if (now != last) { last = now; notifState = now[0]; tick++ }
            }
        }
    }
    if (!showCard) return
    val gold = Color(0xFFC9A227); val teal = Color(0xFF5DCEB2)
    Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().padding(horizontal = 22.dp), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF111A2B)).border(BorderStroke(1.dp, gold.copy(alpha = .45f)), RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF2A2415)).border(BorderStroke(1.dp, gold.copy(alpha = .5f)), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    val iconUrl = sv("notifyCardIcon").takeIf { it.startsWith("tgimg:") || it.startsWith("dbimg:") || it.startsWith("http://") || it.startsWith("https://") }?.let { BackendConfig.resolve(it) }
                    if (iconUrl != null) androidx.compose.runtime.key(iconUrl) { AsyncImage(iconUrl, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                    else Icon(Icons.Default.Notifications, null, Modifier.size(34.dp), tint = gold)
                }
                Spacer(Modifier.height(16.dp))
                Text(sv("notifyCardTitle").trim().ifBlank { tx("Notification permission is required") }, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(sv("notifyCardText").trim().ifBlank { tx("Allow notifications to get your Room ID, Password and match updates on time. Without them you can miss your match.") },
                    color = Color(0xFFB8C0CC), fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 20.sp)
                Spacer(Modifier.height(18.dp))
                NotifyPermRow("\uD83D\uDD14", tx("Notification permission"), tx("Room ID and match updates"), notifOk)
                states.forEach { (p, ok) ->
                    Spacer(Modifier.height(10.dp))
                    NotifyPermRow(p.emoji, sv("notifyCardPermTitle_${p.id}").trim().ifBlank { tx(p.title) }, sv("notifyCardPermSub_${p.id}").trim().ifBlank { tx(p.sub) }, ok)
                }
                custom.forEach { (e, t, sub) ->
                    Spacer(Modifier.height(10.dp))
                    NotifyInfoRow(e.trim().ifBlank { "\u2728" }, t.trim(), sub.trim())
                }
                Spacer(Modifier.height(20.dp))
                Button({ if (missing != null) askLauncher.launch(missing.perms) else openNotificationSettings(ctx) }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = teal, contentColor = Color.Black)) {
                    Text(tx(missing?.btn ?: "ALLOW NOTIFICATION"), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                }
                Spacer(Modifier.height(10.dp))
                Text(if (missing == null) tx("The settings page opens: turn on \"Allow notifications\", then come back.") else tx("Tap Allow in the box that appears."),
                    color = Color(0xFF8D96A5), fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun NotifyPermRow(emoji: String, title: String, sub: String, ok: Boolean) {
    val c = if (ok) Color(0xFF43A047) else Color(0xFFE01B10); val tc = if (ok) Color(0xFF9BE3A0) else Color(0xFFFF8A80)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (ok) Color(0xFF0F2A22) else Color(0xFF0E1522))
        .border(BorderStroke(1.dp, if (ok) Color(0x5543A047) else Color(0x22FFFFFF)), RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(sub, color = Color(0xFF9AA3B2), fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .2f)).border(BorderStroke(1.dp, c.copy(alpha = .45f)), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text(if (ok) "\u2705 " + tx("Allowed") else "\u274C " + tx("Pending"), color = tc, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

/** A row the admin wrote himself: emoji, title and small text, no status chip. */
@Composable
private fun NotifyInfoRow(emoji: String, title: String, sub: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF0E1522)).border(BorderStroke(1.dp, Color(0x22FFFFFF)), RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 24.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            if (title.isNotBlank()) Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (sub.isNotBlank()) Text(sub, color = Color(0xFF9AA3B2), fontSize = 12.sp)
        }
    }
}
