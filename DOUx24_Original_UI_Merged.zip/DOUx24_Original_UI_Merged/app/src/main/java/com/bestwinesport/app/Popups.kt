package com.bestwinesport.app

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Close
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import coil.compose.AsyncImage
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState

/** Shown (and cannot be dismissed) while the player's account is banned. Shows the reason the admin typed + a Customer Support shortcut. */
@Composable
fun BannedDialog(nav: NavController, reason: String) {
    val ctx = LocalContext.current
    AppDialog(title = tx("Account banned"), onDismiss = { }, cancelable = false,
        confirmText = tx("CUSTOMER SUPPORT"), onConfirm = { nav.navigate("support") },
        dismissText = tx("LOG OUT"), onDismissClick = { Repo.auth.signOut(); ctx.toast(tx("Log out Successfully")); nav.navigate("login") { popUpTo(0) } }) {
        Text(tx("Reason"), color = Color.Gray, fontSize = 12.sp)
        Text(reason.ifBlank { tx("Your account was banned for breaking the rules.") }, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        Text(tx("If you think this is a mistake, please contact Customer Support."), color = Color.DarkGray, fontSize = 13.sp)
    }
}

private fun popupSeen(ctx: Context) = ctx.getSharedPreferences("m4_popup", Context.MODE_PRIVATE)

/**
 * Message popup the admin can send from App control at any time. Each popup has an id; a player sees it once
 * (until the admin publishes a new one). Optional Customer Support button.
 */
/** Process-wide flag: "every app open" popups are shown once per app start. */
private object PopupSession { var shown = false }

/**
 * The offer card the admin sends from the admin app (image + title + text + big button + "Maybe later").
 * Button actions: deposit / wallet / support / link / none. Frequency: once / daily / every_open.
 */
@Composable
fun AdminPopupHost(nav: NavController) {
    val ctx = LocalContext.current
    val cfg by rflow(init = AppConfig()) { Repo.appConfig() }
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    var seenId by remember { mutableStateOf(popupSeen(ctx).getString("seen", "") ?: "") }
    var seenAt by remember { mutableLongStateOf(popupSeen(ctx).getLong("seenAt", 0L)) }
    var hiddenNow by remember { mutableStateOf(false) }
    val ready = route != null && route !in setOf("splash", "lang", "welcome", "login", "signup")
    val online = rememberOnline()
    if (!online || !ready || hiddenNow || !cfg.popupOn || cfg.popupId.isBlank() || (cfg.popupMsg.isBlank() && cfg.popupImage.isBlank() && cfg.popupTitle.isBlank())) return
    val day = 24L * 60 * 60 * 1000
    val show = when (cfg.popupFreq) {
        "every_open" -> !PopupSession.shown
        "daily" -> cfg.popupId != seenId || System.currentTimeMillis() - seenAt > day
        else -> cfg.popupId != seenId
    }
    if (!show) return
    fun close() {
        val now = System.currentTimeMillis()
        popupSeen(ctx).edit().putString("seen", cfg.popupId).putLong("seenAt", now).apply()
        seenId = cfg.popupId; seenAt = now; PopupSession.shown = true; hiddenNow = true
    }
    fun act() {
        close()
        when (cfg.popupAction) {
            "deposit" -> nav.navigate("addmoney")
            "wallet" -> nav.navigate("wallet")
            "support" -> nav.navigate("support")
            "link" -> if (cfg.popupLink.isNotBlank()) {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(cfg.popupLink.trim())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { ctx.toast(tx("Link not added yet")) }
            }
            else -> Unit
        }
    }
    androidx.compose.ui.window.Dialog(
        onDismissRequest = { close() },
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 26.dp).clip(RoundedCornerShape(34.dp)).background(Color(0xFF050505)).padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(30.dp).clickable { close() })
            }
            if (cfg.popupImage.isNotBlank()) {
                AsyncImage(cfg.popupImage, null, Modifier.fillMaxWidth().padding(top = 10.dp).heightIn(max = 330.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.FillWidth)
            }
            Column(Modifier.verticalScroll(rememberScrollState()).heightIn(max = 260.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (cfg.popupTitle.isNotBlank()) Text(brandAppName(cfg.popupTitle), Modifier.padding(top = 20.dp), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                if (cfg.popupMsg.isNotBlank()) Text(brandAppName(cfg.popupMsg), Modifier.padding(top = 12.dp), color = Color(0xFFD0D0D0), fontSize = 16.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
            }
            Box(Modifier.fillMaxWidth().padding(top = 22.dp).height(56.dp).clip(RoundedCornerShape(30.dp)).background(ButtonC).clickable { act() }, contentAlignment = Alignment.Center) {
                Text(cfg.popupButton.ifBlank { "OK" }, color = OnButton, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            Text(tx("Maybe later"), Modifier.padding(top = 16.dp, bottom = 6.dp).clickable { close() }, color = Color.Gray, fontSize = 16.sp)
        }
    }
}
