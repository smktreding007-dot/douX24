package com.bestwinesport.app

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * One-time hint on the match list: the FIRST time the player taps an upcoming match card, that card (and only that card) is dimmed
 * with "Tap here to join this tournament" and the JOIN button stays bright. After this it is never shown again (saved on the device).
 */
object JoinTour {
    private const val PREF = "join_tour"
    private const val KEY = "done"

    /** True only until the hint has been consumed. Any failure reading prefs counts as "already shown" so it can never loop or crash. */
    fun pending(ctx: Context): Boolean = try {
        !ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(KEY, false)
    } catch (e: Exception) { false }

    fun markDone(ctx: Context) {
        try { ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(KEY, true).apply() } catch (e: Exception) { }
    }
}

/**
 * Full-screen hint (like the reference video): the whole page is dimmed, a ROUND spotlight stays bright around the JOIN button of the
 * tapped card, and "Tap here to join this tournament" sits on that card. A tap anywhere closes it; swipes under it are blocked.
 * [card] / [join] are bounds in the window.
 */
@Composable
fun JoinTourOverlay(card: Rect, join: Rect, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    var origin by remember { mutableStateOf(Offset.Zero) }
    Box(modifier
        .onGloballyPositioned { origin = it.boundsInWindow().topLeft }
        .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        .pointerInput(Unit) { detectDragGestures { change, _ -> change.consume() } }) {
        Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
            drawRect(Color.Black.copy(alpha = 0.78f))
            if (join.width > 0f && join.height > 0f) {
                // Round spotlight centred on the JOIN button (no outline).
                val centre = Offset(join.center.x - origin.x, join.center.y - origin.y)
                drawCircle(Color.Black, radius = join.width / 2f + 6.dp.toPx(), center = centre, blendMode = BlendMode.Clear)
            }
        }
        Text(
            tx("Tap here to join this tournament"),
            Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                .offset { IntOffset(0, (card.top - origin.y + card.height * 0.30f).toInt()) },
            color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, lineHeight = 25.sp, textAlign = TextAlign.Center
        )
    }
}
