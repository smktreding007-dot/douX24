package com.bestwinesport.app

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.net.URL

class BestwinMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseDatabase.getInstance().reference.child("users/$uid/fcmToken").setValue(token)
    }

    // Admin pushes are data-only so this service renders both foreground and background notifications.
    // This keeps the full-color DOUx24 logo as the app large-icon and uses a photo only when one was selected.
    override fun onMessageReceived(m: RemoteMessage) {
        val isVoice = m.data["type"] == "voice"
        val title = if (isVoice) "\uD83C\uDF99\uFE0F DOUx24 Voice Message"
            else brandAppName(m.notification?.title ?: m.data["title"] ?: "DOUx24")
        AppLanguage.load(applicationContext) // service can run while app is closed, so read the saved language
        val voiceBody = if (AppLanguage.current == "hi") "\u0928\u092F\u093E \u0935\u0949\u0907\u0938 \u092E\u0948\u0938\u0947\u091C \u0906\u092F\u093E \u0939\u0948 \u2014 Play \u0926\u092C\u093E\u0915\u0930 \u0938\u0941\u0928\u0947\u0902 \uD83D\uDD0A"
            else "New voice message received \u2014 tap Play to listen \uD83D\uDD0A"
        val body = if (isVoice) voiceBody else (m.notification?.body ?: m.data["body"] ?: "")
        val img = (m.notification?.imageUrl?.toString() ?: m.data["image"])?.let { BackendConfig.resolve(it) }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val open = Intent(this, MainActivity::class.java)
        if (isVoice) open.putExtra("open_route", "voicemessages").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(this, if (isVoice) 4108 else 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val logoOptions = BitmapFactory.Options().apply { inSampleSize = 2 }
        val appLogo = BitmapFactory.decodeResource(resources, R.drawable.bestwin_loading_logo, logoOptions) // round DOUx24 logo
        val b = NotificationCompat.Builder(this, "bestwin_default").setSmallIcon(R.drawable.ic_notification_logo)
            .setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH)
        if (appLogo != null) b.setLargeIcon(appLogo)
        if (!img.isNullOrBlank()) try {
            val bmp = if (img.startsWith("dbimg:")) {
                val bytes = kotlinx.coroutines.runBlocking { kotlinx.coroutines.withTimeoutOrNull(6000) { DbImages.bytes(applicationContext, img.removePrefix("dbimg:")) } }
                bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            } else BitmapFactory.decodeStream(URL(img).openStream())
            if (bmp != null) b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bmp).setSummaryText(body))
        } catch (_: Exception) { }
        NotificationManagerCompat.from(this).notify(System.currentTimeMillis().toInt(), b.build())
    }
}
