package com.bestwinesport.app

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class User(
    var firstName: String = "", var lastName: String = "", var username: String = "",
    var phone: String = "", var email: String = "", var role: String = "user",
    var deposited: Double = 0.0, var winning: Double = 0.0, var earnings: Double = 0.0, var payouts: Double = 0.0,
    var referralCode: String = "", var referredBy: String = "", var avatar: String = "",
    var banned: Boolean = false, var matchesPlayed: Long = 0, var wins: Long = 0, var kills: Long = 0,
    var createdAt: Long = 0, var dob: String = "", var gender: String = "", var kyc: Boolean = false,
    var pushEnabled: Boolean = true, var referralEarnings: Double = 0.0, var theme: String = "", var banReason: String = ""
) { fun balance() = deposited + winning }

/** A home-screen section (FREE FIRE, PRIVATE ...), added by the admin. type "games" = list of games with admin matches, "player" = Player Match. */
@IgnoreExtraProperties
data class Section(var id: String = "", var name: String = "", var image: String = "", var type: String = "games",
                   var order: Long = 0, var active: Boolean = true)

@IgnoreExtraProperties
data class Game(var id: String = "", var name: String = "", var image: String = "", var section: String = "freefire",
                var order: Long = 0, var active: Boolean = true,
                  /** Onboarding slides only: heading and text shown under the picture (set in Admin -> Banners). */
                  var title: String = "", var subtitle: String = "")

@IgnoreExtraProperties
data class Banner(var id: String = "", var image: String = "", var link: String = "", var section: String = "important",
                  var order: Long = 0, var active: Boolean = true)

@IgnoreExtraProperties
data class Match(
    var id: String = "", var matchId: String = "", var gameId: String = "", var title: String = "", var matchNo: String = "",
    var mode: String = "Solo", var map: String = "Bermuda", var entryFee: Double = 0.0, var prizePool: Double = 0.0,
    var perKill: Double = 0.0, var startTime: Long = 0, var maxPlayers: Long = 48, var joined: Long = 0,
    var image: String = "", var rules: String = "", var status: String = "upcoming", var type: String = "PAID", var comment: String = "", var prizeDetails: String = "", var liveUrl: String = "",
    /** true = the admin set an access code for this match (the code itself is never sent to players; it is checked by the database rules). */
    var hasAccessCode: Boolean = false,
    /** true = the admin removed this match; it is rebuilt from the copy saved in the player's own history. */
    @get:com.google.firebase.database.Exclude @set:com.google.firebase.database.Exclude var archived: Boolean = false
) {
    /** Players in one team: Solo 1, Duo 2, Squad 4, or the first number of "3vs3" / "5vs5" / "6vs6" (spaces and capitals do not matter). */
    fun perTeam(): Int {
        val m = mode.lowercase().replace(" ", "")
        Regex("^(\\d+)vs\\d+$").find(m)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(1, 6) }
        return when (m) { "duo" -> 2; "squad" -> 4; else -> 1 }
    }
    fun teams() = ((maxPlayers + perTeam() - 1) / perTeam()).toInt()
    fun fee() = if (type.equals("FREE", true)) 0.0 else entryFee
}

@IgnoreExtraProperties
data class Slot(var uid: String = "", var username: String = "", var ign: String = "", var ts: Long = 0)

@IgnoreExtraProperties
data class Res(var username: String = "", var ign: String = "", var kills: Long = 0, var prize: Double = 0.0)

@IgnoreExtraProperties
data class Tx(var id: String = "", var type: String = "", var amount: Double = 0.0, var note: String = "",
              var ts: Long = 0, var status: String = "")

@IgnoreExtraProperties
data class LBE(var uid: String = "", var username: String = "", var score: Double = 0.0)

/** Leaderboard cycle id (IST). period: daily / weekly (Mon-Sun) / monthly. A new cycle = a fresh board, so no manual reset needed. */
fun lbKey(period: String): String {
    val tz = java.util.TimeZone.getTimeZone("Asia/Kolkata")
    val c = java.util.Calendar.getInstance(tz).apply { firstDayOfWeek = java.util.Calendar.MONDAY }
    when (period) { "weekly" -> c.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY); "monthly" -> c.set(java.util.Calendar.DAY_OF_MONTH, 1) }
    val f = java.text.SimpleDateFormat(if (period == "monthly") "yyyyMM" else "yyyyMMdd", java.util.Locale.US).apply { timeZone = tz }
    return period + "_" + f.format(c.time)
}

@IgnoreExtraProperties
data class Ann(var id: String = "", var title: String = "", var text: String = "", var image: String = "", var ts: Long = 0) {
    /** Heading shown in the list / ticker: the title, or the first line of the message for older announcements. */
    fun heading(): String = title.ifBlank { text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty() }
}

fun fmt(d: Double): String = String.format(java.util.Locale.US, "%.2f", d)
fun money(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else fmt(d)

@IgnoreExtraProperties
data class Referral(var username: String = "", var ts: Long = 0, var status: String = "pending")

@IgnoreExtraProperties
data class Reward(var title: String = "", var amount: Double = 0.0, var ts: Long = 0)

data class AppConfig(
    val maintenance: Boolean = false, val maintenanceMsg: String = "", val updateOn: Boolean = true,
    val latestCode: Long = 0, val minCode: Long = 0, val latestName: String = "",
    val updateUrl: String = "", val updateNotes: String = "",
    val popupOn: Boolean = false, val popupId: String = "", val popupTitle: String = "",
    val popupMsg: String = "", val popupSupport: Boolean = true,
    val popupImage: String = "", val popupButton: String = "", val popupAction: String = "none",
    val popupLink: String = "", val popupFreq: String = "every_open"
)

data class DepositReq(var id: String = "", var amount: Double = 0.0, var utr: String = "", var status: String = "pending", var ts: Long = 0)

// ---------------------------------------------------------------------------------------------------------------
// Player vs Player matches (created by players, result approved by the admin)
// ---------------------------------------------------------------------------------------------------------------

/** A game the admin enabled for player-made matches (Admin -> Player match games). `slots` = allowed player counts, e.g. "2" (1 vs 1) or "2,4". */
@IgnoreExtraProperties
data class PvpGame(var id: String = "", var name: String = "", var image: String = "", var slots: String = "2",
                   var commission: Double = 0.0, var order: Long = 0, var active: Boolean = true,
                   /** Match title set by the admin; the app adds the running number, e.g. "CS 1VS1 MATCH #767". */
                   var title: String = "", var rules: String = "",
                   /** Wide banner the admin uploads ONCE; every match of this game shows it on top of its card. Empty = use `image`. */
                   var banner: String = "") {
    fun bannerUrl(): String = banner.ifBlank { image }
    fun slotOptions(): List<Int> = slots.split(',', ' ', '/', ';').mapNotNull { it.trim().toIntOrNull() }
        .filter { it in 2..20 }.distinct().sorted().ifEmpty { listOf(2) }
}

@IgnoreExtraProperties
data class PvpMatch(
    var id: String = "", var gameId: String = "", var gameName: String = "", var gameImage: String = "",
    var creatorUid: String = "", var creatorName: String = "", var entryFee: Double = 0.0, var prize: Double = 0.0,
    var slots: Long = 2, var startTime: Long = 0, var note: String = "", var status: String = "upcoming",
    var commission: Double = 0.0, var createdAt: Long = 0, var winnerUid: String = "", var winnerName: String = "",
    var resultDeclared: Boolean = false, var matchCode: String = "", var title: String = "", var matchNo: Long = 0,
    /** Filled by the app from the number of seats taken (not stored in the database). */
    @get:com.google.firebase.database.Exclude @set:com.google.firebase.database.Exclude var joined: Long = 0
) {
    /** Admin title + running number, for example "CS 1VS1 MATCH #767". */
    fun label(): String = title.ifBlank { gameName } + if (matchNo > 0) " #$matchNo" else " #$matchCode"
}

data class PvpPlayer(val seat: String, val uid: String, val username: String, val ts: Long, val ign: String = "")
data class PvpReport(val uid: String, val username: String, val winnerName: String, val note: String, val ts: Long)

/** Entry fee -> winning amount rules for player matches. */
object Pvp {
    const val MIN_FEE = 5.0
    /** Quick-pick entry fees shown in the Create screen (any amount of 5 or more can also be typed). */
    val QUICK_FEES = listOf(5, 10, 20, 35, 50, 100, 150)
    /** Fixed winning for a 1 vs 1 match: entry fee -> winning. */
    private val TABLE = mapOf(5 to 8, 10 to 16, 20 to 35, 35 to 60, 50 to 85, 100 to 170, 150 to 250)

    /**
     * Winning amount (generated automatically, players cannot type it).
     * - If the admin set a commission % for the game: pool (fee x players) minus that commission.
     * - Otherwise the fixed table above (5 -> 8, 10 -> 16 ... 150 -> 250) for 2 players; more players scale by players / 2.
     * - A fee that is not in the table (for example 70) gets 1.7 x the fee (the same rate as 50 -> 85 and 100 -> 170).
     * The admin app uses the same function again when it pays the winner, so a tampered value is never paid.
     */
    fun prize(fee: Double, players: Int, commissionPct: Double): Double {
        if (fee <= 0.0 || players < 2) return 0.0
        if (commissionPct > 0.0) return Math.floor(fee * players * (100.0 - commissionPct.coerceAtMost(100.0)) ) / 100.0
        val base = if (fee % 1.0 == 0.0 && TABLE.containsKey(fee.toInt())) TABLE.getValue(fee.toInt()).toDouble()
        else {
            // Any other fee (6, 7, 8, 12, 70 ...) uses the rate of the nearest lower step of the table (6 -> rate of 5, 70 -> rate of 50).
            val k = TABLE.keys.filter { it <= fee }.maxOrNull() ?: TABLE.keys.minOrNull()!!
            Math.floor(fee * TABLE.getValue(k) / k)
        }
        return base * players / 2.0
    }
}
