package com.bestwinesport.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.os.Build
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Voice messages inside the World chat (players and admins).
 * The recording (AAC .m4a, mono, small) is cut in pieces and saved as worldChat/voice/<voiceId>/c0..cN (base64).
 * The chat message (kind = "voice", voiceId, durationMs) is written LAST, so nobody sees a half uploaded voice.
 * Players can record up to 30 seconds, the admin up to 60 seconds.
 */
object ChatVoice {
    const val USER_MAX_MS = 30_000L
    private const val CHUNK = 150_000

    fun fmt(ms: Long): String { val s = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(s / 60, s % 60) }

    suspend fun upload(file: File): String = withContext(Dispatchers.IO) {
        val bytes = file.readBytes()
        if (bytes.isEmpty()) throw Exception("empty")
        val id = Repo.db.child("worldChat/voice").push().key ?: throw Exception("no id")
        val n = (bytes.size + CHUNK - 1) / CHUNK
        if (n > 6) throw Exception("too long")
        try {
            for (i in 0 until n) {
                val from = i * CHUNK
                val to = minOf(bytes.size, from + CHUNK)
                Repo.db.child("worldChat/voice/$id/c$i").setValue(Base64.encodeToString(bytes, from, to - from, Base64.NO_WRAP)).await()
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { throw Exception(e.message ?: "error") }
        id
    }

    /** The audio as a file on this phone (downloaded once, then cached). */
    suspend fun audioFile(ctx: Context, id: String): File? = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "voice").apply { mkdirs() }
        val f = File(dir, "wc_" + id.filter { it.isLetterOrDigit() || it == '_' || it == '-' } + ".m4a")
        if (f.exists() && f.length() > 0) return@withContext f
        val snap = Repo.db.child("worldChat/voice/$id").get().await()
        val parts = snap.children.mapNotNull { c -> c.key?.removePrefix("c")?.toIntOrNull()?.let { it to (c.value?.toString() ?: "") } }.sortedBy { it.first }
        if (parts.isEmpty()) return@withContext null
        val out = java.io.ByteArrayOutputStream()
        parts.forEach { out.write(Base64.decode(it.second, Base64.NO_WRAP)) }
        f.writeBytes(out.toByteArray())
        f
    }
}

/** Microphone recorder. start() -> null when recording, else an error text. stop() -> length in ms, or -1 when the recording is too short / failed. */
class VoiceRec(private val ctx: Context, private val maxMs: Long) {
    private var rec: MediaRecorder? = null
    private var startedAt = 0L
    var file: File? = null
        private set

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(): String? {
        cancel()
        return try {
            val f = File(ctx.cacheDir, "rec_" + System.currentTimeMillis() + ".m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioChannels(1)
            r.setAudioSamplingRate(22050)
            r.setAudioEncodingBitRate(32000)
            r.setMaxDuration((maxMs + 1000).toInt())
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r; file = f; startedAt = System.currentTimeMillis()
            null
        } catch (e: Exception) {
            try { rec?.release() } catch (_: Exception) { }
            rec = null; file = null
            tx("Could not start the microphone")
        }
    }

    fun stop(): Long {
        val r = rec ?: return -1
        rec = null
        val spoken = System.currentTimeMillis() - startedAt
        return try {
            r.stop(); r.release()
            minOf(realLength(file) ?: spoken, maxMs)
        } catch (e: Exception) {
            try { r.release() } catch (_: Exception) { }
            file?.delete(); file = null
            -1
        }
    }

    /** Stops a running recording and throws it away. */
    fun cancel() {
        val r = rec ?: return
        rec = null
        try { r.stop() } catch (_: Exception) { }
        try { r.release() } catch (_: Exception) { }
        file?.delete(); file = null
    }

    private fun realLength(f: File?): Long? {
        if (f == null) return null
        val m = MediaMetadataRetriever()
        return try { m.setDataSource(f.absolutePath); m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() }
        catch (_: Exception) { null } finally { try { m.release() } catch (_: Exception) { } }
    }
}
