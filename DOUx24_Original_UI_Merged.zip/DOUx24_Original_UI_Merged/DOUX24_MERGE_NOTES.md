# DOUx24 merged project notes

This package is rebuilt from the first supplied BESTWIN_ESPORTS project. Original Compose screens, layouts, navigation and feature implementation are retained. Applied changes are limited to DOUx24 branding strings/assets, Android application IDs, Firebase project configuration, and the existing backend source/setup files.

Firebase project: doux24-c9bb3
Application IDs: com.doux24.player, com.doux24.admin, com.doux24.staff

IMPORTANT: Backend deployment is NOT confirmed by this source ZIP. The app BackendConfig files still reference the previously configured BESTWIN Railway URL. Replace that URL with the actual deployed DOUx24 Railway service URL after deployment, then rebuild. Do not assume payments are live until ZapUPI credentials/webhook are configured in Railway and end-to-end payment verification is tested.

Firebase Storage is not required for this build unless you enable features that upload files to Firebase Storage. Admin image upload currently uses the configured external image upload integration.
